import { ui } from "./store";

let ctx: AudioContext | null = null;
let master: GainNode, sfxBus: GainNode, musBus: GainNode, noiseBuf: AudioBuffer;
let musicTimer: number | null = null;
let step = 0;
let cfg = { root: 60, scale: "major" as "major" | "minor" | "lyd", bpm: 124, mood: "game" as "game" | "menu" | "boss" | "hub" };
let seedArp = 1;

const SCALES = { major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10], lyd: [0, 2, 4, 6, 7, 9, 11] };
const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

export function initAudio() {
  if (ctx) { if (ctx.state === "suspended") ctx.resume(); return; }
  try {
    ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    master = ctx.createGain(); master.gain.value = 0.9;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    master.connect(comp); comp.connect(ctx.destination);
    sfxBus = ctx.createGain(); musBus = ctx.createGain(); sfxBus.connect(master); musBus.connect(master);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    applyVolumes();
  } catch { ctx = null; }
}
export function applyVolumes() {
  if (!ctx) return;
  sfxBus.gain.value = ui.settings.sfx; musBus.gain.value = ui.settings.music * 0.35;
}

function tone(freq: number, dur: number, type: OscillatorType = "square", vol = 0.2, when = 0, slide = 0, bus?: GainNode) {
  if (!ctx) return;
  const t = ctx.currentTime + when;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq * slide), t + dur);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(bus ?? sfxBus); o.start(t); o.stop(t + dur + 0.02);
}
function noise(dur: number, vol = 0.2, f = 2000, when = 0, q = 0.7, type: BiquadFilterType = "bandpass", bus?: GainNode) {
  if (!ctx) return;
  const t = ctx.currentTime + when;
  const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
  const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q;
  const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(fl); fl.connect(g); g.connect(bus ?? sfxBus); s.start(t); s.stop(t + dur + 0.02);
}

export type Sfx = "coin" | "jump" | "hover" | "spin" | "hit" | "spring" | "stomp" | "rescue" | "puzzle" | "check" | "goal" | "move" | "ok" | "back" | "die" | "bosshit" | "smash" | "gadget" | "land" | "gatcha" | "boom" | "shoot" | "win" | "warp";
let lastCoin = 0, coinPitch = 0;
export function sfx(n: Sfx) {
  if (!ctx) return;
  switch (n) {
    case "coin": { const now = performance.now(); coinPitch = now - lastCoin < 500 ? Math.min(coinPitch + 1, 8) : 0; lastCoin = now; const f = 1000 * Math.pow(2, coinPitch / 12); tone(f, 0.08, "square", 0.1); tone(f * 1.5, 0.14, "square", 0.1, 0.06); break; }
    case "jump": tone(300, 0.2, "square", 0.12, 0, 2.4); break;
    case "hover": noise(0.12, 0.05, 900, 0, 1, "bandpass"); break;
    case "spin": noise(0.3, 0.15, 1400, 0, 0.8); tone(500, 0.25, "sawtooth", 0.05, 0, 1.8); break;
    case "hit": tone(220, 0.35, "sawtooth", 0.2, 0, 0.4); noise(0.2, 0.2, 700); break;
    case "spring": tone(200, 0.35, "sine", 0.25, 0, 5); tone(400, 0.3, "triangle", 0.12, 0.05, 3); break;
    case "stomp": tone(160, 0.15, "square", 0.2, 0, 0.5); noise(0.1, 0.2, 400); break;
    case "rescue": [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, 0.22, "triangle", 0.2, i * 0.07)); break;
    case "puzzle": [659, 784, 988, 1319, 1568].forEach((f, i) => { tone(f, 0.3, "sine", 0.22, i * 0.09); tone(f * 2, 0.2, "triangle", 0.08, i * 0.09); }); break;
    case "check": tone(784, 0.15, "triangle", 0.2); tone(1175, 0.3, "triangle", 0.2, 0.1); break;
    case "goal": [523, 659, 784, 1047, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, 0.25, "square", 0.12, i * 0.1)); break;
    case "win": [392, 523, 659, 784, 1047, 1319].forEach((f, i) => { tone(f, 0.5, "triangle", 0.18, i * 0.12); tone(f / 2, 0.5, "sine", 0.18, i * 0.12); }); break;
    case "move": tone(880, 0.05, "triangle", 0.1); break;
    case "ok": tone(660, 0.08, "triangle", 0.15); tone(990, 0.14, "triangle", 0.15, 0.06); break;
    case "back": tone(500, 0.08, "triangle", 0.12); tone(350, 0.12, "triangle", 0.12, 0.05); break;
    case "die": tone(500, 0.6, "sawtooth", 0.15, 0, 0.15); break;
    case "bosshit": tone(120, 0.4, "square", 0.25, 0, 0.4); noise(0.3, 0.3, 500); tone(880, 0.2, "triangle", 0.15, 0.05); break;
    case "smash": noise(0.25, 0.3, 1800, 0, 0.5); tone(240, 0.12, "square", 0.1); break;
    case "gadget": [392, 494, 587, 784].forEach((f, i) => tone(f, 0.15, "sawtooth", 0.1, i * 0.05)); break;
    case "land": noise(0.08, 0.08, 300, 0, 1, "lowpass"); break;
    case "gatcha": for (let i = 0; i < 6; i++) tone(500 + i * 120, 0.08, "square", 0.1, i * 0.08); break;
    case "boom": noise(0.6, 0.4, 200, 0, 0.5, "lowpass"); tone(70, 0.5, "sine", 0.3, 0, 0.4); break;
    case "shoot": tone(700, 0.18, "square", 0.1, 0, 0.3); break;
    case "warp": tone(200, 1.0, "sawtooth", 0.12, 0, 8); noise(1.0, 0.1, 3000, 0, 0.5); break;
  }
}

// ───────── Music (procedural, seeded per world) ─────────
export function setMusic(root: number, scale: "major" | "minor" | "lyd", mood: "game" | "menu" | "boss" | "hub" = "game", seed = 1) {
  cfg = { root, scale, mood, bpm: mood === "menu" ? 84 : mood === "boss" ? 148 : mood === "hub" ? 102 : 124 };
  seedArp = seed; step = 0;
  if (!ctx || musicTimer !== null) return;
  schedule();
}
export function stopMusic() { if (musicTimer !== null) { clearTimeout(musicTimer); musicTimer = null; } }
let nextTime = 0;
function schedule() {
  if (!ctx) return;
  nextTime = ctx.currentTime + 0.05;
  const loop = () => {
    if (!ctx) return;
    while (nextTime < ctx.currentTime + 0.25) { play(step, nextTime); nextTime += 60 / cfg.bpm / 2; step++; }
    musicTimer = window.setTimeout(loop, 80);
  };
  loop();
}
const PROG = [0, 5, 3, 4]; // scale degrees for chords
function play(s: number, t: number) {
  if (!ctx) return;
  const sc = SCALES[cfg.scale];
  const bar = Math.floor(s / 8) % 4;
  const deg = PROG[bar];
  const n = (d: number, oct = 0) => cfg.root + sc[((d % 7) + 7) % 7] + 12 * (Math.floor(d / 7) + oct);
  const off = t - ctx.currentTime;
  const m = cfg.mood;
  // bass
  if (s % 2 === 0) tone(mtof(n(deg, -2)), 0.28, "triangle", m === "menu" ? 0.3 : 0.38, off, 0, musBus);
  // arp
  const pat = [0, 2, 4, 2, 4, 7, 4, 2];
  const r = ((s * 2654435761 + seedArp * 97) >>> 0) % 5;
  if (m === "menu") { if (s % 2 === 0) tone(mtof(n(deg + pat[(s / 2) % 8] + 7)), 0.9, "sine", 0.22, off, 0, musBus); }
  else {
    tone(mtof(n(deg + pat[s % 8] + 7)), 0.16, m === "boss" ? "sawtooth" : "square", 0.07, off, 0, musBus);
    if (r === 0 && s % 4 === 1) tone(mtof(n(deg + 4 + 14)), 0.3, "triangle", 0.1, off, 0, musBus);
    // pad
    if (s % 8 === 0) { tone(mtof(n(deg + 2, 0)), 1.8, "sine", 0.1, off, 0, musBus); tone(mtof(n(deg + 4, 0)), 1.8, "sine", 0.08, off, 0, musBus); }
    // hat / kick
    if (s % 2 === 1) noise(0.04, 0.06, 7000, off, 1, "highpass", musBus);
    if (s % 4 === 0 && m !== "hub") { tone(110, 0.14, "sine", 0.4, off, 0.3, musBus); }
    if (m === "boss" && s % 4 === 2) noise(0.1, 0.12, 1800, off, 1, "bandpass", musBus);
  }
}
