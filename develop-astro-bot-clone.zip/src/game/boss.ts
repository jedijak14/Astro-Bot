import * as THREE from "three";
import { Actor, makeFox, makeBird, tintAnimal, stdMat, glowTexture } from "./assets";
import { sfx } from "./audio";
import type { Level } from "./level";
import type { BossKey } from "./data";

const V = THREE.Vector3;
type St = "intro" | "chase" | "telegraph" | "charge" | "stunned" | "hurt" | "dead";

interface Cfg { name: string; hp: number; R: number; Hh: number; speed: number; chase: number; attacks: ("shock" | "shoot" | "rain")[]; hover: number }
const CFG: Record<BossKey, Cfg> = {
  chewy: { name: "MIGHTY CHEWY", hp: 3, R: 2.0, Hh: 3.4, speed: 3.6, chase: 3.4, attacks: ["shock"], hover: 0 },
  wako: { name: "WAKO TAKO", hp: 3, R: 2.4, Hh: 3.2, speed: 3.0, chase: 3.4, attacks: ["rain", "shoot"], hover: 0.6 },
  venomara: { name: "LADY VENOMARA", hp: 4, R: 1.5, Hh: 2.4, speed: 4.4, chase: 3.0, attacks: ["shoot", "rain"], hover: 0 },
  leon: { name: "MECHA LEON", hp: 4, R: 1.9, Hh: 2.6, speed: 4.0, chase: 3.0, attacks: ["shock", "shoot"], hover: 0 },
  falcon: { name: "FALCON McFLY", hp: 4, R: 1.8, Hh: 3.4, speed: 4.2, chase: 3.0, attacks: ["rain", "shoot"], hover: 3.0 },
  nebulax: { name: "SPACE BULLY NEBULAX", hp: 5, R: 2.8, Hh: 4.6, speed: 4.2, chase: 2.8, attacks: ["shock", "rain", "shoot"], hover: 1.6 },
};

export class Boss {
  cfg: Cfg; hp: number; pos = new V(0, 0, -6); g = new THREE.Group();
  state: St = "intro"; t = 0; dir = new V(0, 0, 1); yaw = 0;
  actor: Actor | null = null;
  parts: THREE.Object3D[] = [];
  trail: THREE.Vector3[] = [];
  seg: THREE.Mesh[] = [];
  star: THREE.Sprite;
  flash = 0; invuln = 0; atkT = 1.5; phase = 0; hoverY = 0;
  marks: { pos: THREE.Vector3; t: number; mesh: THREE.Mesh }[] = [];
  rings: { r: number; mesh: THREE.Mesh; hit: boolean }[] = [];
  tent: THREE.Mesh[][] = [];
  body!: THREE.Object3D;
  mats: THREE.MeshStandardMaterial[] = [];
  handL?: THREE.Mesh; handR?: THREE.Mesh;

  constructor(public kind: BossKey, lv: Level) {
    this.cfg = CFG[kind]; this.hp = this.cfg.hp;
    this.build(lv);
    lv.scene.add(this.g);
    this.star = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture("#ffe066"), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
    this.star.scale.setScalar(2.4); this.star.visible = false; this.g.add(this.star);
  }

  private mat(color: string, o: Partial<THREE.MeshStandardMaterialParameters> = {}) { const m = new THREE.MeshStandardMaterial({ color, roughness: 0.4, ...o }); this.mats.push(m); return m; }
  private sph(r: number, mat: THREE.Material, x = 0, y = 0, z = 0, parent: THREE.Object3D = this.g) { const m = new THREE.Mesh(new THREE.SphereGeometry(r, 20, 14), mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; }

  private build(lv: Level) {
    const k = this.kind; void lv;
    const eye = (parent: THREE.Object3D, x: number, y: number, z: number, r = 0.4, pr = 0.2) => { const e = this.sph(r, stdMat("#fff"), x, y, z, parent); this.sph(pr, stdMat("#111"), 0, 0, r * 0.8, e); };
    this.body = new THREE.Group(); this.g.add(this.body);
    if (k === "chewy") {
      this.actor = makeFox(8.5); tintAnimal(this.actor, "#b0703c", "#3a1a00"); this.actor.play("Survey");
      this.body.add(this.actor.root);
      const b = this.sph(0.35, this.mat("#ffd23c", { emissive: "#ff9a00", emissiveIntensity: 0.6 }), 0, 3.6, 0, this.body); void b;
    } else if (k === "falcon") {
      this.actor = makeBird("stork", 5.5); tintAnimal(this.actor, "#ff7a3a", "#ff3a00"); Object.values(this.actor.actions)[0].play(); this.body.add(this.actor.root);
    } else if (k === "wako") {
      const m = this.mat("#ff6fb8", { roughness: 0.3, emissive: "#a01f78", emissiveIntensity: 0.2 });
      this.sph(2.1, m, 0, 2.2, 0, this.body).scale.set(1, 1.1, 1);
      eye(this.body, -0.8, 2.6, 1.8, 0.55, 0.28); eye(this.body, 0.8, 2.6, 1.8, 0.55, 0.28);
      const bow = this.sph(0.3, this.mat("#ffd23c"), 0, 4.3, 0, this.body); bow.scale.set(2, 0.6, 0.6);
      for (let i = 0; i < 8; i++) { const chain: THREE.Mesh[] = []; for (let j = 0; j < 8; j++) { const s = this.sph(0.62 - j * 0.055, m, 0, 0, 0, this.g); chain.push(s); } this.tent.push(chain); }
    } else if (k === "venomara") {
      const m = this.mat("#34d8e0", { roughness: 0.3, emissive: "#0a5a7a", emissiveIntensity: 0.3 }), m2 = this.mat("#a56bff", { roughness: 0.3 });
      this.sph(1.2, m, 0, 1.2, 0, this.body).scale.set(1, 0.9, 1.3);
      eye(this.body, -0.5, 1.7, 0.9, 0.3, 0.15); eye(this.body, 0.5, 1.7, 0.9, 0.3, 0.15);
      const tongue = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.8, 4), stdMat("#ff3a5a")); tongue.rotation.x = Math.PI / 2; tongue.position.set(0, 1.1, 1.8); this.body.add(tongue); this.parts.push(tongue);
      for (let i = 0; i < 18; i++) { const s = this.sph(1.0 - i * 0.04, i % 2 ? m : m2, 0, 0.9, -3, this.g); this.seg.push(s); }
    } else if (k === "leon") {
      const m = this.mat("#7ae04a", { roughness: 0.35, metalness: 0.2, transparent: true, emissive: "#1a5a0a", emissiveIntensity: 0.3 });
      this.sph(1.6, m, 0, 1.5, 0, this.body).scale.set(1.3, 0.95, 1.5);
      for (const s of [-1, 1]) { const stalk = this.sph(0.55, m, s * 1.0, 2.5, 1.0, this.body); this.sph(0.28, stdMat("#ffd23c", { emissive: "#ffb000", emissiveIntensity: 1 }), 0, 0, 0.35, stalk); }
      const tail = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.28, 10, 24), m); tail.position.set(0, 1.4, -2.3); this.body.add(tail);
      for (let i = 0; i < 6; i++) { const sp = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.6, 5), this.mat(["#ff6fa8", "#ffd23c"][i % 2])); sp.position.set(0, 2.55 - Math.abs(i - 2.5) * 0.08, 1.0 - i * 0.6); this.body.add(sp); }
      const gear = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.12, 6, 8), stdMat("#9aa4b8", { metalness: 0.8 })); gear.position.set(0, 2.5, -0.6); this.body.add(gear); this.parts.push(gear);
    } else {
      const m = this.mat("#3a1a6a", { roughness: 0.25, metalness: 0.3, emissive: "#6a1aff", emissiveIntensity: 0.35 });
      this.sph(2.8, m, 0, 3.0, 0, this.body);
      for (const s of [-1, 1]) { const h = new THREE.Mesh(new THREE.ConeGeometry(0.5, 2, 8), stdMat("#ffd9a8")); h.position.set(s * 1.8, 5.5, 0); h.rotation.z = -s * 0.45; this.body.add(h); eye(this.body, s * 1.1, 3.5, 2.4, 0.75, 0.38); this.sph(0.38, stdMat("#ff3a5a", { emissive: "#ff0030", emissiveIntensity: 2 }), s * 1.1, 3.5, 3.2, this.body); }
      const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.12, 6, 20, Math.PI), stdMat("#ff3a5a", { emissive: "#ff0030", emissiveIntensity: 1.2 })); mouth.position.set(0, 2.1, 2.6); mouth.rotation.z = Math.PI; this.body.add(mouth);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(4.2, 0.2, 8, 48), stdMat("#ff4fd8", { emissive: "#ff4fd8", emissiveIntensity: 1.5 })); ring.position.y = 3; ring.rotation.x = 1.3; this.body.add(ring); this.parts.push(ring);
      this.handL = this.sph(1.1, m, -4.6, 3, 0, this.g); this.handR = this.sph(1.1, m, 4.6, 3, 0, this.g);
    }
  }

  onSlam(lv: Level, p: THREE.Vector3, r: number) {
    if (this.state !== "stunned") return;
    if (Math.hypot(p.x - this.pos.x, p.z - this.pos.z) < r + this.cfg.R) this.damage(lv);
  }

  damage(lv: Level) {
    if (this.invuln > 0 || this.state === "dead") return;
    this.hp--; this.invuln = 1.0; sfx("bosshit"); lv.shake = 0.6; this.flash = 0.6;
    lv.burst(this.pos.clone().add(new V(0, this.cfg.Hh, 0)), "#ffe066", 40, 8, 1.0, 0.5, 6);
    lv.burst(this.pos.clone().add(new V(0, this.cfg.Hh * 0.6, 0)), "#ffffff", 24, 6, 0.8, 0.4, 4);
    lv.ev.onBossHp(this.hp, this.cfg.hp);
    for (let i = 0; i < 6; i++) lv.spawnLoose(this.pos.clone().add(new V(0, this.cfg.Hh, 0)));
    if (this.hp <= 0) { this.state = "dead"; this.t = 0; sfx("boom"); }
    else { this.state = "hurt"; this.t = 0; this.phase = this.cfg.hp - this.hp; }
  }

  private setAnim(name: string, speed = 1) { if (this.actor?.actions[name]) this.actor.play(name, { speed, fade: 0.25 }); }

  update(dt: number, t: number, lv: Level) {
    const p = lv.player; const H = lv.arenaHalf - 2.6;
    this.t += dt; this.invuln = Math.max(0, this.invuln - dt); this.flash = Math.max(0, this.flash - dt);
    const toP = new V(p.pos.x - this.pos.x, 0, p.pos.z - this.pos.z); const dist = toP.length(); if (dist > 0.001) toP.divideScalar(dist);
    const k = this.kind; const c = this.cfg;
    const phaseSpeed = 1 + this.phase * 0.14;
    switch (this.state) {
      case "intro": this.hoverY = c.hover + Math.sin(this.t * 3) * 0.1; this.yaw = Math.atan2(toP.x, toP.z); if (this.t > 2.6) { this.state = "chase"; this.t = 0; this.atkT = 1.2; lv.ev.onBossHp(this.hp, c.hp); } if (k === "chewy") this.setAnim("Survey"); break;
      case "chase": {
        this.setAnim(k === "chewy" ? "Walk" : "Run", 1.1);
        this.dir.lerp(toP, Math.min(1, dt * 3)).normalize();
        const sp = c.speed * phaseSpeed;
        this.pos.x += this.dir.x * sp * dt; this.pos.z += this.dir.z * sp * dt; this.yaw = Math.atan2(this.dir.x, this.dir.z);
        this.atkT -= dt;
        if (this.atkT <= 0) { this.atkT = 2.0 / phaseSpeed; this.attack(lv, c.attacks[Math.floor(Math.random() * c.attacks.length)]); }
        if (this.t > c.chase / Math.sqrt(phaseSpeed)) { this.state = "telegraph"; this.t = 0; this.flash = 0.9; sfx("shoot"); }
        this.hoverY = c.hover + Math.sin(t * 3) * 0.15;
        break;
      }
      case "telegraph": {
        this.yaw = Math.atan2(toP.x, toP.z); this.dir.copy(toP); this.hoverY = c.hover * 0.5 + (k === "falcon" ? 3 : 0);
        this.flash = 0.2; if (this.t > 0.85) { this.state = "charge"; this.t = 0; sfx("boom"); } break;
      }
      case "charge": {
        const sp = (k === "falcon" ? 17 : 15) * phaseSpeed;
        this.pos.x += this.dir.x * sp * dt; this.pos.z += this.dir.z * sp * dt; this.setAnim("Run", 1.8);
        if (k === "falcon") this.hoverY = Math.max(0.2, c.hover * (1 - this.t * 1.4));
        if (Math.random() < 0.6) lv.burst(new V(this.pos.x, 0.3, this.pos.z), "#ffe9a0", 1, 1.5, 0.5, 0.7, 0, 0.2);
        const hit = Math.abs(this.pos.x) > H || Math.abs(this.pos.z) > H;
        if (hit) { this.pos.x = THREE.MathUtils.clamp(this.pos.x, -H, H); this.pos.z = THREE.MathUtils.clamp(this.pos.z, -H, H); this.state = "stunned"; this.t = 0; sfx("boom"); lv.shake = 0.9; lv.burst(new V(this.pos.x, 1, this.pos.z), "#ffffff", 30, 7, 0.9, 0.6, 5); }
        else if (this.t > 1.5) { this.state = "chase"; this.t = 0; this.atkT = 0.6; }
        break;
      }
      case "stunned": {
        this.setAnim(k === "chewy" ? "Survey" : "Walk", 0.3); this.hoverY = k === "falcon" || k === "nebulax" || k === "wako" ? 0.3 : 0;
        this.yaw += dt * 0.4;
        this.star.visible = true; this.star.position.set(0, c.Hh + 1.3 + Math.sin(t * 6) * 0.2, 0); (this.star.material as THREE.SpriteMaterial).opacity = 0.7 + Math.sin(t * 12) * 0.3;
        if (Math.random() < 0.2) lv.burst(this.pos.clone().add(new V(Math.cos(t * 5) * 1.5, c.Hh + 0.6, Math.sin(t * 5) * 1.5)), "#ffe066", 1, 1, 0.6, 0.4, 0, 0);
        if (this.t > 5.2) { this.state = "chase"; this.t = 0; this.atkT = 0.8; }
        this.checkHit(lv, p);
        break;
      }
      case "hurt": this.hoverY = c.hover * 0.5; if (this.t > 1.4) { this.state = "chase"; this.t = 0; this.atkT = 1.0; } this.pos.x -= toP.x * dt * 2; this.pos.z -= toP.z * dt * 2; break;
      case "dead": {
        this.g.scale.multiplyScalar(1 - dt * 0.45); this.g.rotation.y += dt * 12;
        if (Math.random() < 0.5) lv.burst(this.pos.clone().add(new V((Math.random() - 0.5) * 4, 1 + Math.random() * 3, (Math.random() - 0.5) * 4)), ["#ffd23c", "#ff6fa8", "#4fd8ff", "#fff"][Math.floor(Math.random() * 4)], 14, 6, 0.9, 0.5, 4);
        if (this.t > 2.4 && this.g.visible) { this.g.visible = false; for (let i = 0; i < 45; i++) lv.spawnLoose(new V(this.pos.x, 2, this.pos.z)); lv.spawnVip(new V(0, 0, 0)); sfx("win"); }
        break;
      }
    }
    if (this.state !== "stunned") this.star.visible = false;
    // clamp to arena
    this.pos.x = THREE.MathUtils.clamp(this.pos.x, -H, H); this.pos.z = THREE.MathUtils.clamp(this.pos.z, -H, H);
    // contact damage
    if (this.state !== "dead" && this.state !== "intro" && this.state !== "stunned" && this.state !== "hurt" && p.dead <= 0) {
      if (dist < c.R + 0.35 && p.pos.y < this.hoverY + c.Hh) {
        if (p.vel.y < -2 && p.pos.y > this.hoverY + c.Hh * 0.8) { p.vel.y = 12; sfx("stomp"); } else p.hurt(this.pos);
      }
      if (this.seg.length) for (let i = 4; i < this.seg.length; i += 2) { const s = this.seg[i]; if (Math.hypot(p.pos.x - s.position.x, p.pos.z - s.position.z) < 0.9 && p.pos.y < 1.7) p.hurt(s.position); }
    }
    // marks (rain)
    for (const m of this.marks) {
      m.t += dt; const k2 = Math.min(1, m.t / 1.0); m.mesh.scale.setScalar(0.4 + k2 * 0.6); (m.mesh.material as THREE.MeshBasicMaterial).opacity = 0.35 + Math.sin(m.t * 20) * 0.15;
      if (m.t > 1.0 && m.mesh.visible) { m.mesh.visible = false; sfx("boom"); lv.burst(m.pos.clone().add(new V(0, 0.4, 0)), "#ff8a3a", 24, 6, 0.8, 0.6, 6); lv.burst(m.pos, "#ffe066", 12, 4, 0.6, 0.4, 4); lv.shake = Math.max(lv.shake, 0.3); if (Math.hypot(p.pos.x - m.pos.x, p.pos.z - m.pos.z) < 1.9 && p.pos.y < 1.8) p.hurt(m.pos); m.mesh.removeFromParent(); }
    }
    this.marks = this.marks.filter((m) => m.t <= 1.05);
    // shock rings
    for (const r of this.rings) {
      r.r += dt * 8.5; r.mesh.scale.setScalar(r.r); (r.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.8 - r.r / 30);
      const d = Math.hypot(p.pos.x - r.mesh.position.x, p.pos.z - r.mesh.position.z);
      if (!r.hit && Math.abs(d - r.r) < 0.75 && p.pos.y < r.mesh.position.y + 0.55 && p.dead <= 0) { r.hit = true; p.hurt(r.mesh.position); }
      if (r.r > 26) r.mesh.removeFromParent();
    }
    this.rings = this.rings.filter((r) => r.r <= 26);
    this.animate(t, dt);
    // apply transform
    this.g.position.set(this.pos.x, this.hoverY, this.pos.z);
    this.body.rotation.y = this.yaw;
  }

  private checkHit(lv: Level, p: import("./player").Player) {
    if (this.invuln > 0 || p.dead > 0) return;
    const c = this.cfg; const d = Math.hypot(p.pos.x - this.pos.x, p.pos.z - this.pos.z);
    if (p.vel.y < -1 && d < c.R + 0.5 && p.pos.y > this.hoverY + c.Hh * 0.55 && p.pos.y < this.hoverY + c.Hh + 1.2) { p.vel.y = 13; this.damage(lv); return; }
    if (p.spinT > 0 && d < c.R + (p.gadget === "gloves" ? 2.8 : 1.9) && p.pos.y < this.hoverY + c.Hh + 0.6) this.damage(lv);
  }

  private attack(lv: Level, kind: "shock" | "shoot" | "rain") {
    const p = lv.player;
    if (kind === "shock") {
      const m = new THREE.Mesh(new THREE.RingGeometry(0.92, 1, 56), new THREE.MeshBasicMaterial({ color: "#ff4a4a", transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
      m.rotation.x = -Math.PI / 2; m.position.set(this.pos.x, 0.1, this.pos.z); lv.scene.add(m); this.rings.push({ r: 0.5, mesh: m, hit: false }); sfx("boom"); lv.shake = 0.4;
    } else if (kind === "shoot") {
      const o = new V(this.pos.x, this.hoverY + this.cfg.Hh * 0.6, this.pos.z);
      for (let i = -1; i <= 1; i++) { const d = new V(p.pos.x - o.x, 0, p.pos.z - o.z).normalize(); d.applyAxisAngle(new V(0, 1, 0), i * 0.28); lv.fireBall(o, d.setY(0.05), 9, ["#ff6a2a", "#ff3aa8", "#9a4aff"][this.kind.length % 3]); }
      sfx("shoot");
    } else {
      for (let i = 0; i < 5; i++) {
        const a = Math.random() * 6.28, r = i === 0 ? 0 : 1.5 + Math.random() * 5;
        const pos = new V(THREE.MathUtils.clamp(p.pos.x + Math.cos(a) * r, -lv.arenaHalf + 1, lv.arenaHalf - 1), 0.08, THREE.MathUtils.clamp(p.pos.z + Math.sin(a) * r, -lv.arenaHalf + 1, lv.arenaHalf - 1));
        const mesh = new THREE.Mesh(new THREE.CircleGeometry(1.9, 28), new THREE.MeshBasicMaterial({ color: "#ff3a3a", transparent: true, opacity: 0.4, depthWrite: false })); mesh.rotation.x = -Math.PI / 2; mesh.position.copy(pos); lv.scene.add(mesh);
        this.marks.push({ pos, t: -i * 0.12, mesh });
      }
    }
  }

  private animate(t: number, dt: number) {
    this.actor?.update(dt);
    const k = this.kind;
    const flashOn = this.flash > 0 && Math.floor(t * 18) % 2 === 0;
    const setEm = (m: THREE.MeshStandardMaterial, v: number) => { m.emissiveIntensity = v; };
    for (const m of this.mats) { if (!m.emissive) continue; setEm(m, flashOn ? 2.5 : 0.35); if (flashOn) m.emissive.set("#ff2a2a"); }
    if (this.actor) this.actor.model.traverse((o) => { const m = o as THREE.Mesh; if (m.isMesh) { const mt = m.material as THREE.MeshStandardMaterial; if (mt.emissive) { mt.emissiveIntensity = flashOn ? 2 : 0.3; } } });
    if (k === "wako") {
      this.body.position.y = Math.sin(t * 2) * 0.15;
      this.tent.forEach((chain, i) => { const a = (i / 8) * Math.PI * 2 + this.yaw; chain.forEach((s, j) => { const rr = 1.2 + j * 0.62; const wig = Math.sin(t * 3 + i * 0.8 - j * 0.7) * 0.35 * (j / 7 + 0.3); const aa = a + wig; s.position.set(Math.sin(aa) * rr, Math.max(0.55 - j * 0.04, 1.4 - j * 0.28 + Math.sin(t * 4 - j) * 0.15 + (this.state === "charge" ? 0.6 : 0)) - this.hoverY * 0.0, Math.cos(aa) * rr); }); });
    } else if (k === "venomara") {
      const last = this.trail[0];
      if (!last || last.distanceTo(this.pos) > 0.45) { this.trail.unshift(this.pos.clone()); if (this.trail.length > 70) this.trail.pop(); }
      this.seg.forEach((s, i) => { const tp = this.trail[Math.min(this.trail.length - 1, (i + 1) * 2)] ?? this.pos; s.position.set(tp.x + Math.sin(t * 3 + i) * 0.15, 0.9 - i * 0.015, tp.z); s.visible = this.state !== "dead" || this.g.visible; });
      this.body.position.y = Math.sin(t * 5) * 0.08; if (this.parts[0]) this.parts[0].position.z = 1.8 + Math.sin(t * 14) * 0.25;
      this.seg.forEach((s) => { if (this.g.scale.x < 0.99) s.scale.setScalar(this.g.scale.x); });
    } else if (k === "leon") {
      const m = this.mats[0]; const vis = this.state === "chase" ? 0.28 + (Math.sin(t * 3) * 0.5 + 0.5) * 0.12 : 1; m.opacity += (vis - m.opacity) * Math.min(1, dt * 6);
      if (this.parts[0]) this.parts[0].rotation.z += dt * 2; this.body.position.y = Math.abs(Math.sin(t * (this.state === "chase" ? 7 : 2))) * 0.25;
    } else if (k === "nebulax") {
      if (this.parts[0]) this.parts[0].rotation.z += dt * 0.8;
      if (this.handL && this.handR) { const a = t * 1.6; const slam = this.state === "telegraph" ? 1 : 0; this.handL.position.set(-4.6 + Math.sin(a) * 0.4, 3 + Math.sin(a * 1.3) * 0.6 - slam * 2.5, Math.cos(a) * 0.6 + 1.2); this.handR.position.set(4.6 - Math.sin(a) * 0.4, 3 + Math.cos(a * 1.3) * 0.6 - slam * 2.5, Math.cos(a + 1) * 0.6 + 1.2); }
      this.body.position.y = Math.sin(t * 1.8) * 0.2;
    } else if (k === "falcon" && this.actor) {
      this.body.position.y = 1.5 + Math.sin(t * 6) * 0.1;
    } else if (k === "chewy") {
      this.body.position.y = this.state === "chase" ? Math.abs(Math.sin(t * 6)) * 0.15 : 0;
    }
  }
}
