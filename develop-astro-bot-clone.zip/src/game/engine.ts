import * as THREE from "three";
import { Gfx, Sky, Lighting, Particles } from "./world";
import { loadAll, makeRobot, makeSpeeder, makePS5, makeCoin, Actor } from "./assets";
import { Level } from "./level";
import { Player, syncUI } from "./player";
import { GalaxyMap } from "./galaxymap";
import { input } from "./input";
import { initAudio, setMusic, stopMusic, sfx, applyVolumes } from "./audio";
import { ui, setUI, emit, persist, chooseSlot, planetLock, totalPuzzles, totalBots, addToast } from "./store";
import { THEMES, planetById, galaxyById, botDef, seedOf, GATCHA_ITEMS, HUB_UNLOCKS, type BotDef } from "./data";

const V = THREE.Vector3;

// ───────── Title scene ─────────
class TitleScene {
  scene = new THREE.Scene(); sky: Sky; light: Lighting; fx: Particles; astro: Actor; t = 0; bots: Actor[] = []; coins: THREE.Object3D[] = [];
  constructor(gfx: Gfx) {
    const th = THEMES.boss;
    this.sky = new Sky(this.scene, th, 5); this.light = new Lighting(this.scene, th, gfx.env); this.fx = new Particles(this.scene);
    const g = new THREE.Group();
    const top = new THREE.Mesh(new THREE.CylinderGeometry(7, 6.6, 0.8, 40), new THREE.MeshStandardMaterial({ color: "#6fe06a", roughness: 0.7 })); top.receiveShadow = true; top.castShadow = true; g.add(top);
    const rock = new THREE.Mesh(new THREE.ConeGeometry(6.6, 8, 14), new THREE.MeshStandardMaterial({ color: "#9a6a44", roughness: 0.9, flatShading: true })); rock.rotation.x = Math.PI; rock.position.y = -4.4; g.add(rock);
    g.position.y = -0.4; this.scene.add(g);
    const ps5 = makePS5(); ps5.scale.setScalar(0.42); ps5.position.set(-4.5, 0, -5.5); ps5.rotation.set(0.1, 0.6, -0.15); this.scene.add(ps5);
    this.astro = makeRobot({ outfit: ui.save?.outfit ?? "default", height: 1.5 }); this.astro.root.position.set(0, 0, 1.5); this.astro.play("Wave"); this.scene.add(this.astro.root);
    const sp = makeSpeeder(ui.save?.speeder ?? "white"); sp.position.set(3.6, 1.1, 1); sp.rotation.y = -0.6; sp.scale.setScalar(1.2); this.scene.add(sp);
    const cols = ["#ff5a5a", "#5ae068", "#ffd23c", "#4f8bff"]; const hats = ["party", "cap", "crown", "antenna"];
    cols.forEach((c, i) => { const b = makeRobot({ body: c, hat: hats[i], hatColor: "#fff", height: 0.9 }); b.play(["Dance", "Wave", "ThumbsUp", "Dance"][i]); const a = -1.2 + i * 0.9; b.root.position.set(Math.sin(a) * 4.4 + 1, 0, 1.5 + Math.cos(a) * 2.4 - 1); b.root.rotation.y = a + 3; this.scene.add(b.root); this.bots.push(b); });
    for (let i = 0; i < 18; i++) { const c = makeCoin(); const a = (i / 18) * 6.28; c.position.set(Math.cos(a) * 7.5, 2.8 + Math.sin(i) * 0.9, Math.sin(a) * 7.5 - 1); this.scene.add(c); this.coins.push(c); }
    this.light.sun.castShadow = true;
  }
  update(dt: number, cam: THREE.PerspectiveCamera, slots: boolean) {
    this.t += dt; this.astro.update(dt); this.bots.forEach((b) => b.update(dt)); this.fx.update(dt);
    this.coins.forEach((c, i) => { c.rotation.y += dt * 3; c.position.y += Math.sin(this.t * 2 + i) * 0.004; });
    this.light.follow(new V(0, 0, 0));
    const a = this.t * 0.12 + 0.3; const R = slots ? 11 : 9.5;
    cam.position.set(Math.sin(a) * R * 0.6 + 1, 2.4 + Math.sin(this.t * 0.3) * 0.2, 1.5 + Math.cos(a) * R * 0.4 + R * 0.55);
    cam.lookAt(0.5, 1.4, 0); cam.fov = 52; cam.updateProjectionMatrix();
    this.sky.update(cam, this.t);
    if (Math.random() < 0.05) this.fx.emit(new V((Math.random() - 0.5) * 8, 3, (Math.random() - 0.5) * 8), ["#ffd23c", "#4fd8ff", "#ff6fa8"][Math.floor(Math.random() * 3)], 3, 1, 1.5, 0.4, -0.5, 0.8);
  }
}

type Mode = "boot" | "title" | "hub" | "map" | "level";

class Engine {
  canvas!: HTMLCanvasElement;
  gfx!: Gfx;
  mode: Mode = "boot";
  titleScene!: TitleScene;
  level: Level | null = null;
  player: Player | null = null;
  map: GalaxyMap | null = null;
  last = 0; hudAcc = 0; t = 0;
  cam = { yaw: Math.PI, pitch: 0.4, dist: 7.6, target: new V(), idle: 0, intro: 0, shake: 0 };
  dying = false; resumeAt = 0; bannerT = 0; hintT = 0; photo = false; botUnlockShown = false;
  vortexFound = false;
  modal = false;
  started = false;

  async init(canvas: HTMLCanvasElement) {
    if (this.started) return; this.started = true;
    this.canvas = canvas; input.attach(canvas);
    this.gfx = new Gfx(canvas);
    await loadAll((p) => setUI({ loading: p }));
    this.titleScene = new TitleScene(this.gfx);
    this.mode = "title"; setUI({ ready: true, screen: "title" });
    this.last = performance.now();
    requestAnimationFrame(this.loop);
  }

  loop = (now: number) => {
    requestAnimationFrame(this.loop);
    const raw = Math.min(0.1, (now - this.last) / 1000); this.last = now;
    const dt = Math.min(raw, 1 / 30);
    this.t += dt;
    input.update(dt);
    try { this.tick(dt); } catch (e) { console.error(e); }
    this.hudAcc += dt;
    if (this.hudAcc > 0.066) { this.hudAcc = 0; this.pushHud(); }
  };

  private pushHud() {
    if (this.mode === "level" || this.mode === "hub") {
      const p = this.player; if (p) { syncUI(p); }
      if (this.level) { ui.time = this.level.time; ui.runCoins = this.level.runCoins; ui.gadget = p?.gadget ?? "none"; }
      if (ui.banner && performance.now() - ui.banner.t > 3400) ui.banner = null;
      if (ui.toast && performance.now() - ui.toast.t > 3000) ui.toast = null;
      emit();
    } else if (this.mode === "map") { if (ui.toast && performance.now() - ui.toast.t > 3000) ui.toast = null; emit(); }
  }

  private tick(dt: number) {
    const gfx = this.gfx;
    switch (this.mode) {
      case "title": {
        this.titleScene.update(dt, gfx.camera, ui.screen === "slots");
        gfx.render(this.titleScene.scene); break;
      }
      case "map": {
        const m = this.map!;
        if (!ui.paused) m.update(dt);
        if (m.mode === "flight") { if (input.jumpP || input.was("Enter")) this.dive(); }
        gfx.render(m.scene); break;
      }
      case "hub": case "level": {
        const lv = this.level!, p = this.player!;
        if (input.startP && !ui.paused && performance.now() - this.resumeAt > 250 && ui.screen !== "results" && !this.modal && ui.screen !== "credits") { if (this.photo) this.exitPhoto(); else this.pause(true); }
        const active = !ui.paused && ui.screen !== "results";
        if (active) this.stepLevel(dt);
        else { p.syncVisual(0); }
        this.updateCamera(dt, active);
        lv.sky.update(gfx.camera, this.t);
        gfx.render(lv.scene);
        break;
      }
    }
  }

  private stepLevel(dt: number) {
    const lv = this.level!, p = this.player!;
    const canControl = !this.modal && !this.photo && !lv.finished && p.dead <= 0 && this.cam.intro <= 0.3;
    const n = Math.max(1, Math.ceil(dt / (1 / 60)));
    const sdt = dt / n;
    for (let i = 0; i < n; i++) {
      p.update(sdt, this.cam.yaw, canControl);
      lv.update(sdt, this.t + i * sdt);
    }
    // death / respawn flow
    if (p.dead > 0) this.dying = true;
    else if (this.dying) { this.dying = false; lv.runCoins = lv.cpCoins; p.respawn(lv.cpPos.clone()); this.cam.yaw = lv.nearestPath(p.pos).yaw; this.cam.intro = 0; this.shakeCam(0.2); setUI({ runCoins: lv.runCoins }); }
    // hub interactions
    if (this.mode === "hub") this.hubInteract(canControl);
    if (this.mode === "hub") { this.hintT += dt; if (this.hintT > 14 && ui.hint) ui.hint = ""; }
    if (this.mode === "level") {
      this.hintT += dt;
      if (this.hintT > 9 && ui.hint) ui.hint = "";
    }
    if (lv.shake > 0) { this.cam.shake = Math.max(this.cam.shake, lv.shake); lv.shake = 0; }
  }

  private shakeCam(v: number) { this.cam.shake = Math.max(this.cam.shake, v); }

  private hubInteract(canControl: boolean) {
    const lv = this.level!, p = this.player!;
    let best: typeof lv.interact[number] | null = null; let bd = 1e9;
    for (const it of lv.interact) { const d = Math.hypot(it.pos.x - p.pos.x, it.pos.z - p.pos.z); if (d < it.r && d < bd) { best = it; bd = d; } }
    const label = best ? (best.locked ? `🔒 ${best.label} — ${best.locked}` : `△  ${best.label}`) : "";
    if (ui.prompt !== label) ui.prompt = label;
    if (best && canControl && input.interactP) {
      if (best.locked) { sfx("back"); addToast(best.locked); } else { sfx("ok"); best.action(); }
    }
    if (canControl && input.was("KeyB")) { sfx("ok"); setUI({ screen: "collection" }); this.modal = true; }
  }

  // ───── camera ─────
  private updateCamera(dt: number, active: boolean) {
    const c = this.cam, p = this.player!, lv = this.level!, cam = this.gfx.camera;
    const boss = lv.boss;
    if (active || this.photo) {
      const ic = input.cam;
      const inv = ui.settings.invertY ? -1 : 1;
      if (!this.modal || this.photo) { c.yaw -= ic.x; c.pitch = THREE.MathUtils.clamp(c.pitch + ic.y * inv, 0.05, 1.25); }
      c.dist = THREE.MathUtils.clamp(c.dist + input.wheel * 0.6, 4, 16); input.wheel = 0;
      const manual = Math.abs(ic.x) + Math.abs(ic.y) > 0.0005;
      c.idle = manual ? 0 : c.idle + dt;
      // auto-yaw towards the path direction
      if (!boss && this.mode === "level" && c.idle > 1.2 && Math.hypot(p.vel.x, p.vel.z) > 2 && !this.photo) {
        const tgt = lv.nearestPath(p.pos).yaw; let d = tgt - c.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); c.yaw += d * Math.min(1, dt * 0.7);
      }
    }
    if (this.photo) { c.dist = 9; }
    // target
    const tgt = new V(p.pos.x, p.pos.y + 1.0, p.pos.z);
    if (boss && boss.state !== "dead") tgt.lerp(new V(boss.pos.x, 1.5, boss.pos.z), 0.28);
    c.target.x += (tgt.x - c.target.x) * Math.min(1, dt * 8); c.target.z += (tgt.z - c.target.z) * Math.min(1, dt * 8);
    c.target.y += (tgt.y - c.target.y) * Math.min(1, dt * (p.onGround ? 4 : 2.2));
    if (c.intro > 0) c.intro = Math.max(0, c.intro - dt);
    const introK = c.intro > 0 ? c.intro / 2.2 : 0; const e = introK * introK;
    const baseDist = boss ? 15 : this.mode === "hub" ? 9.5 : c.dist; const basePitch = boss ? 0.62 : c.pitch;
    const dist = baseDist + e * 22, pitch = basePitch + e * 0.6;
    const yaw = c.yaw + e * 1.6;
    let cx = c.target.x + Math.sin(yaw) * Math.cos(pitch) * dist, cy = c.target.y + Math.sin(pitch) * dist, cz = c.target.z + Math.cos(yaw) * Math.cos(pitch) * dist;
    // keep camera above ground beneath it
    const gy = p.groundBelow(cx, cz, cy + 3); if (gy !== null && cy < gy + 0.9) cy = gy + 0.9;
    c.shake = Math.max(0, c.shake - dt * 1.6);
    if (c.shake > 0) { cx += (Math.random() - 0.5) * c.shake * 0.5; cy += (Math.random() - 0.5) * c.shake * 0.5; cz += (Math.random() - 0.5) * c.shake * 0.5; }
    cam.position.set(cx, cy, cz); cam.lookAt(c.target.x, c.target.y + 0.2, c.target.z);
    const pcam = cam as THREE.PerspectiveCamera; const wantFov = p.boosting ? 70 : 58; pcam.fov += (wantFov - pcam.fov) * Math.min(1, dt * 4); pcam.updateProjectionMatrix();
  }

  // ───── transitions ─────
  transition(fn: () => void) {
    setUI({ fade: true });
    setTimeout(() => { try { fn(); } catch (e) { console.error(e); } setTimeout(() => setUI({ fade: false }), 120); }, 320);
  }

  pressStart() { initAudio(); applyVolumes(); setMusic(60, "major", "menu", 3); sfx("ok"); setUI({ screen: "slots" }); }
  selectSlot(n: number) { sfx("ok"); chooseSlot(n); this.transition(() => this.enterHub(true)); }
  backToTitle() { this.transition(() => { this.disposeLevel(); this.mode = "title"; ui.save = null; setUI({ screen: "title", paused: false }); setMusic(60, "major", "menu", 3); }); }

  private disposeLevel() { this.level?.dispose(); this.level = null; this.player = null; this.map = null; this.photo = false; this.modal = false; }

  private makePlayer() {
    const p = new Player(ui.save?.outfit ?? "default"); return p;
  }

  enterHub(first = false) {
    this.disposeLevel();
    const save = ui.save!;
    const lv = new Level(this.gfx, null, save, "meadow");
    this.level = lv;
    const rescued: BotDef[] = []; for (const [pid, idxs] of Object.entries(save.bots)) for (const i of idxs) rescued.push(botDef(pid, i));
    const pz = totalPuzzles(save); const ua = ui.settings.unlockAll;
    lv.buildHub({ gatcha: ua || pz >= HUB_UNLOCKS[0].need, garage: ua || pz >= HUB_UNLOCKS[1].need, safari: ua || pz >= HUB_UNLOCKS[2].need }, (id) => this.hubAction(id), rescued, save.vips, pz);
    lv.ev = { onCoin: () => 0, onBot: () => 0, onPuzzle: () => 0, onGoal: () => 0, onVortex: () => 0, onCheckpoint: () => 0, onToast: addToast, onBossHp: () => 0 };
    const p = this.makePlayer(); this.player = p; lv.attachPlayer(p); p.teleport(lv.spawn.clone(), lv.spawnYaw);
    this.cam.yaw = 0; this.cam.pitch = 0.36; this.cam.dist = 9; this.cam.target.copy(p.pos); this.cam.intro = first ? 2.2 : 0.01;
    lv.runCoins = 0;
    this.mode = "hub"; this.modal = false; this.photo = false;
    setUI({ screen: "hub", paused: false, prompt: "", banner: first ? { title: "CRASH SITE", sub: "Your PS5 mothership crashed. Rescue your bots!", t: performance.now() } : null, hint: first ? "Move: WASD / Left Stick   •   Jump: Space / ✕   •   Spin: J / □   •   Interact: E / △" : "", planetId: "" });
    this.hintT = 0;
    setMusic(62, "major", "hub", 11);
  }

  private hubAction(id: string) {
    if (id === "map") { this.openGalaxies(); }
    else if (id === "gatcha") { this.modal = true; setUI({ screen: "gatcha", gatchaResult: null }); }
    else if (id === "garage") { this.modal = true; setUI({ screen: "garage" }); }
    else if (id === "safari") { this.photo = true; this.modal = true; setUI({ screen: "safari", prompt: "" }); }
  }
  exitPhoto() { this.photo = false; this.modal = false; setUI({ screen: "hub" }); sfx("back"); }
  closeModal() { this.modal = false; sfx("back"); setUI({ screen: "hub" }); if (ui.save) { persist(); } }
  refreshHub() { const keep = ui.screen; this.enterHub(false); this.modal = true; setUI({ screen: keep }); }

  // ───── galaxy map ─────
  openGalaxies() {
    this.transition(() => {
      const save = ui.save!; this.disposeLevel();
      const sp = save.speeder; this.map = new GalaxyMap(this.gfx, sp, save.outfit);
      this.map.selected = Math.max(0, ["gorilla", "tentacle", "serpent", "camo", "feather", "lost", "dejavu", "speedway", "void"].indexOf(ui.mapGalaxy));
      this.mode = "map"; setUI({ screen: "galaxies", paused: false, prompt: "", mapNear: "" });
      setMusic(57, "lyd", "menu", 8);
    });
  }
  selectGalaxyIndex(i: number) { this.map?.selectGalaxy(i); }
  chooseGalaxy(gid: string) { this.transition(() => { this.map!.enterGalaxy(gid, ui.planetId && planetById(ui.planetId)?.galaxy === gid ? ui.planetId : undefined); setUI({ screen: "map", mapGalaxy: gid, mapNear: "" }); setMusic(59, "lyd", "game", 4); }); }
  backFromMap() {
    if (this.map?.mode === "flight") { this.transition(() => { this.map!.backToGalaxies(); setUI({ screen: "galaxies", mapNear: "" }); setMusic(57, "lyd", "menu", 8); }); }
    else { this.transition(() => this.enterHub(false)); }
  }
  dive() {
    const id = ui.mapNear; if (!id) return;
    const lock = planetLock(id);
    if (lock) { sfx("back"); addToast(lock); return; }
    sfx("warp"); this.startPlanet(id);
  }

  // ───── planets ─────
  startPlanet(id: string) {
    this.transition(() => {
      const pl = planetById(id); const save = ui.save!;
      this.disposeLevel();
      const lv = new Level(this.gfx, pl, save);
      this.level = lv; this.vortexFound = false;
      const p = this.makePlayer(); this.player = p;
      lv.ev = {
        onCoin: () => { ui.runCoins = lv.runCoins; ui.coinPulse++; },
        onBot: (i) => { const arr = [...ui.runBots]; arr[i] = true; ui.runBots = arr; addToast(`Bot rescued! ${arr.filter(Boolean).length}/${arr.length}`); },
        onPuzzle: (i) => { const arr = [...ui.runPuzzles]; arr[i] = true; ui.runPuzzles = arr; addToast("Puzzle Piece found!"); },
        onGoal: (vip) => this.finishRun(vip),
        onVortex: () => { this.vortexFound = true; addToast("Vortex found! Lost Galaxy planets are opening…"); },
        onCheckpoint: () => addToast("Checkpoint!"),
        onToast: addToast,
        onBossHp: (hp, max) => setUI({ bossHp: hp, bossMax: max }),
      };
      lv.attachPlayer(p); p.teleport(lv.spawn.clone(), lv.spawnYaw);
      if (pl.gadget && pl.gadget !== "none") { /* given at pickup */ }
      this.cam.yaw = lv.path[0]?.yaw ?? 0; this.cam.pitch = pl.kind === "boss" ? 0.62 : 0.4; this.cam.dist = 7.6; this.cam.target.copy(p.pos); this.cam.intro = 2.2; this.cam.shake = 0;
      lv.runCoins = 0; lv.cpCoins = 0; this.dying = false; this.hintT = 0; this.modal = false;
      this.mode = "level";
      const g = galaxyById(pl.galaxy);
      setUI({
        screen: "level", paused: false, planetId: id, runCoins: 0, runBots: lv.botFound.slice(), runPuzzles: lv.puzzleFound.slice(), gadget: "none", time: 0, results: null,
        banner: { title: pl.name, sub: g.name, t: performance.now() }, toast: null, prompt: "", bossHp: 0, bossMax: 0, bossName: pl.boss ? lv.boss!.cfg.name : "",
        hint: !save.seenIntro && pl.id === "sky-garden" ? "Move: WASD / Left Stick  •  Jump: Space / ✕ (hold to hover)  •  Spin: J / □  •  Slam: C / ○ in air  •  Camera: Mouse drag / Arrows / Right Stick" : "",
      });
      save.seenIntro = true;
      const th = THEMES[pl.theme];
      setMusic(th.music, th.scale, pl.boss ? "boss" : "game", seedOf(pl.id));
    });
  }

  private finishRun(vip?: string) {
    const lv = this.level!, pl = lv.planet!, save = ui.save!;
    const gotBots = lv.botFound.filter(Boolean).length;
    const newBotIdx: number[] = []; lv.botFound.forEach((f, i) => { if (f) newBotIdx.push(i); });
    save.bots[pl.id] = Array.from(new Set([...(save.bots[pl.id] ?? []), ...newBotIdx]));
    const puz: number[] = []; lv.puzzleFound.forEach((f, i) => { if (f) puz.push(i); });
    save.puzzles[pl.id] = Array.from(new Set([...(save.puzzles[pl.id] ?? []), ...puz]));
    const prev = save.cleared[pl.id];
    const time = lv.time; const newBest = !prev || time < prev.time;
    save.cleared[pl.id] = { time: newBest ? time : prev.time, coins: Math.max(prev?.coins ?? 0, lv.runCoins) };
    save.coins += lv.runCoins;
    if (vip && !save.vips.includes(vip)) save.vips.push(vip);
    if (this.vortexFound && !save.vortex.includes(pl.id)) save.vortex.push(pl.id);
    persist();
    sfx("win");
    setUI({ screen: "results", results: { planetId: pl.id, coins: lv.runCoins, bots: gotBots, botsTotal: pl.bots, puzzles: puz.length, puzzleTotal: pl.puzzle, time, newBest, vip, vortex: this.vortexFound, par: pl.timer } });
  }

  closeResults() {
    const pl = this.level?.planet; sfx("ok");
    if (pl?.kind === "credits") { setUI({ screen: "credits" }); return; }
    this.transition(() => {
      const save = ui.save!; this.disposeLevel();
      this.map = new GalaxyMap(this.gfx, save.speeder, save.outfit); this.mode = "map";
      this.map.enterGalaxy(pl!.galaxy, pl!.id); setUI({ screen: "map", mapGalaxy: pl!.galaxy, results: null, mapNear: "", paused: false, planetId: pl!.id });
      setMusic(59, "lyd", "game", 4);
    });
  }
  closeCredits() { this.transition(() => this.enterHub(false)); }

  // ───── pause ─────
  pause(v: boolean) {
    if (v) { if (this.mode === "level" || this.mode === "hub") { sfx("ok"); setUI({ paused: true, pauseTab: "main" }); } }
    else { this.resumeAt = performance.now(); sfx("back"); setUI({ paused: false }); }
  }
  restartLevel() {
    const lv = this.level; if (!lv?.planet) return;
    this.startPlanet(lv.planet.id); setUI({ paused: false });
  }
  quitLevel() {
    this.transition(() => {
      if (this.mode === "level" && this.level?.planet) { const pl = this.level.planet; const save = ui.save!; this.disposeLevel(); this.map = new GalaxyMap(this.gfx, save.speeder, save.outfit); this.mode = "map"; this.map.enterGalaxy(pl.galaxy, pl.id); setUI({ screen: "map", paused: false, mapGalaxy: pl.galaxy, mapNear: "" }); setMusic(59, "lyd", "game", 4); }
      else this.enterHub(false);
    });
  }
  toHub() { this.transition(() => { this.enterHub(false); }); }

  // ───── gatcha / garage ─────
  gatchaPull() {
    const save = ui.save!; const COST = 100;
    if (save.coins < COST) { sfx("back"); addToast("Not enough coins (100 needed)"); return false; }
    save.coins -= COST;
    const w = GATCHA_ITEMS.map((i) => (i.rarity === 1 ? 6 : i.rarity === 2 ? 3 : 1));
    let x = Math.random() * w.reduce((a, b) => a + b, 0); let pick = GATCHA_ITEMS[0]; for (let i = 0; i < w.length; i++) { x -= w[i]; if (x <= 0) { pick = GATCHA_ITEMS[i]; break; } }
    const dupe = save.gatcha.includes(pick.id); if (dupe) save.coins += 20; else save.gatcha.push(pick.id);
    persist(); sfx("gatcha"); setUI({ gatchaResult: { ...pick, dupe } }); return true;
  }
  setOutfit(id: string) { const s = ui.save!; s.outfit = id; persist(); sfx("ok"); this.refreshHub(); }
  setSpeeder(id: string) { const s = ui.save!; s.speeder = id; persist(); sfx("ok"); emit(); }
  debugCoins() { const s = ui.save; if (s) { s.coins += 500; persist(); emit(); } }
  stats() { return { bots: totalBots(), puzzles: totalPuzzles() }; }
  stopMusic = stopMusic;
}

export const engine = new Engine();
(window as unknown as { __astro: Engine }).__astro = engine;
