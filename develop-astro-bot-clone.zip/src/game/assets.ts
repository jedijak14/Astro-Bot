import * as THREE from "three";
import { GLTFLoader, type GLTF } from "three/examples/jsm/loaders/GLTFLoader.js";
import * as SkeletonUtils from "three/examples/jsm/utils/SkeletonUtils.js";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import robotUrl from "../assets/models/RobotExpressive.glb?url";
import xbotUrl from "../assets/models/Xbot.glb?url";
import foxUrl from "../assets/models/Fox.glb?url";
import parrotUrl from "../assets/models/Parrot.glb?url";
import flamingoUrl from "../assets/models/Flamingo.glb?url";
import storkUrl from "../assets/models/Stork.glb?url";
import horseUrl from "../assets/models/Horse.glb?url";
import { OUTFITS, SPEEDER_COLORS } from "./data";

type Key = "robot" | "xbot" | "fox" | "parrot" | "flamingo" | "stork" | "horse";
const URLS: Record<Key, string> = { robot: robotUrl, xbot: xbotUrl, fox: foxUrl, parrot: parrotUrl, flamingo: flamingoUrl, stork: storkUrl, horse: horseUrl };
export const gltf = {} as Record<Key, GLTF>;

export async function loadAll(onProgress: (p: number) => void) {
  const loader = new GLTFLoader();
  const keys = Object.keys(URLS) as Key[];
  let done = 0;
  await Promise.all(keys.map(async (k) => { gltf[k] = await loader.loadAsync(URLS[k]); done++; onProgress(done / keys.length); }));
}

// ───────── Actor (rigged / animated model wrapper) ─────────
export class Actor {
  root = new THREE.Group();
  model!: THREE.Object3D;
  mixer: THREE.AnimationMixer;
  actions: Record<string, THREE.AnimationAction> = {};
  current = "";
  height = 1;
  headTop = 1;
  headBone: THREE.Object3D | null = null;
  morphs: THREE.Mesh[] = [];
  constructor(src: Key, targetHeight: number) {
    const g = gltf[src];
    this.model = SkeletonUtils.clone(g.scene);
    this.root.add(this.model);
    const holder = new THREE.Group();
    this.root.add(holder);
    this.model.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) { m.castShadow = true; m.receiveShadow = false; m.frustumCulled = false; if (m.morphTargetDictionary) this.morphs.push(m); }
      if ((o as THREE.Bone).isBone && /^(Head|mixamorig:Head)$/.test(o.name) && !this.headBone) this.headBone = o;
    });
    this.root.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(this.model, true);
    const sz = box.getSize(new THREE.Vector3());
    const longest = src === "fox" || src === "horse" || src.match(/parrot|flamingo|stork/) ? Math.max(sz.y, sz.x, sz.z) : sz.y;
    const s = targetHeight / (longest || 1);
    this.model.scale.multiplyScalar(s);
    this.root.updateMatrixWorld(true);
    const b2 = new THREE.Box3().setFromObject(this.model, true);
    this.model.position.y -= b2.min.y; // feet on ground
    this.model.position.x -= (b2.min.x + b2.max.x) / 2; this.model.position.z -= (b2.min.z + b2.max.z) / 2;
    if (src === "fox") this.model.position.z += 0; // keep centred
    this.root.updateMatrixWorld(true);
    this.height = b2.max.y - b2.min.y;
    this.mixer = new THREE.AnimationMixer(this.model);
    for (const c of g.animations) this.actions[c.name] = this.mixer.clipAction(c);
    // head top (for accessories)
    const hm = this.morphs.find((m) => m.name.startsWith("Head"));
    if (hm) { const hb = new THREE.Box3().setFromObject(hm, true); this.headTop = hb.max.y; }
    else this.headTop = this.height * 0.98;
  }
  play(name: string, o: { fade?: number; once?: boolean; speed?: number } = {}) {
    const a = this.actions[name]; if (!a) return;
    if (this.current === name && !o.once) { a.timeScale = o.speed ?? 1; return; }
    const prev = this.actions[this.current];
    a.reset(); a.enabled = true; a.timeScale = o.speed ?? 1; a.setEffectiveWeight(1);
    if (o.once) { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; } else a.setLoop(THREE.LoopRepeat, Infinity);
    a.play();
    if (prev && prev !== a) prev.crossFadeTo(a, o.fade ?? 0.18, false);
    this.current = name;
  }
  isDone(name: string) { const a = this.actions[name]; return !a || (!a.isRunning() || a.time >= a.getClip().duration - 0.05); }
  update(dt: number) { this.mixer.update(dt); }
  express(name: string, v: number) { for (const m of this.morphs) { const i = m.morphTargetDictionary?.[name]; if (i !== undefined && m.morphTargetInfluences) m.morphTargetInfluences[i] = v; } }
  /** attach a world-unit-sized object to a bone, keeping it upright in bind pose */
  attach(bone: THREE.Object3D, obj: THREE.Object3D, offset: THREE.Vector3) {
    this.root.updateMatrixWorld(true);
    const wq = new THREE.Quaternion(), ws = new THREE.Vector3(), wp = new THREE.Vector3();
    bone.getWorldQuaternion(wq); bone.getWorldScale(ws); bone.getWorldPosition(wp);
    const holder = new THREE.Object3D();
    const inv = wq.clone().invert();
    holder.quaternion.copy(inv);
    holder.scale.setScalar(1 / ws.x);
    holder.position.copy(offset).applyQuaternion(inv).divideScalar(ws.x);
    holder.add(obj); bone.add(holder);
    return holder;
  }
  boneWorld(bone: THREE.Object3D) { this.root.updateMatrixWorld(true); return bone.getWorldPosition(new THREE.Vector3()); }
  dispose() { this.mixer.stopAllAction(); }
}

// ───────── Materials ─────────
const matCache = new Map<string, THREE.Material>();
export function stdMat(color: string, o: Partial<THREE.MeshStandardMaterialParameters> = {}, key?: string) {
  const k = key ?? color + JSON.stringify(o);
  let m = matCache.get(k) as THREE.MeshStandardMaterial | undefined;
  if (!m) { m = new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.05, ...o }); matCache.set(k, m); }
  return m;
}

const robotMatCache = new Map<string, Record<string, THREE.MeshStandardMaterial>>();
export function styleRobot(a: Actor, p: { body: string; joint: string; accent: string; flat?: boolean; eye?: string }) {
  const key = JSON.stringify(p);
  let set = robotMatCache.get(key);
  if (!set) {
    set = {
      Main: new THREE.MeshStandardMaterial({ color: p.body, roughness: 0.28, metalness: 0.08, flatShading: !!p.flat }),
      Grey: new THREE.MeshStandardMaterial({ color: p.joint, roughness: 0.45, metalness: 0.2, flatShading: !!p.flat }),
      Black: new THREE.MeshStandardMaterial({ color: "#05070f", roughness: 0.15, metalness: 0.4, emissive: new THREE.Color(p.eye ?? p.accent), emissiveIntensity: 1.4, flatShading: !!p.flat }),
    };
    robotMatCache.set(key, set);
  }
  a.model.traverse((o) => {
    const m = o as THREE.Mesh;
    if (!m.isMesh) return;
    const apply = (mt: THREE.Material) => set![mt.name] ?? mt;
    m.material = Array.isArray(m.material) ? m.material.map(apply) : apply(m.material);
  });
}

// ───────── Hats / accessories ─────────
export function makeHat(kind: string, color: string, w: number): THREE.Object3D | null {
  const g = new THREE.Group();
  const c = stdMat(color, { roughness: 0.4 });
  const white = stdMat("#ffffff", { roughness: 0.4 });
  const gold = stdMat("#ffd23c", { roughness: 0.25, metalness: 0.7 });
  const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; g.add(m); return m; };
  const r = w * 0.5;
  switch (kind) {
    case "cap": add(new THREE.SphereGeometry(r * 1.0, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), c, 0, 0, 0); add(new THREE.CylinderGeometry(r * 0.9, r * 0.9, 0.02, 20, 1, false, -0.8, 1.6), c, 0, 0.0, r * 0.95).scale.z = 0.5; break;
    case "party": add(new THREE.ConeGeometry(r * 0.55, w * 0.9, 16), c, 0, w * 0.45, 0); add(new THREE.SphereGeometry(r * 0.15, 10, 8), white, 0, w * 0.92, 0); break;
    case "crown": { add(new THREE.CylinderGeometry(r * 0.7, r * 0.6, w * 0.25, 16, 1, true), gold); for (let i = 0; i < 5; i++) { const a = (i / 5) * Math.PI * 2; add(new THREE.ConeGeometry(r * 0.13, w * 0.22, 8), gold, Math.cos(a) * r * 0.66, w * 0.22, Math.sin(a) * r * 0.66); } break; }
    case "horns": for (const s of [-1, 1]) { const h = add(new THREE.ConeGeometry(r * 0.16, w * 0.5, 10), white, s * r * 0.62, w * 0.18, 0); h.rotation.z = -s * 0.5; } break;
    case "headband": add(new THREE.TorusGeometry(r * 0.98, r * 0.07, 8, 28), c, 0, -w * 0.12, 0).rotation.x = Math.PI / 2; add(new THREE.SphereGeometry(r * 0.15, 8, 8), c, r, -w * 0.12, -r * 0.1); break;
    case "helmet": add(new THREE.SphereGeometry(r * 1.05, 20, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), c, 0, -w * 0.05, 0); break;
    case "antenna": add(new THREE.CylinderGeometry(r * 0.04, r * 0.04, w * 0.5, 6), stdMat("#9aa6b8"), 0, w * 0.25, 0); add(new THREE.SphereGeometry(r * 0.16, 10, 8), stdMat(color, { emissive: color, emissiveIntensity: 1.2 }), 0, w * 0.52, 0); break;
    case "chef": add(new THREE.CylinderGeometry(r * 0.6, r * 0.55, w * 0.4, 16), white, 0, w * 0.2, 0); add(new THREE.SphereGeometry(r * 0.7, 14, 10), white, 0, w * 0.42, 0); break;
    case "wizard": add(new THREE.ConeGeometry(r * 0.6, w * 1.1, 16), c, 0, w * 0.55, 0); add(new THREE.CylinderGeometry(r * 1.1, r * 1.1, 0.02, 20), c, 0, 0, 0); break;
    case "bow": add(new THREE.ConeGeometry(r * 0.3, r * 0.5, 8), c, -r * 0.3, w * 0.05, 0).rotation.z = Math.PI / 2; add(new THREE.ConeGeometry(r * 0.3, r * 0.5, 8), c, r * 0.3, w * 0.05, 0).rotation.z = -Math.PI / 2; add(new THREE.SphereGeometry(r * 0.14, 8, 8), c, 0, w * 0.05, 0); g.position.x = r * 0.4; break;
    case "halo": add(new THREE.TorusGeometry(r * 0.6, r * 0.06, 8, 24), stdMat("#fff3a0", { emissive: "#ffe060", emissiveIntensity: 1.5 }), 0, w * 0.25, 0).rotation.x = Math.PI / 2; break;
    default: return null;
  }
  return g;
}

export interface RobotOpts { body?: string; joint?: string; accent?: string; hat?: string; hatColor?: string; flat?: boolean; height?: number; outfit?: string }
export function makeRobot(o: RobotOpts = {}): Actor {
  const a = new Actor("robot", o.height ?? 1.0);
  const of = OUTFITS.find((x) => x.id === o.outfit);
  styleRobot(a, { body: o.body ?? of?.body ?? "#f4f7ff", joint: o.joint ?? of?.joint ?? "#a9b8d6", accent: o.accent ?? of?.accent ?? "#2f8bff", flat: o.flat ?? o.outfit === "throwback" });
  if (a.headBone) {
    const headW = a.height * 0.5;
    const pos = a.boneWorld(a.headBone);
    // ear lights
    const accent = o.accent ?? of?.accent ?? "#2f8bff";
    const lightMat = stdMat(accent, { emissive: accent, emissiveIntensity: 2 }, "ear" + accent);
    for (const s of [-1, 1]) {
      const l = new THREE.Mesh(new THREE.SphereGeometry(a.height * 0.04, 8, 6), lightMat);
      a.attach(a.headBone, l, new THREE.Vector3(s * headW * 0.46 - pos.x, a.headTop - a.height * 0.2 - pos.y, -pos.z));
    }
    if (o.hat && o.hat !== "none") {
      const hat = makeHat(o.hat, o.hatColor ?? "#ff5a5a", headW);
      if (hat) a.attach(a.headBone, hat, new THREE.Vector3(-pos.x, a.headTop - a.height * 0.06 - pos.y, -pos.z));
    }
  }
  return a;
}
export function makeXbot(color: string, h = 1.0): Actor {
  const a = new Actor("xbot", h);
  a.model.traverse((o) => { const m = o as THREE.Mesh; if (m.isMesh) { m.material = stdMat(color, { roughness: 0.3, metalness: 0.2 }, "xb" + color); } });
  return a;
}
export function tintAnimal(a: Actor, color: string | null, emissive?: string) {
  if (!color) return;
  a.model.traverse((o) => { const m = o as THREE.Mesh; if (m.isMesh) { const mt = (m.material as THREE.MeshStandardMaterial).clone(); mt.color.multiply(new THREE.Color(color)); if (emissive) { mt.emissive = new THREE.Color(emissive); mt.emissiveIntensity = 0.3; } m.material = mt; } });
}
export const makeFox = (h = 0.8) => new Actor("fox", h);
export const makeBird = (k: "parrot" | "flamingo" | "stork", h = 1) => new Actor(k, h);
export const makeHorse = (h = 1.2) => new Actor("horse", h);

// ───────── Procedural props ─────────
const coinGeo = (() => { const g = new THREE.CylinderGeometry(0.26, 0.26, 0.06, 24); g.rotateX(Math.PI / 2); return g; })();
const coinRim = (() => { const g = new THREE.TorusGeometry(0.24, 0.035, 8, 24); return g; })();
const coinMat = new THREE.MeshStandardMaterial({ color: "#ffcf3a", roughness: 0.25, metalness: 0.85, emissive: "#ff9a00", emissiveIntensity: 0.35 });
const starShape = (() => { const s = new THREE.Shape(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 0.07 : 0.16, a = (i / 10) * Math.PI * 2 + Math.PI / 2; i ? s.lineTo(Math.cos(a) * r, Math.sin(a) * r) : s.moveTo(Math.cos(a) * r, Math.sin(a) * r); } return s; })();
const starGeo = new THREE.ExtrudeGeometry(starShape, { depth: 0.02, bevelEnabled: false });
export function makeCoin(big = false) {
  const g = new THREE.Group();
  const c = new THREE.Mesh(coinGeo, coinMat); c.castShadow = true; g.add(c);
  const r = new THREE.Mesh(coinRim, coinMat); g.add(r);
  const s = new THREE.Mesh(starGeo, coinMat); s.position.z = 0.025; g.add(s);
  const s2 = s.clone(); s2.position.z = -0.045; g.add(s2);
  if (big) g.scale.setScalar(1.8);
  return g;
}

export function puzzleGeo() {
  const s = new THREE.Shape();
  const k = 0.5;
  s.moveTo(-k, -k); s.lineTo(-0.12, -k); s.absarc(0, -k, 0.12, Math.PI, 0, true); s.lineTo(k, -k);
  s.lineTo(k, -0.12); s.absarc(k, 0, 0.12, -Math.PI / 2, Math.PI / 2, false); s.lineTo(k, k);
  s.lineTo(0.12, k); s.absarc(0, k, 0.12, 0, Math.PI, false); s.lineTo(-k, k);
  s.lineTo(-k, 0.12); s.absarc(-k, 0, 0.12, Math.PI / 2, -Math.PI / 2, true); s.lineTo(-k, -k);
  return new THREE.ExtrudeGeometry(s, { depth: 0.18, bevelEnabled: true, bevelSize: 0.05, bevelThickness: 0.05, bevelSegments: 3 });
}
const _pz = puzzleGeo();
export function makePuzzle(color = "#43b0ff", scale = 0.55) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(_pz, new THREE.MeshStandardMaterial({ color, roughness: 0.2, metalness: 0.2, emissive: color, emissiveIntensity: 0.55 }));
  m.position.z = -0.09; m.castShadow = true; g.add(m);
  g.scale.setScalar(scale);
  return g;
}

export function glowTexture(color = "#ffffff") {
  const c = document.createElement("canvas"); c.width = c.height = 128;
  const x = c.getContext("2d")!; const gr = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, color); gr.addColorStop(0.25, color + "aa"); gr.addColorStop(1, color + "00");
  x.fillStyle = gr; x.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
export function textSprite(text: string, color = "#ffffff", bg = "#ff3b5c", size = 1) {
  const c = document.createElement("canvas"); c.width = 256; c.height = 128;
  const x = c.getContext("2d")!;
  x.fillStyle = bg; x.beginPath(); x.roundRect(8, 8, 240, 90, 36); x.fill();
  x.beginPath(); x.moveTo(110, 96); x.lineTo(128, 124); x.lineTo(146, 96); x.fill();
  x.strokeStyle = "#fff"; x.lineWidth = 6; x.beginPath(); x.roundRect(8, 8, 240, 90, 36); x.stroke();
  x.fillStyle = color; x.font = "900 60px Fredoka, Arial Rounded MT Bold, sans-serif"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText(text, 128, 54);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthWrite: false, transparent: true }));
  s.scale.set(1.6 * size, 0.8 * size, 1); return s;
}

// Dual Speeder (DualSense-shaped ship)
export function makeSpeeder(colorId = "white") {
  const col = SPEEDER_COLORS.find((c) => c.id === colorId)?.color ?? "#f2f5ff";
  const g = new THREE.Group();
  const body = stdMat(col, { roughness: 0.25, metalness: 0.1 });
  const dark = stdMat("#0b0e18", { roughness: 0.2, metalness: 0.5 }, "sp-dark");
  const glow = stdMat("#38a8ff", { emissive: "#38a8ff", emissiveIntensity: 2.2 }, "sp-glow");
  const mesh = (geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; g.add(m); return m; };
  mesh(new RoundedBoxGeometry(2.3, 0.42, 1.15, 5, 0.18), body);
  mesh(new RoundedBoxGeometry(1.5, 0.3, 0.85, 4, 0.12), dark, 0, 0.12, 0);
  for (const s of [-1, 1]) {
    const grip = mesh(new THREE.CapsuleGeometry(0.28, 0.9, 6, 14), body, s * 0.95, -0.05, -0.55); grip.rotation.set(Math.PI / 2 + 0.25, 0, s * 0.18); grip.scale.set(1, 1, 0.9);
    const th = mesh(new THREE.ConeGeometry(0.2, 0.5, 12), glow, s * 0.98, -0.12, -1.1); th.rotation.x = -Math.PI / 2; th.scale.set(1, 1, 1);
    const names = ["#43d17c", "#ff4f5e", "#4f8bff", "#ff6fc8"];
    names.forEach((c, i) => { const a = (i / 4) * Math.PI * 2; mesh(new THREE.SphereGeometry(0.05, 8, 6), stdMat(c, { emissive: c, emissiveIntensity: 0.6 }, "btn" + c), s * 0.85 + Math.cos(a) * 0.12, 0.23, 0.2 + Math.sin(a) * 0.12); });
  }
  const bar = mesh(new THREE.TorusGeometry(0.8, 0.045, 8, 32, Math.PI), glow, 0, 0.2, 0.52); bar.rotation.set(0.0, Math.PI, 0); bar.rotation.x = -0.2; bar.scale.set(1, 0.4, 1);
  mesh(new THREE.SphereGeometry(0.1, 10, 8), glow, 0, 0.22, 0.2);
  return g;
}

// PS5 mothership (crashed, tilted)
export function makePS5() {
  const g = new THREE.Group();
  const white = stdMat("#f5f7fc", { roughness: 0.25, metalness: 0.05 });
  const dark = stdMat("#0b0d14", { roughness: 0.2, metalness: 0.4 }, "ps-dark");
  const glow = stdMat("#4aa8ff", { emissive: "#4aa8ff", emissiveIntensity: 2 }, "ps-glow");
  const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; g.add(m); return m; };
  add(new RoundedBoxGeometry(3.0, 11, 4.4, 5, 0.5), dark, 0, 5.5, 0);
  for (const s of [-1, 1]) {
    const f = add(new RoundedBoxGeometry(2.2, 11.4, 6.2, 5, 0.9), white, s * 2.1, 5.7, 0);
    f.scale.set(1, 1, 1); f.rotation.z = s * 0.06;
    add(new THREE.BoxGeometry(0.1, 8, 0.1), glow, s * 0.9, 5.5, 2.3);
  }
  add(new THREE.CylinderGeometry(0.4, 0.4, 0.2, 20), glow, 0, 10.7, 2.3).rotation.x = Math.PI / 2;
  return g;
}

export { THREE };
