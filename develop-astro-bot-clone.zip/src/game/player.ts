import * as THREE from "three";
import { Actor, makeRobot, stdMat } from "./assets";
import { ui } from "./store";
import { sfx } from "./audio";
import { input } from "./input";
import type { Gadget } from "./data";

export interface Solid {
  obj: THREE.Object3D;
  min: THREE.Vector3; max: THREE.Vector3; vel: THREE.Vector3;
  kind: "static" | "mover" | "crumble" | "ice" | "climb" | "arena" | "glass";
  active: boolean;
  update?: (t: number, dt: number) => void;
  touched?: () => void;
}

export interface PlayerHost {
  solids: Solid[];
  burst: (p: THREE.Vector3, color: string, n?: number, speed?: number, life?: number, size?: number, grav?: number, up?: number) => void;
  onSlam: (p: THREE.Vector3, r: number) => void;
  onDie: () => void;
  onHurt: (n: number) => void;
  getCoins: () => number;
  minY: number;
  slippery: boolean;
}

const R = 0.32, H = 0.95, STEP = 0.36;

export class Player {
  group = new THREE.Group();
  actor: Actor;
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  yaw = 0;
  onGround = false;
  standing: Solid | null = null;
  coyote = 0; jumpBuf = 0;
  fuel = 1; // hover fuel (0..1)
  boostFuel = 1;
  spinT = 0; spinCd = 0;
  slamming = false;
  jumping = false;
  hovering = false;
  boosting = false;
  climbing: { s: Solid; nx: number; nz: number } | null = null;
  touchWall: { s: Solid; nx: number; nz: number } | null = null;
  invuln = 0;
  dead = 0;
  hurtT = 0;
  gadget: Gadget = "none";
  gadgetVis: THREE.Object3D[] = [];
  blob: THREE.Mesh;
  animLock = 0;
  celebrate = 0;
  speedMul = 1;
  frozen = false;
  lastGroundY = 0;
  landedFlag = false;
  fall = 0;
  sitting = false;
  host!: PlayerHost;

  constructor(outfit = "default") {
    this.actor = makeRobot({ outfit, height: 1.0 });
    this.group.add(this.actor.root);
    this.actor.play("Idle");
    this.blob = new THREE.Mesh(new THREE.CircleGeometry(0.42, 20), new THREE.MeshBasicMaterial({ color: "#000", transparent: true, opacity: 0.35, depthWrite: false }));
    this.blob.rotation.x = -Math.PI / 2;
  }

  setGadget(g: Gadget) {
    this.gadgetVis.forEach((o) => o.removeFromParent()); this.gadgetVis = [];
    this.gadget = g;
    if (g === "none") return;
    const a = this.actor;
    const bone = (n: string) => { let r: THREE.Object3D | null = null; a.model.traverse((o) => { if ((o as THREE.Bone).isBone && o.name === n) r = o; }); return r as THREE.Object3D | null; };
    const head = a.headBone; const s = a.height;
    const hp = head ? a.boneWorld(head) : new THREE.Vector3();
    if (g === "frog" && head) {
      const grp = new THREE.Group(); const gm = stdMat("#4ad65a", { roughness: 0.4 });
      const dome = new THREE.Mesh(new THREE.SphereGeometry(s * 0.27, 18, 10, 0, 6.283, 0, 1.4), gm); grp.add(dome);
      for (const x of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(s * 0.09, 10, 8), stdMat("#fff")); e.position.set(x * s * 0.14, s * 0.2, s * 0.04); const p = new THREE.Mesh(new THREE.SphereGeometry(s * 0.04, 8, 6), stdMat("#111")); p.position.set(0, 0, s * 0.07); e.add(p); grp.add(e); }
      this.gadgetVis.push(a.attach(head, grp, new THREE.Vector3(-hp.x, a.headTop - s * 0.16 - hp.y, -hp.z)));
    }
    if (g === "monkey" && head) {
      const grp = new THREE.Group(); const gm = stdMat("#8a5a2a", { roughness: 0.8 });
      for (const x of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(s * 0.1, 10, 8), gm); e.position.set(x * s * 0.3, s * 0.06, 0); grp.add(e); const i = new THREE.Mesh(new THREE.SphereGeometry(s * 0.06, 8, 6), stdMat("#ffc89a")); i.position.set(x * s * 0.3, s * 0.06, s * 0.05); grp.add(i); }
      this.gadgetVis.push(a.attach(head, grp, new THREE.Vector3(-hp.x, a.headTop - s * 0.2 - hp.y, -hp.z)));
    }
    if (g === "rocket") {
      const torso = bone("Torso") ?? bone("Abdomen"); if (torso) {
        const tp = a.boneWorld(torso);
        const grp = new THREE.Group();
        for (const x of [-1, 1]) { const c = new THREE.Mesh(new THREE.CapsuleGeometry(s * 0.08, s * 0.3, 4, 10), stdMat("#ff5a3c", { metalness: 0.4, roughness: 0.3 })); c.position.set(x * s * 0.12, 0, 0); grp.add(c); const f = new THREE.Mesh(new THREE.ConeGeometry(s * 0.07, s * 0.2, 8), stdMat("#ffd23c", { emissive: "#ff9a00", emissiveIntensity: 2 })); f.position.set(x * s * 0.12, -s * 0.28, 0); f.rotation.x = Math.PI; f.name = "flame"; grp.add(f); }
        this.gadgetVis.push(a.attach(torso, grp, new THREE.Vector3(-tp.x, s * 0.42 - tp.y, -tp.z - s * 0.3)));
      }
    }
    if (g === "gloves") {
      for (const side of ["L", "R"]) {
        const b = bone("Palm2." + side) ?? bone("LowerArm." + side); if (!b) continue;
        const m = new THREE.Mesh(new THREE.SphereGeometry(s * 0.2, 14, 10), stdMat("#ff3a4a", { roughness: 0.3, metalness: 0.1 }));
        this.gadgetVis.push(a.attach(b, m, new THREE.Vector3(0, 0, 0)));
      }
    }
    sfx("gadget");
  }

  teleport(p: THREE.Vector3, yaw?: number) {
    this.pos.copy(p); this.vel.set(0, 0, 0); this.onGround = false; this.standing = null; this.climbing = null;
    if (yaw !== undefined) this.yaw = yaw;
    this.group.position.copy(p); this.lastGroundY = p.y; this.fall = 0;
  }

  get center() { return new THREE.Vector3(this.pos.x, this.pos.y + H * 0.5, this.pos.z); }

  hurt(from: THREE.Vector3, dmgCoins = 10) {
    if (this.invuln > 0 || this.dead > 0) return;
    const c = this.host.getCoins();
    this.host.onHurt(dmgCoins);
    sfx("hit");
    if (c <= 0) { this.die(); return; }
    const d = new THREE.Vector3(this.pos.x - from.x, 0, this.pos.z - from.z); if (d.lengthSq() < 0.001) d.set(0, 0, 1); d.normalize();
    this.vel.set(d.x * 6, 7, d.z * 6); this.onGround = false; this.standing = null; this.climbing = null;
    this.invuln = 1.6; this.hurtT = 0.5; this.spinT = 0;
    this.host.burst(this.center, "#ffd23c", 14, 5, 0.8, 0.3, 10);
  }
  die() {
    if (this.dead > 0) return;
    this.dead = 1.3; sfx("die"); this.vel.set(0, 6, 0); this.actor.play("Death", { once: true, fade: 0.1 });
    this.host.burst(this.center, "#ffffff", 20, 5, 0.9, 0.3, 4);
    this.host.onDie();
  }
  respawn(p: THREE.Vector3) {
    this.dead = 0; this.teleport(p); this.invuln = 2; this.setVisible(true); this.actor.play("Idle", { fade: 0.1 }); this.fuel = 1; this.boostFuel = 1;
    this.slamming = false; this.spinT = 0;
  }
  setVisible(v: boolean) { this.actor.root.visible = v; }

  // ─── movement collision ───
  private overlapsXZ(s: Solid, x: number, z: number) { return x + R > s.min.x && x - R < s.max.x && z + R > s.min.z && z - R < s.max.z; }
  private overlap(s: Solid, x: number, y: number, z: number) { return s.active && this.overlapsXZ(s, x, z) && y + H > s.min.y && y < s.max.y; }

  private moveAxis(axis: "x" | "z", d: number) {
    if (d === 0) return;
    this.pos[axis] += d;
    const sol = this.host.solids;
    for (let i = 0; i < sol.length; i++) {
      const s = sol[i];
      if (!this.overlap(s, this.pos.x, this.pos.y, this.pos.z)) continue;
      const rise = s.max.y - this.pos.y;
      if (rise > 0 && rise <= STEP && this.vel.y <= 0.5 && !this.headBlocked(s.max.y)) { this.pos.y = s.max.y + 0.001; this.onGround = true; this.standing = s; continue; }
      const lo = axis === "x" ? s.min.x : s.min.z, hi = axis === "x" ? s.max.x : s.max.z;
      const nx = axis === "x" ? (d > 0 ? -1 : 1) : 0, nz = axis === "z" ? (d > 0 ? -1 : 1) : 0;
      this.pos[axis] = d > 0 ? lo - R - 0.001 : hi + R + 0.001;
      if (s.kind === "climb") this.touchWall = { s, nx, nz };
      this.vel[axis] = 0;
    }
  }
  private headBlocked(y: number) {
    for (const s of this.host.solids) if (s.active && this.overlapsXZ(s, this.pos.x, this.pos.z) && s.min.y < y + H && s.max.y > y + 0.02 && s.min.y > y - 0.01) return true;
    return false;
  }
  private moveY(d: number) {
    this.pos.y += d;
    const sol = this.host.solids;
    let hitG = false;
    for (let i = 0; i < sol.length; i++) {
      const s = sol[i];
      if (!this.overlap(s, this.pos.x, this.pos.y, this.pos.z)) continue;
      if (d <= 0 || this.pos.y + H * 0.5 > (s.min.y + s.max.y) * 0.5 + 0.0001 && s.max.y - (this.pos.y - d) < 0.3) {
        if (d <= 0.0001) { this.pos.y = s.max.y; hitG = true; this.standing = s; this.vel.y = Math.max(this.vel.y, 0); this.vel.y = 0; continue; }
      }
      this.pos.y = s.min.y - H - 0.001; this.vel.y = Math.min(this.vel.y, 0);
    }
    return hitG;
  }

  update(dt: number, camYaw: number, canControl: boolean) {
    const g = this.host;
    const prevGround = this.onGround;
    this.invuln = Math.max(0, this.invuln - dt); this.hurtT = Math.max(0, this.hurtT - dt);
    this.spinCd = Math.max(0, this.spinCd - dt);
    this.touchWall = null;
    if (this.dead > 0) {
      this.dead -= dt; this.vel.y -= 26 * dt; this.pos.y += this.vel.y * dt * 0.6; this.syncVisual(dt); return;
    }
    const ctl = canControl && !this.frozen;
    const mv = ctl ? input.move : { x: 0, y: 0 };
    // camera-relative direction
    const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw), rx = Math.cos(camYaw), rz = -Math.sin(camYaw);
    let dx = fx * mv.y + rx * mv.x, dz = fz * mv.y + rz * mv.x;
    const mag = Math.min(1, Math.hypot(dx, dz));
    if (mag > 0.001) { dx /= Math.hypot(dx, dz); dz /= Math.hypot(dx, dz) || 1; const l = Math.hypot(dx, dz); dx /= l; dz /= l; }
    const slipperyNow = this.standing?.kind === "ice" || g.slippery;
    const maxSp = (this.hovering ? 6.2 : 7.0) * this.speedMul;

    // ─── wall climbing ───
    if (this.climbing) {
      const c = this.climbing;
      this.vel.set(0, 0, 0);
      const up = ctl ? mv.y : 0;
      const latx = ctl ? mv.x : 0;
      const speed = this.gadget === "monkey" ? 5.2 : 3.4;
      // lateral movement along wall
      const tx0 = -c.nz, tz0 = c.nx; // wall tangent
      const lat = (rx * tx0 + rz * tz0) * latx;
      const stillTouch = this.stillOnWall(c);
      if (!stillTouch) this.climbing = null;
      else {
        this.moveY(up * speed * dt);
        this.moveAxis("x", tx0 * lat * speed * 0.7 * dt);
        this.moveAxis("z", tz0 * lat * speed * 0.7 * dt);
        this.moveAxis(c.nx !== 0 ? "x" : "z", -(c.nx || c.nz) * 0.4 * dt); // stick to wall
        if (this.pos.y >= c.s.max.y - 0.15 && up > 0) { this.pos.y = c.s.max.y + 0.001; this.pos.x -= c.nx * 0.45; this.pos.z -= c.nz * 0.45; this.climbing = null; this.onGround = true; this.standing = c.s; }
        if (ctl && input.jumpP) { this.vel.set(c.nx * 6.5, 11.5, c.nz * 6.5); this.climbing = null; this.jumping = true; sfx("jump"); this.yaw = Math.atan2(c.nx, c.nz); }
        this.actor.play("WalkJump", { speed: 0.001, fade: 0.1 });
        this.yaw = Math.atan2(-c.nx, -c.nz);
        this.syncVisual(dt); return;
      }
    }

    // ─── horizontal velocity ───
    const accel = this.onGround ? (slipperyNow ? 7 : 62) : 28;
    const decel = this.onGround ? (slipperyNow ? 1.6 : 55) : 8;
    const tx = dx * maxSp * mag, tz = dz * maxSp * mag;
    const rate = mag > 0.01 ? accel : decel;
    const vx = this.vel.x + THREE.MathUtils.clamp(tx - this.vel.x, -rate * dt, rate * dt);
    const vz = this.vel.z + THREE.MathUtils.clamp(tz - this.vel.z, -rate * dt, rate * dt);
    if (!this.boosting) { this.vel.x = vx; this.vel.z = vz; }
    if (mag > 0.1 && this.spinT <= 0 && !this.boosting) { const ty = Math.atan2(dx, dz); let d = ty - this.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); this.yaw += d * Math.min(1, dt * 16); }

    // ─── jumping ───
    this.coyote = this.onGround ? 0.11 : this.coyote - dt;
    this.jumpBuf = ctl && input.jumpP ? 0.12 : this.jumpBuf - dt;
    const jumpV = this.gadget === "frog" ? 15.5 : 11.2;
    if (this.jumpBuf > 0 && this.coyote > 0) {
      this.vel.y = jumpV; this.onGround = false; this.standing = null; this.coyote = 0; this.jumpBuf = 0; this.jumping = true; sfx("jump");
      g.burst(this.pos, "#ffffff", 5, 1.5, 0.35, 0.22, 0, 0.1);
      this.actor.play("Jump", { once: true, fade: 0.08 });
    }
    if (this.jumping && ctl && !input.jump && this.vel.y > 4.5) { this.vel.y *= 0.55; this.jumping = false; }
    // ─── hover / boost ───
    const gravity = 30;
    this.hovering = false; this.boosting = false;
    const airborne = !this.onGround;
    if (airborne && ctl && input.jump && this.vel.y < 2 && this.fuel > 0 && this.spinT <= 0 && !this.slamming) {
      this.hovering = true; this.fuel = Math.max(0, this.fuel - dt / 1.3);
      this.vel.y += (-0.6 - this.vel.y) * Math.min(1, dt * 9);
      if (Math.random() < 0.7) g.burst(new THREE.Vector3(this.pos.x, this.pos.y + 0.05, this.pos.z), "#6ad0ff", 1, 1.5, 0.4, 0.3, 0, -1.4);
    } else {
      this.vel.y -= gravity * dt * (this.vel.y < 0 ? 1.1 : 1);
    }
    if (this.gadget === "rocket" && ctl && input.boost && this.boostFuel > 0 && !this.slamming) {
      this.boosting = true; this.boostFuel = Math.max(0, this.boostFuel - dt / 2.2);
      const f = new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw));
      this.vel.x += (f.x * 13 - this.vel.x) * Math.min(1, dt * 6); this.vel.z += (f.z * 13 - this.vel.z) * Math.min(1, dt * 6);
      this.vel.y += ((this.onGround ? 0 : 1.5) - this.vel.y) * Math.min(1, dt * 5) + (this.onGround ? 0 : 0);
      if (this.onGround && this.vel.y <= 0) { this.vel.y = 0.5; }
      g.burst(new THREE.Vector3(this.pos.x - f.x * 0.3, this.pos.y + 0.6, this.pos.z - f.z * 0.3), "#ffb02a", 2, 2, 0.35, 0.35, 0, 0);
    }
    if (this.onGround) { this.fuel = Math.min(1, this.fuel + dt * 1.6); this.boostFuel = Math.min(1, this.boostFuel + dt * 0.9); }

    // ─── spin & slam ───
    if (ctl && input.spinP && this.spinCd <= 0 && this.spinT <= 0 && !this.slamming) {
      this.spinT = 0.44; this.spinCd = 0.18; sfx("spin");
      if (airborne) this.vel.y = Math.max(this.vel.y, 3.5);
      this.actor.play("Punch", { once: true, fade: 0.05, speed: 1.6 });
    }
    if (this.spinT > 0) this.spinT -= dt;
    if (ctl && input.slamP && airborne && !this.slamming && this.pos.y - this.lastGroundY > -50) { this.slamming = true; this.vel.set(0, -26, 0); this.spinT = 0; sfx("spin"); }
    if (this.slamming) { this.vel.x = 0; this.vel.z = 0; this.vel.y = -26; }

    // ─── carry by platform ───
    if (this.standing && this.onGround) {
      const sv = this.standing.vel;
      if (sv.lengthSq() > 0) { this.pos.x += sv.x * dt; this.pos.z += sv.z * dt; if (sv.y !== 0) this.pos.y += sv.y * dt; }
    }

    // ─── integrate + collide ───
    this.onGround = false; const wasStanding = this.standing; this.standing = null;
    const sdt = dt;
    this.moveAxis("x", this.vel.x * sdt);
    this.moveAxis("z", this.vel.z * sdt);
    const landed = this.moveY(this.vel.y * sdt);
    if (landed) { this.onGround = true; }
    else if (this.vel.y <= 0.01 && this.snapProbe()) { this.onGround = true; }
    if (this.onGround && this.standing === null) this.standing = wasStanding;
    if (this.onGround) {
      if (!prevGround && this.fall < -9) { g.burst(this.pos, "#ffffff", 6, 2, 0.4, 0.28, 2, 0.2); sfx("land"); }
      if (this.slamming) { this.slamming = false; sfx("boom"); g.onSlam(this.pos.clone(), this.gadget === "frog" ? 3.4 : 2.4); g.burst(this.pos, "#ffe9a0", 22, 6, 0.6, 0.35, 4, 0.1); }
      this.lastGroundY = this.pos.y; this.jumping = false; this.hovering = false;
      if (this.standing) this.standing.touched?.();
    }
    this.fall = this.vel.y;
    // wall grab
    if (this.touchWall && ctl && (mag > 0.1) && !this.hovering) {
      const w = this.touchWall as { s: Solid; nx: number; nz: number };
      if (this.gadget === "monkey" || w.s.kind === "climb") { this.climbing = w; this.fuel = Math.min(1, this.fuel + 0.5); this.slamming = false; this.spinT = 0; }
    }
    if (this.pos.y < g.minY) { this.die(); }
    this.syncVisual(dt);
  }

  private stillOnWall(c: { s: Solid; nx: number; nz: number }) {
    const s = c.s; const eps = 0.08;
    return s.active && this.pos.y + H > s.min.y && this.pos.y < s.max.y + 0.05 && this.pos.x + R + eps > s.min.x && this.pos.x - R - eps < s.max.x && this.pos.z + R + eps > s.min.z && this.pos.z - R - eps < s.max.z;
  }

  private snapProbe() {
    for (const s of this.host.solids) {
      if (!s.active || !this.overlapsXZ(s, this.pos.x, this.pos.z)) continue;
      const d = this.pos.y - s.max.y;
      if (d > -0.02 && d < 0.07) { this.pos.y = s.max.y; this.standing = s; this.vel.y = 0; return true; }
    }
    return false;
  }

  /** highest solid top below a point (for shadow blob / aiming) */
  groundBelow(x: number, z: number, y: number): number | null {
    let best: number | null = null;
    for (const s of this.host.solids) {
      if (!s.active) continue;
      if (x > s.min.x && x < s.max.x && z > s.min.z && z < s.max.z && s.max.y <= y + 0.5) { if (best === null || s.max.y > best) best = s.max.y; }
    }
    return best;
  }

  syncVisual(dt: number, yawOffset = 0) {
    const a = this.actor;
    this.group.position.copy(this.pos);
    let ry = this.yaw + yawOffset;
    if (this.spinT > 0) ry += (1 - this.spinT / 0.44) * Math.PI * 4;
    a.root.rotation.y = ry;
    // animation state
    const sp = Math.hypot(this.vel.x, this.vel.z);
    if (this.dead > 0) { /* death anim already playing */ }
    else if (this.celebrate > 0) { this.celebrate -= dt; a.play("Dance"); }
    else if (this.spinT > 0) { a.play("Punch"); }
    else if (this.climbing) { /* handled */ }
    else if (!this.onGround) {
      if (this.hovering) a.play("WalkJump", { speed: 1.5 }); else if (this.vel.y > 0.5) { if (a.current !== "Jump") a.play("Jump", { once: true, fade: 0.08 }); } else a.play("WalkJump", { speed: 0.6 });
    } else if (this.sitting) a.play("Sitting");
    else if (sp > 4.2) a.play("Running", { speed: 0.9 + sp * 0.04 });
    else if (sp > 0.6) a.play("Walking", { speed: 0.8 + sp * 0.12 });
    else a.play("Idle");
    a.update(dt);
    // face expression
    a.express("Angry", this.hurtT > 0 ? 0 : 0); a.express("Surprised", this.hurtT > 0 || this.dead > 0 ? 1 : 0);
    // blink while invulnerable
    if (this.dead <= 0) this.setVisible(this.invuln <= 0 || Math.floor(this.invuln * 14) % 2 === 0);
    // squash on landing
    const sc = 1; a.root.scale.setScalar(sc);
    // gadget flames
    for (const o of this.gadgetVis) o.traverse((m) => { if (m.name === "flame") m.visible = this.boosting; });
    // blob shadow
    const gy = this.groundBelow(this.pos.x, this.pos.z, this.pos.y);
    if (gy !== null) { this.blob.visible = true; this.blob.position.set(this.pos.x, gy + 0.03, this.pos.z); const k = THREE.MathUtils.clamp(1 - (this.pos.y - gy) / 12, 0.4, 1); this.blob.scale.setScalar(k); (this.blob.material as THREE.MeshBasicMaterial).opacity = 0.38 * k; }
    else this.blob.visible = false;
  }
}

export function syncUI(p: Player) { ui.hover = p.fuel; ui.boost = p.boostFuel; }
