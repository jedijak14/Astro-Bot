import * as THREE from "three";
import { GALAXIES, PLANETS, THEMES, planetById, galaxyById, rng, seedOf, type Planet } from "./data";
import { Sky, Lighting, Particles, type Gfx } from "./world";
import { Actor, makeRobot, makeSpeeder, glowTexture, textSprite, stdMat } from "./assets";
import { input } from "./input";
import { planetLock, ui, galaxyUnlocked } from "./store";

const V = THREE.Vector3;

function planetTexture(planet: Planet, locked: boolean) {
  const th = THEMES[planet.theme]; const r = rng(seedOf(planet.id));
  const c = document.createElement("canvas"); c.width = 512; c.height = 256; const x = c.getContext("2d")!;
  const sea = new THREE.Color(th.skyTop).lerp(new THREE.Color(th.skyMid), 0.3); const land = new THREE.Color(th.top); const rock = new THREE.Color(th.side);
  const hex = (col: THREE.Color) => "#" + col.getHexString();
  x.fillStyle = hex(planet.kind === "boss" ? rock : sea); x.fillRect(0, 0, 512, 256);
  for (let i = 0; i < 46; i++) { x.fillStyle = hex(i % 3 ? land : rock); x.globalAlpha = 0.9; x.beginPath(); const cx = r() * 512, cy = 30 + r() * 196; x.ellipse(cx, cy, 20 + r() * 60, 10 + r() * 28, r() * 3, 0, 7); x.fill(); x.beginPath(); x.ellipse(cx - 512, cy, 20 + r() * 60, 10 + r() * 28, r() * 3, 0, 7); x.fill(); }
  x.globalAlpha = 0.28; x.fillStyle = "#fff"; for (let i = 0; i < 16; i++) { x.beginPath(); x.ellipse(r() * 512, r() * 256, 40 + r() * 70, 5 + r() * 9, 0, 0, 7); x.fill(); }
  x.globalAlpha = 1;
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = THREE.RepeatWrapping;
  void locked; return t;
}

interface PlanetObj { planet: Planet; group: THREE.Group; mesh: THREE.Mesh; r: number; locked: boolean; ring: THREE.Mesh; mark?: THREE.Sprite; pos: THREE.Vector3; spin: number; label: THREE.Sprite }

export class GalaxyMap {
  scene = new THREE.Scene();
  sky: Sky; light: Lighting; fx: Particles;
  mode: "galaxies" | "flight" = "galaxies";
  orbs: { g: THREE.Group; core: THREE.Mesh; id: string; base: THREE.Vector3 }[] = [];
  selected = 0;
  planets: PlanetObj[] = [];
  ship = new THREE.Group();
  astro: Actor;
  speed = 14;
  yaw = Math.PI; pitch = 0; roll = 0;
  cam: THREE.Camera;
  camPos = new V(); camLook = new V();
  fov = 60;
  contentRoot = new THREE.Group();
  t = 0;
  stars: THREE.Points;

  constructor(public gfx: Gfx, speederColor: string, outfit: string) {
    this.cam = gfx.camera;
    const th = THEMES.space;
    this.sky = new Sky(this.scene, th, 91);
    this.sky.decor.visible = true;
    this.light = new Lighting(this.scene, th, gfx.env);
    this.light.sun.castShadow = false;
    this.light.sun.position.set(40, 60, 30); this.light.sun.target.position.set(0, 0, 0);
    this.fx = new Particles(this.scene);
    this.scene.fog = new THREE.FogExp2("#050830", 0.0016);
    this.scene.add(this.contentRoot);
    // speeder with Astro
    const sp = makeSpeeder(speederColor); sp.scale.setScalar(1.1); this.ship.add(sp);
    this.astro = makeRobot({ outfit, height: 1.0 }); this.astro.root.position.set(0, 0.2, 0.1); this.astro.root.scale.setScalar(0.85); this.astro.play("Sitting"); this.ship.add(this.astro.root);
    this.scene.add(this.ship);
    // dust
    const n = 500; const pos = new Float32Array(n * 3); for (let i = 0; i < n; i++) pos.set([(Math.random() - 0.5) * 400, (Math.random() - 0.5) * 300, (Math.random() - 0.5) * 400], i * 3);
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    this.stars = new THREE.Points(g, new THREE.PointsMaterial({ size: 1.4, color: "#bcd0ff", sizeAttenuation: true, transparent: true, opacity: 0.7, depthWrite: false })); this.scene.add(this.stars);
    this.buildGalaxies();
  }

  // ───── galaxy select ─────
  private buildGalaxies() {
    this.clear();
    this.mode = "galaxies"; this.ship.visible = false;
    GALAXIES.forEach((gx, i) => {
      const g = new THREE.Group();
      const c = document.createElement("canvas"); c.width = 256; c.height = 256; const x = c.getContext("2d")!;
      const gr = x.createLinearGradient(0, 0, 256, 256); gr.addColorStop(0, gx.color); gr.addColorStop(1, gx.color2); x.fillStyle = gr; x.fillRect(0, 0, 256, 256);
      const r = rng(seedOf(gx.id)); x.globalAlpha = 0.35; x.fillStyle = "#fff"; for (let k = 0; k < 24; k++) { x.beginPath(); x.ellipse(r() * 256, r() * 256, 30 + r() * 50, 5 + r() * 12, r() * 3, 0, 7); x.fill(); }
      const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace;
      const core = new THREE.Mesh(new THREE.SphereGeometry(4, 40, 28), new THREE.MeshStandardMaterial({ map: tx, roughness: 0.5, emissive: gx.color, emissiveIntensity: 0.25 }));
      g.add(core);
      // spiral arms of points
      const n = 700; const pos = new Float32Array(n * 3), col = new Float32Array(n * 3); const cc = new THREE.Color(gx.color);
      for (let k = 0; k < n; k++) { const arm = k % 3; const rad = 5 + r() * 7; const a = rad * 0.55 + arm * 2.09 + (r() - 0.5) * 0.5; pos.set([Math.cos(a) * rad, (r() - 0.5) * 0.8, Math.sin(a) * rad], k * 3); const w = 0.6 + r() * 0.6; col.set([cc.r * w + 0.3, cc.g * w + 0.3, cc.b * w + 0.3], k * 3); }
      const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pos, 3)); pg.setAttribute("color", new THREE.BufferAttribute(col, 3));
      const disc = new THREE.Points(pg, new THREE.PointsMaterial({ size: 0.34, vertexColors: true, transparent: true, opacity: 0.95, depthWrite: false })); disc.rotation.x = 0.5; g.add(disc);
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(gx.color), blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.8 })); halo.scale.setScalar(26); g.add(halo);
      const base = new V((i - 4) * 19, Math.sin(i * 1.3) * 2, Math.cos(i * 0.9) * 4);
      g.position.copy(base); this.contentRoot.add(g); this.orbs.push({ g, core, id: gx.id, base });
    });
  }
  selectGalaxy(i: number) { this.selected = (i + GALAXIES.length) % GALAXIES.length; }

  clear() { while (this.contentRoot.children.length) this.contentRoot.remove(this.contentRoot.children[0]); this.orbs = []; this.planets = []; }

  // ───── flight ─────
  enterGalaxy(gid: string, startAtPlanet?: string) {
    this.clear(); this.mode = "flight"; this.ship.visible = true;
    const g = galaxyById(gid); const list = g.planets.map(planetById);
    const r = rng(seedOf(gid));
    const gx = GALAXIES.find((q) => q.id === gid)!;
    const nebula = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(gx.color), blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.45 })); nebula.scale.setScalar(480); nebula.position.set(0, -40, -140); this.contentRoot.add(nebula);
    list.forEach((pl, i) => {
      const locked = !!planetLock(pl.id);
      const a = i * 2.39996 + 0.4; const rad = 38 + Math.sqrt(i) * 17 + r() * 8;
      const pos = new V(Math.cos(a) * rad, Math.sin(i * 1.7) * 12 + (r() - 0.5) * 6, Math.sin(a) * rad * 0.9 - 20);
      const R = pl.kind === "boss" ? 8 : pl.kind === "extra" || pl.kind === "speed" || pl.kind === "void" ? 3.4 : 5.2;
      const grp = new THREE.Group(); grp.position.copy(pos);
      const mat = new THREE.MeshStandardMaterial({ map: planetTexture(pl, locked), roughness: 0.7, color: locked ? "#555a66" : "#ffffff", emissive: locked ? "#000" : THEMES[pl.theme].skyMid, emissiveIntensity: locked ? 0 : 0.18 });
      const mesh = new THREE.Mesh(pl.kind === "extra" || pl.kind === "speed" ? new THREE.IcosahedronGeometry(R, 2) : new THREE.SphereGeometry(R, 40, 28), mat); mesh.castShadow = false; grp.add(mesh);
      const atm = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(locked ? "#667" : THEMES[pl.theme].skyMid), blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.55 })); atm.scale.setScalar(R * 3.4); grp.add(atm);
      const ring = new THREE.Mesh(new THREE.RingGeometry(R * 1.45, R * 1.55, 64), new THREE.MeshBasicMaterial({ color: "#ffffff", transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false })); ring.rotation.x = Math.PI / 2.4; grp.add(ring);
      if (pl.kind === "boss") { const bring = new THREE.Mesh(new THREE.TorusGeometry(R * 1.35, 0.25, 8, 60), stdMat("#ff4a6a", { emissive: "#ff2a4a", emissiveIntensity: 1 })); bring.rotation.x = 1.3; grp.add(bring); }
      if (!locked && ui.save?.cleared[pl.id]) { const flag = new THREE.Group(); const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 2.4, 6), stdMat("#fff")); pole.position.y = 1.2; const cl = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.9), new THREE.MeshBasicMaterial({ color: "#3a8aff", side: THREE.DoubleSide })); cl.position.set(0.7, 2.0, 0); flag.add(pole, cl); flag.position.set(0, R - 0.1, 0); grp.add(flag); }
      let mark: THREE.Sprite | undefined;
      if (!locked && !ui.save?.cleared[pl.id]) { mark = textSprite("!", "#fff", "#ff3b5c", 1.0); mark.position.set(0, R + 3, 0); grp.add(mark); }
      if (locked) { const lk = textSprite("LOCKED", "#fff", "#555a70", 1.1); lk.position.set(0, R + 2.4, 0); grp.add(lk); }
      const label = textSprite(pl.name.toUpperCase().slice(0, 18), "#fff", "#2f6df0", 1.5); label.position.set(0, -R - 2.2, 0); label.visible = false; grp.add(label);
      this.contentRoot.add(grp);
      this.planets.push({ planet: pl, group: grp, mesh, r: R, locked, ring, mark, pos, spin: 0.05 + r() * 0.12, label });
    });
    // start near requested planet or at the edge
    const tgt = startAtPlanet ? this.planets.find((p) => p.planet.id === startAtPlanet) : undefined;
    if (tgt) { this.ship.position.copy(tgt.pos).add(new V(0, 4, tgt.r + 14)); this.yaw = Math.PI; } else { this.ship.position.set(0, 4, 95); this.yaw = Math.PI; }
    this.pitch = 0; this.speed = 8;
    this.camPos.copy(this.ship.position).add(new V(0, 4, 10)); this.camLook.copy(this.ship.position);
  }
  backToGalaxies() { this.buildGalaxies(); }

  update(dt: number) {
    this.t += dt;
    this.sky.update(this.cam, this.t);
    this.fx.update(dt);
    this.astro.update(dt);
    if (this.mode === "galaxies") {
      this.orbs.forEach((o, i) => {
        const sel = i === this.selected; const unlocked = galaxyUnlocked(o.id);
        o.core.rotation.y += dt * (sel ? 0.5 : 0.15); o.g.rotation.y += dt * 0.08;
        const s = sel ? 1.35 : 0.8; o.g.scale.lerp(new V(s, s, s), Math.min(1, dt * 5));
        (o.core.material as THREE.MeshStandardMaterial).color.set(unlocked ? "#ffffff" : "#444a58"); (o.core.material as THREE.MeshStandardMaterial).emissiveIntensity = unlocked ? (sel ? 0.5 : 0.2) : 0;
        o.g.position.y = o.base.y + Math.sin(this.t + i) * 0.4;
      });
      const sel = this.orbs[this.selected];
      const tx = sel.base.x; this.camPos.lerp(new V(tx, 3, 24), Math.min(1, dt * 3.5)); this.camLook.lerp(new V(tx, 0.5, 0), Math.min(1, dt * 4));
      this.cam.position.copy(this.camPos); this.cam.lookAt(this.camLook); (this.cam as THREE.PerspectiveCamera).fov = 50; (this.cam as THREE.PerspectiveCamera).updateProjectionMatrix();
      return;
    }
    // flight
    const mv = input.move;
    this.yaw -= mv.x * 1.5 * dt; this.pitch = THREE.MathUtils.clamp(this.pitch + mv.y * 1.1 * dt, -0.9, 0.9);
    if (Math.abs(mv.y) < 0.05) this.pitch *= 1 - Math.min(1, dt * 0.8);
    const boosting = input.boost || input.isDown("ShiftLeft", "ShiftRight");
    const target = boosting ? 46 : mv.y < -0.5 ? 6 : 15;
    this.speed += (target - this.speed) * Math.min(1, dt * (boosting ? 2.5 : 1.8));
    const dir = new V(Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), Math.cos(this.yaw) * Math.cos(this.pitch));
    this.ship.position.addScaledVector(dir, this.speed * dt);
    // soft bounds
    const off = this.ship.position.length(); if (off > 190) this.ship.position.multiplyScalar(1 - Math.min(1, (off - 190) * 0.002));
    this.roll += (-mv.x * 0.6 - this.roll) * Math.min(1, dt * 4);
    this.ship.rotation.set(-this.pitch, this.yaw, this.roll, "YXZ");
    this.ship.rotation.y = this.yaw;
    if (Math.random() < Math.min(1, this.speed / 20)) this.fx.emit(this.ship.position.clone().addScaledVector(dir, -2.2), boosting ? "#ffb02a" : "#5ac8ff", 1, 1, 0.4, boosting ? 0.9 : 0.5, 0, 0);
    // camera
    const back = dir.clone().multiplyScalar(-(9 + this.speed * 0.12)); const wantPos = this.ship.position.clone().add(back).add(new V(0, 3.6 + Math.abs(this.pitch), 0));
    this.camPos.lerp(wantPos, Math.min(1, dt * 4)); this.camLook.lerp(this.ship.position.clone().addScaledVector(dir, 6), Math.min(1, dt * 6));
    this.cam.position.copy(this.camPos); this.cam.lookAt(this.camLook);
    const pc = this.cam as THREE.PerspectiveCamera; pc.fov += ((boosting ? 78 : 58) - pc.fov) * Math.min(1, dt * 3); pc.updateProjectionMatrix();
    // planets
    let near: PlanetObj | null = null; let nd = 1e9;
    for (const p of this.planets) {
      p.mesh.rotation.y += dt * p.spin;
      const d = p.pos.distanceTo(this.ship.position) - p.r;
      if (d < nd) { nd = d; near = p; }
      if (p.mark) { p.mark.position.y = p.r + 3 + Math.sin(this.t * 3) * 0.4; }
      p.label.visible = false; (p.ring.material as THREE.MeshBasicMaterial).opacity = 0;
    }
    if (near && nd < 16) {
      near.label.visible = true; near.label.quaternion.copy(this.cam.quaternion);
      const m = near.ring.material as THREE.MeshBasicMaterial; m.opacity = 0.55 + Math.sin(this.t * 6) * 0.2; near.ring.scale.setScalar(1 + Math.sin(this.t * 4) * 0.03);
      if (ui.mapNear !== near.planet.id) { ui.mapNear = near.planet.id; ui.mapPlanet = near.planet.id; import("./store").then((s) => s.emit()); }
    } else if (ui.mapNear) { ui.mapNear = ""; import("./store").then((s) => s.emit()); }
    // collide with planets (push out)
    for (const p of this.planets) { const d = this.ship.position.distanceTo(p.pos); if (d < p.r + 1.8) { const n = this.ship.position.clone().sub(p.pos).normalize(); this.ship.position.copy(p.pos).addScaledVector(n, p.r + 1.8); this.speed *= 0.9; } }
  }
  nearPlanet(): PlanetObj | null { return this.planets.find((p) => p.planet.id === ui.mapNear) ?? null; }
}
export { PLANETS };
