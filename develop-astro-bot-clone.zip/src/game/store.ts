import { useSyncExternalStore } from "react";
import { PLANETS, GALAXIES, MAIN_GALAXIES, planetById, galaxyById, TOTAL_BOTS, type Gadget } from "./data";

export type Screen = "title" | "slots" | "hub" | "galaxies" | "map" | "level" | "results" | "gatcha" | "garage" | "collection" | "safari" | "credits";

export interface SaveData {
  slot: number;
  coins: number;
  bots: Record<string, number[]>;
  puzzles: Record<string, number[]>;
  cleared: Record<string, { time: number; coins: number }>;
  vortex: string[];
  vips: string[];
  gatcha: string[];
  outfit: string;
  speeder: string;
  seenIntro: boolean;
  playTime: number;
}

export interface Settings { music: number; sfx: number; unlockAll: boolean; shadows: boolean; bloom: boolean; invertY: boolean; }

export interface UIState {
  screen: Screen;
  paused: boolean;
  pauseTab: "main" | "controls" | "options";
  slot: number;
  save: SaveData | null;
  settings: Settings;
  loading: number; // 0..1
  ready: boolean;
  // in-level
  planetId: string;
  runCoins: number;
  coinPulse: number;
  runBots: boolean[];
  runPuzzles: boolean[];
  gadget: Gadget;
  hover: number;
  boost: number;
  time: number;
  banner: { title: string; sub: string; t: number } | null;
  toast: { text: string; t: number } | null;
  prompt: string;
  bossHp: number;
  bossMax: number;
  bossName: string;
  hint: string;
  results: null | { planetId: string; coins: number; bots: number; botsTotal: number; puzzles: number; puzzleTotal: number; time: number; newBest: boolean; vip?: string; vortex?: boolean; par?: number };
  // map
  mapGalaxy: string;
  mapPlanet: string;
  mapNear: string;
  gatchaResult: { id: string; name: string; emoji: string; rarity: number; dupe: boolean } | null;
  fade: boolean;
  version: number;
}

const SETTINGS_KEY = "astro-bot-web-settings";
const SAVE_KEY = (n: number) => `astro-bot-web-save-${n}`;

export const defaultSave = (slot: number): SaveData => ({
  slot, coins: 0, bots: {}, puzzles: {}, cleared: {}, vortex: [], vips: [], gatcha: [],
  outfit: "default", speeder: "white", seenIntro: false, playTime: 0,
});

function loadSettings(): Settings {
  try { const s = localStorage.getItem(SETTINGS_KEY); if (s) return { music: 0.6, sfx: 0.8, unlockAll: false, shadows: true, bloom: true, invertY: false, ...JSON.parse(s) }; } catch { /* ignore */ }
  return { music: 0.6, sfx: 0.8, unlockAll: false, shadows: true, bloom: true, invertY: false };
}

export const ui: UIState = {
  screen: "title", paused: false, pauseTab: "main", slot: 0, save: null, settings: loadSettings(), loading: 0, ready: false,
  planetId: "", runCoins: 0, coinPulse: 0, runBots: [], runPuzzles: [], gadget: "none", hover: 1, boost: 1, time: 0,
  banner: null, toast: null, prompt: "", bossHp: 0, bossMax: 0, bossName: "", hint: "", results: null,
  mapGalaxy: "gorilla", mapPlanet: "", mapNear: "", gatchaResult: null, fade: false, version: 0,
};

const listeners = new Set<() => void>();
let snapshot = { ...ui };
export function emit() { ui.version++; snapshot = { ...ui }; listeners.forEach((l) => l()); }
export function setUI(p: Partial<UIState>) { Object.assign(ui, p); emit(); }
export function useUI(): UIState {
  return useSyncExternalStore((cb) => { listeners.add(cb); return () => { listeners.delete(cb); }; }, () => snapshot);
}

export function saveSettings() { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(ui.settings)); } catch { /* ignore */ } }
export function patchSettings(p: Partial<Settings>) { ui.settings = { ...ui.settings, ...p }; saveSettings(); emit(); }

export function readSlot(n: number): SaveData | null {
  try { const s = localStorage.getItem(SAVE_KEY(n)); return s ? { ...defaultSave(n), ...JSON.parse(s) } : null; } catch { return null; }
}
export function persist() { if (ui.save) { try { localStorage.setItem(SAVE_KEY(ui.save.slot), JSON.stringify(ui.save)); } catch { /* ignore */ } } }
export function deleteSlot(n: number) { try { localStorage.removeItem(SAVE_KEY(n)); } catch { /* ignore */ } emit(); }
export function chooseSlot(n: number) {
  ui.save = readSlot(n) ?? defaultSave(n); ui.slot = n; persist(); emit();
}

// ───────── progress helpers ─────────
export const totalBots = (s: SaveData | null = ui.save) => (s ? Object.values(s.bots).reduce((a, b) => a + b.length, 0) + s.vips.length : 0);
export const totalPuzzles = (s: SaveData | null = ui.save) => (s ? Object.values(s.puzzles).reduce((a, b) => a + b.length, 0) : 0);
export const planetsCleared = (s: SaveData | null = ui.save) => (s ? Object.keys(s.cleared).length : 0);
export function completion(s: SaveData | null) {
  if (!s) return 0;
  const tot = TOTAL_BOTS + PLANETS.reduce((a, p) => a + p.puzzle, 0);
  const got = Object.values(s.bots).reduce((a, b) => a + b.length, 0) + totalPuzzles(s);
  return Math.min(100, Math.round((got / tot) * 100));
}
export const botsIn = (id: string) => ui.save?.bots[id]?.length ?? 0;
export const puzzlesIn = (id: string) => ui.save?.puzzles[id]?.length ?? 0;
const isCleared = (id: string) => !!ui.save?.cleared[id];

export function galaxyUnlocked(gid: string): boolean {
  if (ui.settings.unlockAll) return true;
  const idx = MAIN_GALAXIES.indexOf(gid);
  if (idx === 0) return true;
  if (idx > 0) { const prev = galaxyById(MAIN_GALAXIES[idx - 1]); const boss = prev.planets.map(planetById).find((p) => p.kind === "boss")!; return isCleared(boss.id); }
  if (gid === "lost") return (ui.save?.vortex.length ?? 0) >= 1;
  if (gid === "dejavu") return MAIN_GALAXIES.every((g) => galaxyById(g).planets.map(planetById).filter((p) => p.kind === "boss").every((p) => isCleared(p.id)));
  if (gid === "speedway" || gid === "void") return isCleared("space-bully-nebulax");
  return false;
}

/** returns null if unlocked, otherwise reason text */
export function planetLock(id: string): string | null {
  if (ui.settings.unlockAll) return null;
  const p = planetById(id);
  if (!galaxyUnlocked(p.galaxy)) return "Galaxy locked";
  const g = galaxyById(p.galaxy);
  const list = g.planets.map(planetById);
  const idx = list.indexOf(p);
  const mains = list.filter((q) => q.kind === "main");
  switch (p.kind) {
    case "main": { if (idx === 0) return null; const prev = list[idx - 1]; return isCleared(prev.id) ? null : `Clear ${prev.name} first`; }
    case "boss": {
      if (p.boss === "nebulax") return isCleared("playsquadron-go") ? null : "Clear PlaySquadron Go! first";
      if (!mains.every((m) => isCleared(m.id))) return "Clear all planets in this galaxy";
      const need = p.needBots ?? 0; return totalBots() >= need ? null : `Needs ${need} Bots (you have ${totalBots()})`;
    }
    case "vip": { const boss = list.find((q) => q.kind === "boss")!; return isCleared(boss.id) ? null : `Defeat ${boss.name} first`; }
    case "extra": { const open = mains.filter((m) => isCleared(m.id)).length; return open >= 2 ? null : "Clear 2 planets in this galaxy"; }
    case "lost": { const i = list.indexOf(p); const need = Math.ceil((i + 1) / 2); return (ui.save?.vortex.length ?? 0) >= need ? null : `Find ${need} Vortex portal${need > 1 ? "s" : ""}`; }
    case "final": return MAIN_GALAXIES.every((g2) => galaxyById(g2).planets.map(planetById).filter((q) => q.kind === "boss").every((q) => isCleared(q.id))) ? null : "Defeat all 5 galaxy bosses";
    case "credits": return isCleared("space-bully-nebulax") ? null : "Defeat Nebulax first";
    case "speed": case "void": return isCleared("space-bully-nebulax") ? null : "Defeat Nebulax first";
  }
  return null;
}
export const firstUnclearedIn = (gid: string) => galaxyById(gid).planets.find((id) => !isCleared(id) && !planetLock(id)) ?? galaxyById(gid).planets[0];
export const galaxyProgress = (gid: string) => { const g = galaxyById(gid); const done = g.planets.filter(isCleared).length; return { done, total: g.planets.length }; };
export { GALAXIES };

export function addToast(text: string) { setUI({ toast: { text, t: performance.now() } }); }
