// ─────────────────────────────────────────────────────────────
//  Static game data: galaxies, planets, themes, bots, collectibles
// ─────────────────────────────────────────────────────────────

export type Gadget = "none" | "frog" | "rocket" | "monkey" | "gloves";
export type PlanetKind = "main" | "boss" | "vip" | "extra" | "lost" | "final" | "credits" | "speed" | "void";
export type BossKey = "chewy" | "wako" | "venomara" | "leon" | "falcon" | "nebulax";

export interface Mix {
  mover?: number; crumble?: number; spring?: number; beam?: number; rotbar?: number; ice?: number; tower?: number;
  grunt?: number; fox?: number; flyer?: number; cannon?: number; boulder?: number; climb?: number;
}

export interface Planet {
  id: string;
  name: string;
  galaxy: string;
  kind: PlanetKind;
  theme: string;
  len: number; // number of path segments
  diff: number; // 1..5
  bots: number;
  puzzle: number;
  vortex?: boolean; // contains hidden warp-portal to the Lost Galaxy
  gadget?: Gadget;
  boss?: BossKey;
  vip?: string; // VIP bot rewarded
  needBots?: number;
  mix: Mix;
  timer?: number; // speedrun par (s)
  blurb: string;
}

export interface Galaxy {
  id: string;
  name: string;
  icon: string;
  color: string;
  color2: string;
  creature: string;
  planets: string[];
}

export interface Theme {
  skyTop: string; skyMid: string; skyBot: string; fog: string; fogD: number;
  top: string; side: string; alt: string; accent: string; prop: string; sun: string; stars?: boolean;
  music: number; scale: "major" | "minor" | "lyd";
  bg: string; // background decoration kind
}

export const THEMES: Record<string, Theme> = {
  meadow: { skyTop: "#3d8bff", skyMid: "#8fd0ff", skyBot: "#e9f8ff", fog: "#bfe6ff", fogD: 0.011, top: "#7fe05a", side: "#a86b3c", alt: "#ffe066", accent: "#ff6fa8", prop: "tree", sun: "#fff4d6", music: 60, scale: "major", bg: "clouds" },
  canyon: { skyTop: "#ff8a4c", skyMid: "#ffc08a", skyBot: "#fff0d0", fog: "#ffd9aa", fogD: 0.012, top: "#f2b36c", side: "#c4673a", alt: "#ffe9b0", accent: "#ff5a3c", prop: "rock", sun: "#ffe2b8", music: 57, scale: "lyd", bg: "mesas" },
  ruins: { skyTop: "#1f8f7a", skyMid: "#74d4b0", skyBot: "#e4ffe6", fog: "#a5e8c4", fogD: 0.014, top: "#59c46a", side: "#8d8a6a", alt: "#d8d29a", accent: "#ffd23c", prop: "pillar", sun: "#fffbe0", music: 55, scale: "minor", bg: "clouds" },
  factory: { skyTop: "#5a8ee0", skyMid: "#a8c8f0", skyBot: "#f0f6ff", fog: "#c8dcf5", fogD: 0.012, top: "#ffcc33", side: "#5a6475", alt: "#ff9d2e", accent: "#2f6df0", prop: "crate", sun: "#ffffff", music: 62, scale: "major", bg: "clouds" },
  retro: { skyTop: "#10052e", skyMid: "#3b1a7a", skyBot: "#ff4fa3", fog: "#42217d", fogD: 0.012, top: "#35e8ff", side: "#2a1a66", alt: "#ff4fd8", accent: "#fffb4f", prop: "voxel", sun: "#ffb3ff", stars: true, music: 64, scale: "minor", bg: "grid" },
  beach: { skyTop: "#18b6ff", skyMid: "#7fe3ff", skyBot: "#fff6d8", fog: "#aef0ff", fogD: 0.010, top: "#ffe9a6", side: "#d9a45f", alt: "#6be3d8", accent: "#ff7a59", prop: "palm", sun: "#fffbe8", music: 62, scale: "major", bg: "sea" },
  snow: { skyTop: "#5c7fd6", skyMid: "#a9c3f2", skyBot: "#f3f7ff", fog: "#d6e4fa", fogD: 0.014, top: "#f4fbff", side: "#9bc2e6", alt: "#bfe4ff", accent: "#4f8bff", prop: "pine", sun: "#f2f6ff", music: 53, scale: "minor", bg: "clouds" },
  casino: { skyTop: "#1c0733", skyMid: "#59124f", skyBot: "#ff6a5c", fog: "#4a1245", fogD: 0.013, top: "#d62f5b", side: "#2b0f3a", alt: "#ffd24a", accent: "#ffd24a", prop: "chip", sun: "#ffd9a8", stars: true, music: 58, scale: "lyd", bg: "neon" },
  night: { skyTop: "#05031c", skyMid: "#1b1250", skyBot: "#4a2c8a", fog: "#241a5e", fogD: 0.014, top: "#7b6bff", side: "#2b2468", alt: "#b9a8ff", accent: "#ffe34f", prop: "lantern", sun: "#a8b8ff", stars: true, music: 55, scale: "minor", bg: "moon" },
  desert: { skyTop: "#2fa3ff", skyMid: "#9ad8ff", skyBot: "#fff1c4", fog: "#ffeabd", fogD: 0.012, top: "#f7d27a", side: "#c99a4a", alt: "#fff0b0", accent: "#27c2a8", prop: "cactus", sun: "#fff6d0", music: 57, scale: "lyd", bg: "pyramids" },
  sky: { skyTop: "#6fb7ff", skyMid: "#c7e6ff", skyBot: "#ffffff", fog: "#e1f2ff", fogD: 0.008, top: "#ffffff", side: "#c9defa", alt: "#ffe6f2", accent: "#ff6fa8", prop: "balloon", sun: "#ffffff", music: 64, scale: "major", bg: "clouds" },
  ocean: { skyTop: "#0a4aa0", skyMid: "#1f9bd1", skyBot: "#a7f0ff", fog: "#2aa6d6", fogD: 0.03, top: "#53e0c2", side: "#2a7aa8", alt: "#b4fff0", accent: "#ff7ab8", prop: "coral", sun: "#c8f7ff", music: 56, scale: "major", bg: "bubbles" },
  spooky: { skyTop: "#150a2e", skyMid: "#3c1d62", skyBot: "#8a4a9a", fog: "#3a1d58", fogD: 0.02, top: "#8f5ad6", side: "#3b2a55", alt: "#ff9d3c", accent: "#ff9d3c", prop: "tomb", sun: "#d6b8ff", stars: true, music: 52, scale: "minor", bg: "moon" },
  candy: { skyTop: "#ff7ac8", skyMid: "#ffc2e6", skyBot: "#fff2fa", fog: "#ffd4ee", fogD: 0.012, top: "#fff0d0", side: "#ff8fb8", alt: "#8fe9ff", accent: "#ff4f9a", prop: "lolli", sun: "#fff5fa", music: 65, scale: "major", bg: "clouds" },
  space: { skyTop: "#02030f", skyMid: "#0a1045", skyBot: "#1f2e8a", fog: "#0a1245", fogD: 0.006, top: "#d6e4ff", side: "#4a5a9a", alt: "#6bffe0", accent: "#ff5ac8", prop: "asteroid", sun: "#cfe0ff", stars: true, music: 59, scale: "lyd", bg: "planets" },
  lava: { skyTop: "#3a0a0a", skyMid: "#a02a12", skyBot: "#ffb04a", fog: "#8a2410", fogD: 0.018, top: "#5a4a4a", side: "#2a1a1a", alt: "#ff8a2a", accent: "#ffd23c", prop: "vent", sun: "#ffc890", music: 51, scale: "minor", bg: "lava" },
  neon: { skyTop: "#050520", skyMid: "#13135a", skyBot: "#3a1d9a", fog: "#14145c", fogD: 0.012, top: "#1fffd4", side: "#14143f", alt: "#ff3fd0", accent: "#fff03f", prop: "speaker", sun: "#b0b8ff", stars: true, music: 66, scale: "major", bg: "neon" },
  trash: { skyTop: "#6a8a6a", skyMid: "#a8c8a0", skyBot: "#eef6e0", fog: "#b8d4b0", fogD: 0.016, top: "#8fb070", side: "#6a5a48", alt: "#d4c890", accent: "#ff8a3c", prop: "can", sun: "#fff4d0", music: 54, scale: "minor", bg: "clouds" },
  dojo: { skyTop: "#ff5a6a", skyMid: "#ffb08a", skyBot: "#fff0d8", fog: "#ffc8a8", fogD: 0.013, top: "#e6d4a8", side: "#a8403a", alt: "#ffffff", accent: "#ff3a4a", prop: "torii", sun: "#fff0d6", music: 58, scale: "minor", bg: "mesas" },
  boss: { skyTop: "#1a1450", skyMid: "#4a2a9a", skyBot: "#ff8a6a", fog: "#3a2488", fogD: 0.010, top: "#dfe8ff", side: "#5a5a9a", alt: "#ffd23c", accent: "#ff4f6a", prop: "rock", sun: "#ffd9b8", stars: true, music: 60, scale: "minor", bg: "planets" },
};

const P = (p: Partial<Planet> & Pick<Planet, "id" | "name" | "galaxy" | "theme">): Planet => ({
  kind: "main", len: 16, diff: 1, bots: 6, puzzle: 1, mix: {}, blurb: "", ...p,
});

export const PLANETS: Planet[] = [
  // ───────── GORILLA NEBULA ─────────
  P({ id: "sky-garden", name: "Sky Garden", galaxy: "gorilla", theme: "meadow", len: 15, diff: 1, bots: 6, vortex: true, mix: { spring: 1, grunt: 1, mover: 0.5 }, blurb: "A flamingo-filled paradise floating above the clouds." }),
  P({ id: "creamy-canyon", name: "Creamy Canyon", galaxy: "gorilla", theme: "canyon", len: 16, diff: 1, bots: 6, gadget: "frog", mix: { spring: 1, mover: 1, fox: 0.6, grunt: 0.6 }, blurb: "Hop through the canyon with a frog-powered leap." }),
  P({ id: "az-tech-trail", name: "Az-Tech Trail", galaxy: "gorilla", theme: "ruins", len: 17, diff: 2, bots: 6, gadget: "monkey", mix: { climb: 1, beam: 1, crumble: 0.6, grunt: 1 }, blurb: "Ancient ruins full of climbable vines and crumbling stones." }),
  P({ id: "construction-derby", name: "Construction Derby", galaxy: "gorilla", theme: "factory", len: 17, diff: 2, bots: 6, vortex: true, mix: { mover: 1.2, rotbar: 0.8, boulder: 0.6, grunt: 0.8 }, blurb: "Hard hats on! Keep an eye out for swinging wrecking arms." }),
  P({ id: "rolling-star-sola", name: "Rolling Star Sola", galaxy: "gorilla", theme: "sky", len: 14, diff: 2, bots: 5, mix: { boulder: 1.5, spring: 1, beam: 1 }, blurb: "Dodge giant rolling stars across the sunlit sky." }),
  P({ id: "mighty-chewy", name: "Mighty Chewy", galaxy: "gorilla", theme: "boss", kind: "boss", boss: "chewy", len: 1, diff: 2, bots: 1, puzzle: 1, needBots: 20, vip: "Monkey Stalker", mix: {}, blurb: "A gigantic, grumpy beast has swallowed one of your friends!" }),
  P({ id: "apes-on-the-loose", name: "Apes On The Loose", galaxy: "gorilla", theme: "meadow", kind: "vip", len: 15, diff: 2, bots: 6, vip: "Spike Catcher", mix: { fox: 2, spring: 1, mover: 0.5 }, blurb: "The monkeys are out of the cage! Round them all up." }),
  P({ id: "crumble-rumble-1", name: "Crumble Rumble 1", galaxy: "gorilla", theme: "canyon", kind: "extra", len: 11, diff: 2, bots: 3, puzzle: 1, mix: { crumble: 3, spring: 0.5 }, blurb: "Don't stand still – everything falls apart!" }),
  P({ id: "retro-rampage-1", name: "Retro Rampage 1", galaxy: "gorilla", theme: "retro", kind: "extra", len: 11, diff: 2, bots: 3, puzzle: 1, mix: { grunt: 1, beam: 1, mover: 0.6 }, blurb: "Blast back to the polygon-era with a chunky retro run." }),

  // ───────── TENTACLE SYSTEM ─────────
  P({ id: "go-go-archipelago", name: "Go-Go Archipelago!", galaxy: "tentacle", theme: "beach", len: 16, diff: 2, bots: 6, vortex: true, mix: { spring: 1, mover: 1, grunt: 1, flyer: 0.4 }, blurb: "Island hop across a sun-soaked tropical sea." }),
  P({ id: "downsize-surprise", name: "Downsize Surprise", galaxy: "tentacle", theme: "candy", len: 16, diff: 2, bots: 6, vortex: true, gadget: "gloves", mix: { spring: 1, rotbar: 0.6, grunt: 1.2, beam: 0.8 }, blurb: "Everything is huge! Big gloves for even bigger fun." }),
  P({ id: "trunk-of-funk", name: "Trunk Of Funk", galaxy: "tentacle", theme: "ruins", len: 17, diff: 3, bots: 6, mix: { climb: 1.2, mover: 1, spring: 1, flyer: 0.6 }, blurb: "Groove your way up a giant swaying trunk." }),
  P({ id: "wormy-passage", name: "Wormy Passage", galaxy: "tentacle", theme: "trash", len: 17, diff: 3, bots: 6, mix: { crumble: 1.2, rotbar: 1, grunt: 1.2, beam: 1 }, blurb: "Squeeze through the wriggling worm tunnels." }),
  P({ id: "wako-tako", name: "Wako Tako", galaxy: "tentacle", theme: "ocean", kind: "boss", boss: "wako", len: 1, diff: 3, bots: 1, needBots: 60, vip: "Boy", mix: {}, blurb: "A tangled octopus wants a hug... or a fight." }),
  P({ id: "bot-of-war", name: "Bot Of War", galaxy: "tentacle", theme: "snow", kind: "vip", len: 15, diff: 3, bots: 6, vip: "Dad of Boy", mix: { fox: 1, grunt: 1.5, mover: 0.8, ice: 1 }, blurb: "A stern warrior bot guards a frosty realm." }),
  P({ id: "retro-rampage-2", name: "Retro Rampage 2", galaxy: "tentacle", theme: "retro", kind: "extra", len: 11, diff: 3, bots: 3, mix: { grunt: 1, rotbar: 1, mover: 1 }, blurb: "More polygons, more problems." }),
  P({ id: "pumpkin-peril", name: "Pumpkin Peril", galaxy: "tentacle", theme: "spooky", kind: "extra", len: 11, diff: 3, bots: 3, mix: { grunt: 1.5, crumble: 1, flyer: 1 }, blurb: "The pumpkin patch has teeth." }),
  P({ id: "fragile-frenzy", name: "Fragile Frenzy", galaxy: "tentacle", theme: "ocean", kind: "extra", len: 11, diff: 3, bots: 3, mix: { crumble: 2.5, spring: 1 }, blurb: "Glass platforms: don't break the rhythm." }),
  P({ id: "crumble-rumble-2", name: "Crumble Rumble 2", galaxy: "tentacle", theme: "beach", kind: "extra", len: 11, diff: 3, bots: 3, mix: { crumble: 3, mover: 0.8 }, blurb: "Sand castles crumble fast." }),
  P({ id: "cut-n-grind", name: "Cut 'N Grind", galaxy: "tentacle", theme: "factory", kind: "extra", len: 11, diff: 3, bots: 3, mix: { rotbar: 2.5, beam: 1.5 }, blurb: "Spinning blades and tight timing." }),
  P({ id: "dashing-dillo", name: "Dashing Dillo", galaxy: "tentacle", theme: "canyon", kind: "extra", len: 11, diff: 3, bots: 3, mix: { boulder: 2, spring: 1 }, blurb: "Roll with the armadillos!" }),

  // ───────── SERPENT STARWAY ─────────
  P({ id: "slo-mo-casino", name: "Slo-Mo Casino", galaxy: "serpent", theme: "casino", len: 17, diff: 3, bots: 6, vortex: true, mix: { rotbar: 1, mover: 1.3, spring: 1, cannon: 0.6, grunt: 0.8 }, blurb: "Bet on slow-motion in the glitziest casino in space." }),
  P({ id: "bathhouse-battle", name: "Bathhouse Battle", galaxy: "serpent", theme: "dojo", len: 17, diff: 3, bots: 6, vortex: true, mix: { ice: 1, grunt: 1.5, fox: 0.8, mover: 1 }, blurb: "Steamy brawls in the slippery bathhouse." }),
  P({ id: "free-big-brother", name: "Free Big Brother!", galaxy: "serpent", theme: "space", len: 17, diff: 3, bots: 6, mix: { cannon: 1.2, mover: 1.2, flyer: 0.8, beam: 1 }, blurb: "Break your big bro out of the space prison." }),
  P({ id: "trapped-in-time", name: "Trapped In Time", galaxy: "serpent", theme: "desert", len: 18, diff: 4, bots: 6, mix: { crumble: 1.2, mover: 1.5, rotbar: 1 }, blurb: "Platforms speed up and slow down inside a giant hourglass." }),
  P({ id: "lady-venomara", name: "Lady Venomara", galaxy: "serpent", theme: "boss", kind: "boss", boss: "venomara", len: 1, diff: 4, bots: 1, needBots: 100, vip: "Raider Dude", mix: {}, blurb: "She's coiled and ready to strike." }),
  P({ id: "dude-raiding", name: "Dude Raiding", galaxy: "serpent", theme: "ruins", kind: "vip", len: 16, diff: 4, bots: 6, vip: "Treasure Hunter", mix: { climb: 1, beam: 1.2, crumble: 1, cannon: 0.6 }, blurb: "Treasure, traps and a very questionable rope." }),
  P({ id: "magnetic-mayhem", name: "Magnetic Mayhem", galaxy: "serpent", theme: "factory", kind: "extra", len: 11, diff: 4, bots: 3, mix: { mover: 2.5, rotbar: 1 }, blurb: "Magnets everywhere!" }),
  P({ id: "ropeway-rally", name: "Ropeway Rally", galaxy: "serpent", theme: "sky", kind: "extra", len: 11, diff: 4, bots: 3, mix: { mover: 2.5, beam: 1.5 }, blurb: "Cable cars in the clouds." }),
  P({ id: "rolling-star-luna", name: "Rolling Star Luna", galaxy: "serpent", theme: "night", kind: "extra", len: 11, diff: 4, bots: 3, mix: { boulder: 2.5, spring: 1 }, blurb: "Moonlit rolling stars." }),
  P({ id: "swinging-sentries", name: "Swinging Sentries", galaxy: "serpent", theme: "casino", kind: "extra", len: 11, diff: 4, bots: 3, mix: { rotbar: 2.5, cannon: 1 }, blurb: "Timing is everything." }),
  P({ id: "rolling-rampage", name: "Rolling Rampage", galaxy: "serpent", theme: "snow", kind: "extra", len: 11, diff: 4, bots: 3, mix: { boulder: 3, ice: 1 }, blurb: "Snowballs, but meaner." }),
  P({ id: "retro-rampage-3", name: "Retro Rampage 3", galaxy: "serpent", theme: "retro", kind: "extra", len: 12, diff: 4, bots: 3, mix: { grunt: 1.5, cannon: 1, rotbar: 1 }, blurb: "Even more retro." }),
  P({ id: "crumble-rumble-3", name: "Crumble Rumble 3", galaxy: "serpent", theme: "casino", kind: "extra", len: 12, diff: 4, bots: 3, mix: { crumble: 3.5 }, blurb: "Jackpot or bust." }),

  // ───────── CAMO COSMOS ─────────
  P({ id: "hieroglitch-pyramid", name: "Hieroglitch Pyramid", galaxy: "camo", theme: "desert", len: 18, diff: 4, bots: 6, vortex: true, mix: { crumble: 1, rotbar: 1, grunt: 1.2, climb: 0.8, spring: 0.6 }, blurb: "A glitchy pyramid with a mind of its own." }),
  P({ id: "balloon-breeze", name: "Balloon Breeze", galaxy: "camo", theme: "sky", len: 17, diff: 4, bots: 6, vortex: true, gadget: "rocket", mix: { flyer: 1.3, spring: 1, mover: 1 }, blurb: "Rocket boost through a sky of drifting balloons." }),
  P({ id: "bubbling-under", name: "Bubbling Under", galaxy: "camo", theme: "ocean", len: 17, diff: 4, bots: 6, mix: { spring: 1.5, mover: 1.2, grunt: 1, crumble: 0.6 }, blurb: "Deep sea bounce and bubble." }),
  P({ id: "spooky-time", name: "Spooky Time", galaxy: "camo", theme: "spooky", len: 17, diff: 4, bots: 6, mix: { flyer: 1.2, grunt: 1.5, crumble: 1, rotbar: 0.6 }, blurb: "Ghouls and graveyards after dark." }),
  P({ id: "mecha-leon", name: "Mecha Leon", galaxy: "camo", theme: "boss", kind: "boss", boss: "leon", len: 1, diff: 4, bots: 1, needBots: 150, vip: "Energetic Blob", mix: {}, blurb: "A cunning mechanical chameleon blends into the arena." }),
  P({ id: "going-loco", name: "Going Loco", galaxy: "camo", theme: "candy", kind: "vip", len: 16, diff: 4, bots: 6, vip: "Blobby Roller", mix: { spring: 1.5, ice: 1, mover: 1, grunt: 1 }, blurb: "Roll, bounce and sing with the blobs." }),
  P({ id: "vertical-velocity", name: "Vertical Velocity", galaxy: "camo", theme: "ruins", kind: "extra", len: 12, diff: 4, bots: 3, mix: { tower: 3, climb: 1, spring: 1 }, blurb: "Up, up and away." }),
  P({ id: "splashing-sprint", name: "Splashing Sprint", galaxy: "camo", theme: "ocean", kind: "extra", len: 11, diff: 4, bots: 3, mix: { mover: 2, spring: 1.5 }, blurb: "Make a splash." }),
  P({ id: "crumble-rumble-4", name: "Crumble Rumble 4", galaxy: "camo", theme: "desert", kind: "extra", len: 12, diff: 4, bots: 3, mix: { crumble: 3.5, spring: 0.5 }, blurb: "Sinking sands." }),
  P({ id: "follow-the-light", name: "Follow The Light", galaxy: "camo", theme: "night", kind: "extra", len: 11, diff: 4, bots: 3, mix: { beam: 2, crumble: 1.5, flyer: 0.6 }, blurb: "Stick to the glowing path." }),
  P({ id: "retro-rampage-4", name: "Retro Rampage 4", galaxy: "camo", theme: "retro", kind: "extra", len: 12, diff: 4, bots: 3, mix: { grunt: 2, rotbar: 1.2, mover: 1 }, blurb: "Pixel-perfect pain." }),
  P({ id: "boing-bonanza", name: "Boing! Bonanza", galaxy: "camo", theme: "candy", kind: "extra", len: 11, diff: 4, bots: 3, mix: { spring: 4 }, blurb: "Springs. So many springs." }),

  // ───────── FEATHER CLUSTER ─────────
  P({ id: "djinny-of-the-lamp", name: "Djinny Of The Lamp", galaxy: "feather", theme: "desert", len: 18, diff: 4, bots: 7, vortex: true, mix: { flyer: 1, mover: 1.2, grunt: 1, spring: 1, rotbar: 0.6 }, blurb: "Rub the lamp and let the chaos begin." }),
  P({ id: "frozen-meal", name: "Frozen Meal", galaxy: "feather", theme: "snow", len: 18, diff: 4, bots: 7, vortex: true, mix: { ice: 1.5, fox: 1, grunt: 1.2, crumble: 0.8 }, blurb: "Slippery slopes in the deep-freeze." }),
  P({ id: "luna-sola", name: "Luna Sola", galaxy: "feather", theme: "night", len: 18, diff: 5, bots: 7, mix: { mover: 1.5, spring: 1, flyer: 1, beam: 1 }, blurb: "A moonlit mirror of Sola's sunny sky." }),
  P({ id: "orbital-blitz", name: "Orbital Blitz", galaxy: "feather", theme: "space", len: 18, diff: 5, bots: 7, mix: { cannon: 1.5, mover: 1.5, rotbar: 1, flyer: 0.8 }, blurb: "Dodge orbital bombardment above the planet." }),
  P({ id: "cannon-brawl", name: "Cannon Brawl", galaxy: "feather", theme: "factory", len: 18, diff: 5, bots: 7, mix: { cannon: 2.5, mover: 1, boulder: 0.8, grunt: 1 }, blurb: "Cannons ahoy!" }),
  P({ id: "falcon-mcfly", name: "Falcon McFly", galaxy: "feather", theme: "boss", kind: "boss", boss: "falcon", len: 1, diff: 5, bots: 1, needBots: 200, vip: "Machine Hunter", mix: {}, blurb: "A fiery falcon rules the roost." }),
  P({ id: "machine-learning", name: "Machine Learning", galaxy: "feather", theme: "ruins", kind: "vip", len: 17, diff: 5, bots: 7, vip: "Aloof Huntress", mix: { fox: 2, flyer: 1, cannon: 1, mover: 1 }, blurb: "Mechanical beasts roam the grasslands." }),
  P({ id: "slowdown-showdown", name: "Slowdown Showdown", galaxy: "feather", theme: "casino", kind: "extra", len: 12, diff: 5, bots: 3, mix: { mover: 2, rotbar: 2 }, blurb: "Time bends around you." }),
  P({ id: "to-the-beat", name: "To The Beat!", galaxy: "feather", theme: "neon", kind: "extra", len: 12, diff: 5, bots: 3, mix: { mover: 2, spring: 2, crumble: 1 }, blurb: "Hop in time with the music." }),
  P({ id: "crumble-rumble-5", name: "Crumble Rumble 5", galaxy: "feather", theme: "snow", kind: "extra", len: 12, diff: 5, bots: 3, mix: { crumble: 4, ice: 1 }, blurb: "Ice cracks beneath your feet." }),
  P({ id: "shocking-behavior", name: "Shocking Behavior", galaxy: "feather", theme: "neon", kind: "extra", len: 12, diff: 5, bots: 3, mix: { rotbar: 3, cannon: 1 }, blurb: "Zap!" }),
  P({ id: "djinnys-revenge", name: "Djinny's Revenge", galaxy: "feather", theme: "desert", kind: "extra", len: 12, diff: 5, bots: 3, mix: { flyer: 2, mover: 2, crumble: 1 }, blurb: "He's back, and he's mad." }),
  P({ id: "retro-rampage-5", name: "Retro Rampage 5", galaxy: "feather", theme: "retro", kind: "extra", len: 13, diff: 5, bots: 3, mix: { grunt: 2, rotbar: 1.5, cannon: 1.2, mover: 1.2 }, blurb: "The final retro run." }),
  P({ id: "birdy-barrage", name: "Birdy Barrage", galaxy: "feather", theme: "sky", kind: "extra", len: 12, diff: 5, bots: 3, mix: { flyer: 3, spring: 1.2 }, blurb: "A flock of angry birds." }),

  // ───────── LOST GALAXY ─────────
  P({ id: "fan-club", name: "Fan Club", galaxy: "lost", theme: "neon", kind: "lost", len: 14, diff: 3, bots: 5, mix: { spring: 1.5, mover: 1, grunt: 1 }, blurb: "Your biggest fans have built a stage." }),
  P({ id: "funky-fungi", name: "Funky Fungi", galaxy: "lost", theme: "candy", kind: "lost", len: 14, diff: 3, bots: 5, mix: { spring: 3, beam: 0.8, grunt: 0.8 }, blurb: "Bouncy mushrooms galore." }),
  P({ id: "light-bulb-limbo", name: "Light Bulb Limbo", galaxy: "lost", theme: "night", kind: "lost", len: 14, diff: 3, bots: 5, mix: { beam: 2, mover: 1, crumble: 1 }, blurb: "Follow the bulbs through the dark." }),
  P({ id: "boxel-bust-up", name: "Boxel Bust-Up", galaxy: "lost", theme: "retro", kind: "lost", len: 14, diff: 4, bots: 5, mix: { grunt: 2, rotbar: 1, mover: 1.5 }, blurb: "Smash the boxel bosses." }),
  P({ id: "furnace-fever", name: "Furnace Fever", galaxy: "lost", theme: "lava", kind: "lost", len: 14, diff: 4, bots: 5, mix: { crumble: 1.5, rotbar: 1.5, spring: 1, cannon: 0.8 }, blurb: "It's getting hot in here." }),
  P({ id: "ghouls-and-bots", name: "Ghouls & Bots", galaxy: "lost", theme: "spooky", kind: "lost", len: 14, diff: 4, bots: 5, mix: { flyer: 1.5, grunt: 2, crumble: 1 }, blurb: "Who you gonna call?" }),
  P({ id: "rocket-pull-power", name: "Rocket Pull Power!", galaxy: "lost", theme: "space", kind: "lost", len: 14, diff: 4, gadget: "rocket", bots: 5, mix: { flyer: 1, mover: 1, cannon: 1 }, blurb: "Pull back and launch!" }),
  P({ id: "danger-dojo", name: "Danger Dojo", galaxy: "lost", theme: "dojo", kind: "lost", len: 14, diff: 4, gadget: "gloves", bots: 5, mix: { grunt: 2, rotbar: 1.5, beam: 1.5 }, blurb: "Train with the masters." }),
  P({ id: "high-suction-hero", name: "High-Suction Hero", galaxy: "lost", theme: "trash", kind: "lost", len: 14, diff: 4, bots: 5, mix: { spring: 1, grunt: 1.5, climb: 1 }, blurb: "Vacuum up the mess." }),
  P({ id: "turtles-in-trash", name: "Turtles In Trash", galaxy: "lost", theme: "ocean", kind: "lost", len: 14, diff: 4, bots: 5, mix: { grunt: 1.5, mover: 1.5, spring: 1 }, blurb: "Rescue the turtles from the litter." }),
  P({ id: "final-encore", name: "Final Encore", galaxy: "lost", theme: "neon", kind: "lost", len: 20, diff: 5, bots: 6, mix: { mover: 2, rotbar: 1.5, crumble: 1.5, cannon: 1, spring: 1 }, blurb: "The grand finale of the Lost Galaxy." }),

  // ───────── DÉJÀ VU DIMENSION ─────────
  P({ id: "playsquadron-go", name: "PlaySquadron Go!", galaxy: "dejavu", theme: "space", kind: "final", len: 20, diff: 5, bots: 0, puzzle: 2, mix: { flyer: 1.5, cannon: 1.5, mover: 2, rotbar: 1 }, blurb: "Dash through the stars in a classic arcade-flavoured flight." }),
  P({ id: "space-bully-nebulax", name: "Space Bully Nebulax", galaxy: "dejavu", theme: "boss", kind: "boss", boss: "nebulax", len: 1, diff: 5, bots: 0, puzzle: 1, vip: "Great Bot Leader", mix: {}, blurb: "The final showdown with the Space Bully himself." }),
  P({ id: "credits-clash", name: "Credits Clash", galaxy: "dejavu", theme: "neon", kind: "credits", len: 12, diff: 2, bots: 0, puzzle: 1, mix: { spring: 1, mover: 1 }, blurb: "A victory lap with every bot you've rescued." }),

  // ───────── STELLAR SPEEDWAY (post-game speedruns) ─────────
  P({ id: "building-speed", name: "Building Speed", galaxy: "speedway", theme: "factory", kind: "speed", len: 12, diff: 3, bots: 1, puzzle: 0, timer: 55, mix: { mover: 1, spring: 1.5 }, blurb: "Race the clock through the construction site." }),
  P({ id: "helium-heights", name: "Helium Heights", galaxy: "speedway", theme: "sky", kind: "speed", len: 12, diff: 3, bots: 1, puzzle: 0, timer: 60, mix: { spring: 2, flyer: 1 }, blurb: "Float to the top – fast." }),
  P({ id: "let-it-slide", name: "Let It Slide", galaxy: "speedway", theme: "snow", kind: "speed", len: 12, diff: 3, bots: 1, puzzle: 0, timer: 55, mix: { ice: 3, mover: 1 }, blurb: "Slide your way to a record." }),
  P({ id: "spring-loaded-run", name: "Spring-Loaded Run", galaxy: "speedway", theme: "candy", kind: "speed", len: 12, diff: 3, bots: 1, puzzle: 0, timer: 50, mix: { spring: 4 }, blurb: "Boing, boing, boing!" }),
  P({ id: "rising-heat", name: "Rising Heat", galaxy: "speedway", theme: "lava", kind: "speed", len: 12, diff: 4, bots: 1, puzzle: 0, timer: 60, mix: { crumble: 1.5, spring: 1.5, mover: 1 }, blurb: "Outrun the heat." }),

  // ───────── VICIOUS VOID (post-game challenge) ─────────
  P({ id: "void-gauntlet", name: "Vicious Void: Gauntlet", galaxy: "void", theme: "night", kind: "void", len: 14, diff: 5, bots: 1, puzzle: 0, mix: { rotbar: 2, mover: 2, crumble: 2, cannon: 1 }, blurb: "No checkpoints. No mercy." }),
  P({ id: "void-tower", name: "Vicious Void: Tower", galaxy: "void", theme: "space", kind: "void", len: 14, diff: 5, bots: 1, puzzle: 0, mix: { tower: 4, beam: 2, flyer: 1 }, blurb: "A deadly climb." }),
  P({ id: "void-pit", name: "Vicious Void: Pit", galaxy: "void", theme: "lava", kind: "void", len: 14, diff: 5, bots: 1, puzzle: 0, mix: { crumble: 3, cannon: 2, boulder: 1 }, blurb: "Don't look down." }),
  P({ id: "void-glitch", name: "Vicious Void: Glitch", galaxy: "void", theme: "neon", kind: "void", len: 14, diff: 5, bots: 1, puzzle: 0, mix: { mover: 3, spring: 2, rotbar: 2 }, blurb: "Reality is glitching." }),
];

export const GALAXIES: Galaxy[] = [
  { id: "gorilla", name: "Gorilla Nebula", icon: "🦍", color: "#4fd06a", color2: "#1c7f3a", creature: "Gorilla", planets: [] },
  { id: "tentacle", name: "Tentacle System", icon: "🐙", color: "#ff5ab4", color2: "#a01f78", creature: "Octopus", planets: [] },
  { id: "serpent", name: "Serpent Starway", icon: "🐍", color: "#34d8e0", color2: "#127a9a", creature: "Cobra", planets: [] },
  { id: "camo", name: "Camo Cosmos", icon: "🦎", color: "#ff9c3a", color2: "#b3501a", creature: "Chameleon", planets: [] },
  { id: "feather", name: "Feather Cluster", icon: "🦅", color: "#a56bff", color2: "#5a2ab0", creature: "Falcon", planets: [] },
  { id: "lost", name: "Lost Galaxy", icon: "🌀", color: "#ffd23c", color2: "#b8860b", creature: "Mystery", planets: [] },
  { id: "dejavu", name: "Déjà Vu Dimension", icon: "🔁", color: "#ff4f6a", color2: "#8a1a3a", creature: "Nebulax", planets: [] },
  { id: "speedway", name: "Stellar Speedway", icon: "⚡", color: "#5ac8ff", color2: "#1a6aa8", creature: "Speed", planets: [] },
  { id: "void", name: "Vicious Void", icon: "☠️", color: "#9a9ab8", color2: "#3a3a58", creature: "Void", planets: [] },
];
GALAXIES.forEach((g) => (g.planets = PLANETS.filter((p) => p.galaxy === g.id).map((p) => p.id)));

export const planetById = (id: string) => PLANETS.find((p) => p.id === id)!;
export const galaxyById = (id: string) => GALAXIES.find((g) => g.id === id)!;
export const MAIN_GALAXIES = ["gorilla", "tentacle", "serpent", "camo", "feather"];

export const TOTAL_BOTS = PLANETS.reduce((a, p) => a + p.bots, 0) + 0;
export const TOTAL_PUZZLE = PLANETS.reduce((a, p) => a + p.puzzle, 0);

// ───────── Bots ─────────
const FIRST = ["Bolt", "Sparky", "Widget", "Cog", "Pixel", "Zippy", "Nuts", "Ratchet", "Byte", "Tinker", "Gizmo", "Chip", "Dot", "Blip", "Volt", "Rivet", "Dash", "Beep", "Boop", "Clank", "Fizz", "Sprocket", "Pip", "Zap", "Juno", "Orbit", "Nova", "Comet", "Turbo", "Echo"];
const LAST = ["the Brave", "the Bold", "McBot", "Jr.", "the Wise", "of Mars", "the Quick", "the Kind", "the Sleepy", "Prime", "Mk II", "the Great", "the Tiny", "the Merry", "the Odd"];
export const HATS = ["none", "cap", "party", "crown", "horns", "headband", "helmet", "antenna", "chef", "wizard", "bow", "halo"];
export const BOT_COLORS = ["#ff5a5a", "#ffb03c", "#ffe24a", "#5ae068", "#3ad8d8", "#4f8bff", "#a56bff", "#ff6fc8", "#f4f6fa", "#8a96a8"];

function hash(s: string) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
export function rng(seed: number) { let s = seed >>> 0 || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
export const seedOf = hash;

export interface BotDef { id: string; name: string; color: string; hat: string; model: "robot" | "xbot"; anim: string; vip?: boolean; }
export function botDef(planetId: string, i: number): BotDef {
  const h = hash(planetId + ":" + i);
  const anims = ["Wave", "Dance", "ThumbsUp", "Yes", "Sitting", "Idle"];
  return {
    id: `${planetId}#${i}`,
    name: `${FIRST[h % FIRST.length]} ${LAST[(h >> 5) % LAST.length]}`,
    color: BOT_COLORS[(h >> 3) % BOT_COLORS.length],
    hat: HATS[(h >> 7) % HATS.length],
    model: (h >> 11) % 7 === 0 ? "xbot" : "robot",
    anim: anims[(h >> 9) % anims.length],
  };
}
export const VIP_BOTS: Record<string, { color: string; hat: string; note: string }> = {
  "Monkey Stalker": { color: "#ffb03c", hat: "headband", note: "A net-wielding monkey catcher." },
  "Spike Catcher": { color: "#4f8bff", hat: "cap", note: "Always ready with a butterfly net." },
  "Boy": { color: "#ff6fc8", hat: "cap", note: "Don't call him 'boy'." },
  "Dad of Boy": { color: "#8a96a8", hat: "horns", note: "A warrior with a grumpy soul." },
  "Raider Dude": { color: "#c98a4a", hat: "cap", note: "Always in search of lost treasure." },
  "Treasure Hunter": { color: "#ffe24a", hat: "cap", note: "X marks the spot." },
  "Energetic Blob": { color: "#ff6fc8", hat: "none", note: "Rolls and jiggles with joy." },
  "Blobby Roller": { color: "#5ae068", hat: "none", note: "Sings while bouncing." },
  "Machine Hunter": { color: "#ff8a3c", hat: "headband", note: "Hunts robotic beasts." },
  "Aloof Huntress": { color: "#ff5a5a", hat: "headband", note: "A skilled archer." },
  "Great Bot Leader": { color: "#f4f6fa", hat: "crown", note: "Leader of the Bot crew." },
  "Chop Chop Master": { color: "#ffb03c", hat: "chef", note: "Kung-fu onion master." },
};

export const OUTFITS = [
  { id: "default", name: "Astro Classic", need: 0, body: "#f4f7ff", joint: "#a9b8d6", accent: "#2f8bff" },
  { id: "gold", name: "Golden Astro", need: 3, body: "#ffd96a", joint: "#b88a1a", accent: "#fff3b0" },
  { id: "crimson", name: "Crimson Racer", need: 6, body: "#ff5a6a", joint: "#8a2030", accent: "#ffffff" },
  { id: "midnight", name: "Midnight Bot", need: 9, body: "#3a4468", joint: "#161a30", accent: "#5ae0ff" },
  { id: "mint", name: "Mint Fresh", need: 12, body: "#8ff0c8", joint: "#2a8a6a", accent: "#ffffff" },
  { id: "throwback", name: "Throwback Outfit", need: 99, body: "#d9d9d9", joint: "#7a7a7a", accent: "#4f8bff" },
];
export const SPEEDER_COLORS = [
  { id: "white", name: "Classic White", color: "#f2f5ff" },
  { id: "black", name: "Midnight Black", color: "#23262e" },
  { id: "red", name: "Cosmic Red", color: "#d83a3a" },
  { id: "blue", name: "Ocean Blue", color: "#2f7bff" },
  { id: "purple", name: "Nebula Purple", color: "#8a4fe0" },
  { id: "gold", name: "Champion Gold", color: "#e8b83a" },
];

export const GATCHA_ITEMS: { id: string; name: string; emoji: string; rarity: 1 | 2 | 3 }[] = [
  { id: "g1", name: "Retro Console", emoji: "🎮", rarity: 1 }, { id: "g2", name: "Tiny Controller", emoji: "🕹️", rarity: 1 },
  { id: "g3", name: "Memory Card", emoji: "💾", rarity: 1 }, { id: "g4", name: "Disc of Joy", emoji: "💿", rarity: 1 },
  { id: "g5", name: "Pocket Handheld", emoji: "📱", rarity: 1 }, { id: "g6", name: "Headset", emoji: "🎧", rarity: 1 },
  { id: "g7", name: "Camera Eye", emoji: "📷", rarity: 1 }, { id: "g8", name: "Mini Trophy", emoji: "🏆", rarity: 2 },
  { id: "g9", name: "Lucky Star", emoji: "⭐", rarity: 2 }, { id: "g10", name: "Tiny Rocket", emoji: "🚀", rarity: 2 },
  { id: "g11", name: "Ape Net", emoji: "🥅", rarity: 1 }, { id: "g12", name: "Rubber Duck", emoji: "🦆", rarity: 1 },
  { id: "g13", name: "Golden Banana", emoji: "🍌", rarity: 2 }, { id: "g14", name: "Space Ice Cream", emoji: "🍦", rarity: 1 },
  { id: "g15", name: "Moon Cake", emoji: "🥮", rarity: 1 }, { id: "g16", name: "Cassette", emoji: "📼", rarity: 1 },
  { id: "g17", name: "Robot Dino", emoji: "🦖", rarity: 2 }, { id: "g18", name: "Crystal Ball", emoji: "🔮", rarity: 3 },
  { id: "g19", name: "Dream Crown", emoji: "👑", rarity: 3 }, { id: "g20", name: "Comet Shard", emoji: "☄️", rarity: 2 },
  { id: "g21", name: "Pixel Heart", emoji: "💖", rarity: 2 }, { id: "g22", name: "Magic Lamp", emoji: "🪔", rarity: 2 },
  { id: "g23", name: "Dancing Toy", emoji: "🪅", rarity: 1 }, { id: "g24", name: "Rainbow", emoji: "🌈", rarity: 3 },
];

export const HUB_UNLOCKS = [
  { id: "gatcha", name: "Gatcha Lab", need: 2 },
  { id: "garage", name: "Dual Speeder Garage", need: 5 },
  { id: "safari", name: "Safari Park", need: 8 },
  { id: "master", name: "Great Master Challenge", need: 0 },
];
