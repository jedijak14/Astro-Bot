import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { THEMES, rng, seedOf, botDef, VIP_BOTS, type Planet, type Theme, type Gadget, type BotDef } from "./data";
import { Actor, makeRobot, makeXbot, makeFox, makeBird, makeCoin, makePuzzle, stdMat, textSprite, glowTexture, makePS5 } from "./assets";
import { Sky, Lighting, Particles, type Gfx } from "./world";
import { Player, type Solid, type PlayerHost } from "./player";
import { sfx } from "./audio";
import { type SaveData } from "./store";
import { Boss } from "./boss";

const V = THREE.Vector3;
export interface Enemy {
  obj: THREE.Object3D; pos: THREE.Vector3; r: number; h: number; alive: boolean; hurts: boolean;
  update(dt: number, t: number, lv: Level): void;
  spin(lv: Level): void; stomp(lv: Level): boolean;
}
interface Updatable { obj: THREE.Object3D; update(dt: number, t: number, lv: Level): void; remove?: boolean }
export interface Interactable { pos: THREE.Vector3; r: number; label: string; locked?: string | null; action: () => void }

function exitDist(w: number, d: number, dx: number, dz: number) {
  const ax = Math.abs(dx) < 1e-4 ? 1e9 : w / 2 / Math.abs(dx);
  const az = Math.abs(dz) < 1e-4 ? 1e9 : d / 2 / Math.abs(dz);
  return Math.min(ax, az);
}

// ───────── textures ─────────
const texCache = new Map<string, THREE.CanvasTexture>();
function patTex(theme: Theme, kind: "top" | "side", name: string) {
  const k = theme.top + theme.side + name + kind;
  if (texCache.has(k)) return texCache.get(k)!;
  const c = document.createElement("canvas"); c.width = c.height = 128; const x = c.getContext("2d")!;
  const base = new THREE.Color(kind === "top" ? theme.top : theme.side);
  const css = (col: THREE.Color, l = 0) => "#" + col.clone().offsetHSL(0, 0, l).getHexString();
  x.fillStyle = css(base); x.fillRect(0, 0, 128, 128);
  if (kind === "top") {
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { x.fillStyle = css(base, (i + j) % 2 ? 0.045 : -0.02); x.fillRect(i * 32, j * 32, 32, 32); }
    x.strokeStyle = css(base, -0.12); x.lineWidth = 3; x.strokeRect(1.5, 1.5, 125, 125);
    for (let i = 0; i < 30; i++) { x.fillStyle = css(base, (Math.random() - 0.5) * 0.12); x.fillRect(Math.random() * 128, Math.random() * 128, 3, 3); }
  } else {
    x.strokeStyle = css(base, -0.12); x.lineWidth = 3;
    for (let r = 0; r < 4; r++) { x.beginPath(); x.moveTo(0, r * 32); x.lineTo(128, r * 32); x.stroke(); for (let b = 0; b < 3; b++) { const ox = ((r % 2) * 21 + b * 42) % 128; x.beginPath(); x.moveTo(ox, r * 32); x.lineTo(ox, r * 32 + 32); x.stroke(); } }
    for (let i = 0; i < 20; i++) { x.fillStyle = css(base, (Math.random() - 0.5) * 0.1); x.fillRect(Math.random() * 128, Math.random() * 128, 6, 4); }
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4;
  texCache.set(k, t); return t;
}

export function makeProp(kind: string, r: () => number, th: Theme): THREE.Group {
  const g = new THREE.Group();
  const m = (geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); o.castShadow = true; g.add(o); return o; };
  const trunk = stdMat("#8a5a34", { roughness: 0.9 });
  const leaf = stdMat(new THREE.Color(th.top).offsetHSL(0, 0, -0.08).getStyle(), { roughness: 0.7 });
  const acc = stdMat(th.accent, { roughness: 0.4 });
  const alt = stdMat(th.alt, { roughness: 0.5 });
  const side = stdMat(th.side, { roughness: 0.8 });
  switch (kind) {
    case "tree": m(new THREE.CylinderGeometry(0.18, 0.26, 1.6, 8), trunk, 0, 0.8, 0); m(new THREE.IcosahedronGeometry(1.0, 1), leaf, 0, 2.2, 0); m(new THREE.IcosahedronGeometry(0.7, 1), leaf, 0.6, 1.8, 0.2); break;
    case "pine": for (let i = 0; i < 3; i++) m(new THREE.ConeGeometry(1.1 - i * 0.28, 1.3, 8), stdMat(i % 2 ? "#e8f6ff" : "#2f8f5a"), 0, 1.2 + i * 0.85, 0); m(new THREE.CylinderGeometry(0.15, 0.2, 0.8, 6), trunk, 0, 0.4, 0); break;
    case "palm": { for (let i = 0; i < 6; i++) { const s = m(new THREE.CylinderGeometry(0.14 - i * 0.008, 0.16 - i * 0.008, 0.6, 7), trunk, Math.sin(i * 0.25) * 0.3, 0.3 + i * 0.58, 0); s.rotation.z = -i * 0.05; } for (let i = 0; i < 7; i++) { const l = m(new THREE.ConeGeometry(0.22, 1.7, 4), stdMat("#38c25a"), 0.3, 3.6, 0); l.geometry.translate(0, 0.85, 0); l.rotation.set(0, (i / 7) * 6.28, 1.15); l.scale.set(1, 1, 0.3); } break; }
    case "cactus": m(new THREE.CapsuleGeometry(0.28, 1.6, 4, 8), stdMat("#3fae5a"), 0, 1.0, 0); m(new THREE.CapsuleGeometry(0.16, 0.6, 4, 8), stdMat("#3fae5a"), 0.5, 1.2, 0); m(new THREE.CapsuleGeometry(0.16, 0.5, 4, 8), stdMat("#3fae5a"), -0.45, 0.9, 0); break;
    case "rock": m(new THREE.DodecahedronGeometry(0.9 + r() * 0.5, 0), side, 0, 0.5, 0).scale.set(1, 0.7, 1); break;
    case "pillar": m(new THREE.CylinderGeometry(0.45, 0.5, 2.6 + r() * 1.5, 10), alt, 0, 1.5, 0); m(new THREE.BoxGeometry(1.2, 0.3, 1.2), alt, 0, 2.9, 0); break;
    case "crate": m(new RoundedBoxGeometry(1.3, 1.3, 1.3, 3, 0.1), acc, 0, 0.65, 0); m(new THREE.BoxGeometry(1.34, 0.12, 1.34), alt, 0, 0.65, 0); break;
    case "voxel": for (let i = 0; i < 5; i++) m(new THREE.BoxGeometry(0.8, 0.8, 0.8), stdMat([th.accent, th.alt, th.top][i % 3], { emissive: [th.accent, th.alt, th.top][i % 3], emissiveIntensity: 0.4 }), (r() - 0.5) * 1.6, 0.4 + Math.floor(i / 2) * 0.8, (r() - 0.5) * 1.6); break;
    case "balloon": { const c = ["#ff5a7a", "#ffd23c", "#4fd8ff", "#7aff7a", "#c07aff"][Math.floor(r() * 5)]; m(new THREE.SphereGeometry(0.8, 14, 12), stdMat(c, { roughness: 0.25 }), 0, 2.2, 0).scale.set(1, 1.2, 1); m(new THREE.CylinderGeometry(0.02, 0.02, 1.6, 4), stdMat("#fff"), 0, 0.8, 0); break; }
    case "coral": for (let i = 0; i < 4; i++) m(new THREE.ConeGeometry(0.2, 1.2 + r(), 6), stdMat(["#ff6fa8", "#ffb03c", "#b46aff", "#6affd0"][i]), (r() - 0.5) * 1.0, 0.7, (r() - 0.5) * 1.0); break;
    case "lantern": m(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 6), trunk, 0, 1.1, 0); m(new THREE.SphereGeometry(0.34, 12, 10), stdMat("#ffe66a", { emissive: "#ffcf3a", emissiveIntensity: 2 }), 0, 2.3, 0); break;
    case "tomb": m(new RoundedBoxGeometry(1.0, 1.5, 0.4, 3, 0.15), side, 0, 0.75, 0); m(new THREE.SphereGeometry(0.5, 10, 8, 0, 6.28, 0, 1.57), side, 0, 1.45, 0).scale.z = 0.4; break;
    case "lolli": m(new THREE.CylinderGeometry(0.06, 0.06, 1.8, 6), stdMat("#fff"), 0, 0.9, 0); m(new THREE.CylinderGeometry(0.7, 0.7, 0.18, 20), acc, 0, 2.0, 0).rotation.x = Math.PI / 2; break;
    case "asteroid": m(new THREE.IcosahedronGeometry(0.9 + r() * 0.6, 0), side, 0, 0.6, 0).scale.set(1.2, 0.8, 1); break;
    case "vent": m(new THREE.ConeGeometry(0.8, 1.3, 8), side, 0, 0.65, 0); m(new THREE.SphereGeometry(0.4, 8, 6), stdMat("#ff7a1a", { emissive: "#ff4a00", emissiveIntensity: 2 }), 0, 1.3, 0); break;
    case "speaker": m(new RoundedBoxGeometry(1.2, 2.0, 0.9, 3, 0.1), stdMat("#10102a", { roughness: 0.5 }), 0, 1.0, 0); for (const y of [0.55, 1.45]) m(new THREE.CylinderGeometry(0.34, 0.34, 0.06, 16), stdMat(th.accent, { emissive: th.accent, emissiveIntensity: 0.8 }), 0, y, 0.46).rotation.x = Math.PI / 2; break;
    case "can": m(new THREE.CylinderGeometry(0.5, 0.5, 1.2, 14), stdMat("#c9ced8", { metalness: 0.7, roughness: 0.3 }), 0, 0.6, 0).rotation.z = r() * 0.4; break;
    case "chip": for (let i = 0; i < 3; i++) m(new THREE.CylinderGeometry(0.7, 0.7, 0.18, 22), stdMat(i % 2 ? "#ffffff" : "#d62f5b"), 0, 0.1 + i * 0.2, 0); break;
    case "torii": for (const s of [-1, 1]) m(new THREE.CylinderGeometry(0.16, 0.2, 2.8, 8), stdMat("#e63a3a"), s * 1.0, 1.4, 0); m(new THREE.BoxGeometry(3.0, 0.25, 0.3), stdMat("#e63a3a"), 0, 2.7, 0); m(new THREE.BoxGeometry(2.4, 0.15, 0.2), stdMat("#e63a3a"), 0, 2.2, 0); break;
    default: m(new THREE.DodecahedronGeometry(0.8, 0), side, 0, 0.5, 0);
  }
  return g;
}

// ───────── Level ─────────
export interface LevelEvents {
  onCoin: () => void; onBot: (i: number) => void; onPuzzle: (i: number) => void; onGoal: (vip?: string) => void; onVortex: () => void; onCheckpoint: () => void; onToast: (s: string) => void; onBossHp: (hp: number, max: number) => void; onHubInteract?: (id: string) => void;
}

export class Level implements PlayerHost {
  scene = new THREE.Scene();
  sky: Sky; light: Lighting; fx: Particles;
  theme: Theme;
  solids: Solid[] = [];
  ents: Updatable[] = [];
  enemies: Enemy[] = [];
  coins: { obj: THREE.Object3D; got: boolean; vel?: THREE.Vector3; t?: number; big?: boolean }[] = [];
  botsE: { obj: THREE.Object3D; actor: Actor; idx: number; state: "wait" | "saved" | "hidden"; t: number; def: BotDef; bubble: THREE.Sprite; pos: THREE.Vector3; vip?: string }[] = [];
  puzzlesE: { obj: THREE.Object3D; idx: number; got: boolean }[] = [];
  springs: { pos: THREE.Vector3; power: number; obj: THREE.Object3D; t: number }[] = [];
  checkpoints: { pos: THREE.Vector3; obj: THREE.Object3D; on: boolean; light: THREE.Mesh }[] = [];
  crates: { solid: Solid; obj: THREE.Object3D; broken: boolean; coins: number; bot?: number }[] = [];
  pickups: { obj: THREE.Object3D; gadget: Gadget; got: boolean; pos: THREE.Vector3 }[] = [];
  interact: Interactable[] = [];
  vortexPos: THREE.Vector3 | null = null;
  vortexObj: THREE.Object3D | null = null;
  goalPos = new V();
  goalObj: THREE.Object3D | null = null;
  spawn = new V(0, 0.01, 0);
  spawnYaw = 0;
  path: { p: THREE.Vector3; yaw: number }[] = [];
  minY = -30;
  slippery = false;
  runCoins = 0;
  cpPos = new V(); cpCoins = 0;
  time = 0;
  finished = false;
  player!: Player;
  boss: Boss | null = null;
  ev!: LevelEvents;
  r: () => number;
  saved: SaveData | null;
  botFound: boolean[] = [];
  puzzleFound: boolean[] = [];
  gadgetOwned: Gadget = "none";
  isHub = false;
  vip?: string;
  arenaHalf = 15;
  shake = 0;
  shock: { pos: THREE.Vector3; r: number; t: number; obj: THREE.Mesh }[] = [];

  constructor(public gfx: Gfx, public planet: Planet | null, save: SaveData | null, themeKey?: string) {
    this.saved = save;
    this.theme = THEMES[themeKey ?? planet?.theme ?? "meadow"];
    const seed = seedOf(planet?.id ?? "hub");
    this.r = rng(seed);
    this.sky = new Sky(this.scene, this.theme, seed);
    this.light = new Lighting(this.scene, this.theme, gfx.env);
    this.fx = new Particles(this.scene);
    if (planet) {
      this.botFound = Array.from({ length: planet.bots }, (_, i) => !!save?.bots[planet.id]?.includes(i));
      this.puzzleFound = Array.from({ length: planet.puzzle }, (_, i) => !!save?.puzzles[planet.id]?.includes(i));
      if (planet.kind === "boss") this.buildBossArena(); else this.generate();
    }
    this.cpPos.copy(this.spawn);
  }

  // ───── PlayerHost ─────
  burst(p: THREE.Vector3, color: string, n = 10, speed = 3, life = 0.6, size = 0.25, grav = 6, up = 0.5) { this.fx.emit(p, color, n, speed, life, size, grav, up); }
  getCoins() { return this.runCoins; }
  // host interface wrappers
  onSlam(p: THREE.Vector3, r: number) {
    for (const e of this.enemies) if (e.alive && Math.hypot(e.pos.x - p.x, e.pos.z - p.z) < r + e.r && Math.abs(e.pos.y - p.y) < 2) e.spin(this);
    for (const c of this.crates) if (!c.broken && Math.hypot(c.solid.obj.position.x - p.x, c.solid.obj.position.z - p.z) < r + 0.8) this.breakCrate(c);
    this.boss?.onSlam(this, p, r);
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.3, 0.5, 32), new THREE.MeshBasicMaterial({ color: "#ffe9a0", transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2; ring.position.set(p.x, p.y + 0.06, p.z); this.scene.add(ring);
    this.shock.push({ pos: p, r: 0.3, t: 0, obj: ring });
  }
  onDie() { /* handled by engine through update */ }
  onHurt(n: number) {
    const lost = Math.min(this.runCoins, n);
    this.runCoins -= lost;
    for (let i = 0; i < Math.min(lost, 12); i++) this.spawnLoose(this.player.center);
    this.ev.onCoin();
  }

  attachPlayer(p: Player) {
    this.player = p;
    p.host = this as PlayerHost;
    this.scene.add(p.group); this.scene.add(p.blob);
  }

  spawnLoose(from: THREE.Vector3) {
    const o = makeCoin(); o.position.copy(from); this.scene.add(o);
    this.coins.push({ obj: o, got: false, vel: new V((Math.random() - 0.5) * 7, 5 + Math.random() * 3, (Math.random() - 0.5) * 7), t: 0 });
  }

  // ───── building blocks ─────
  addPlatform(cx: number, topY: number, cz: number, w: number, d: number, o: { thick?: number; kind?: Solid["kind"]; color?: string; sideColor?: string; round?: number } = {}): Solid {
    const thick = o.thick ?? 1.4;
    const g = new THREE.Group();
    const th = this.theme;
    const sideMat = new THREE.MeshStandardMaterial({ map: patTex(th, "side", "s"), color: o.sideColor ?? "#ffffff", roughness: 0.78, metalness: 0.02 });
    const topTex = patTex(th, "top", "t").clone(); topTex.repeat.set(Math.max(1, w / 2.5), Math.max(1, d / 2.5)); topTex.needsUpdate = true;
    const isIce = o.kind === "ice";
    const topMat = new THREE.MeshStandardMaterial({ map: topTex, color: o.color ?? (isIce ? "#bfeaff" : "#ffffff"), roughness: isIce ? 0.08 : 0.55, metalness: isIce ? 0.2 : 0.02, emissive: th.stars ? new THREE.Color(th.top).multiplyScalar(0.08) : new THREE.Color(0) });
    const rad = o.round ?? Math.min(0.2, thick * 0.15, w * 0.15, d * 0.15);
    const body = new THREE.Mesh(new RoundedBoxGeometry(w, thick, d, 3, rad), sideMat);
    body.position.y = -thick / 2; body.castShadow = true; body.receiveShadow = true; g.add(body);
    const top = new THREE.Mesh(new RoundedBoxGeometry(w + 0.04, 0.36, d + 0.04, 3, 0.12), topMat);
    top.position.y = -0.18 + 0.001; top.receiveShadow = true; top.castShadow = true; g.add(top);
    g.position.set(cx, topY, cz);
    this.scene.add(g);
    const s: Solid = { obj: g, min: new V(cx - w / 2, topY - thick, cz - d / 2), max: new V(cx + w / 2, topY, cz + d / 2), vel: new V(), kind: o.kind ?? "static", active: true };
    this.solids.push(s);
    if (isIce) this.slippery = false;
    return s;
  }
  private syncSolid(s: Solid, w: number, thick: number, d: number) {
    const p = s.obj.position;
    s.min.set(p.x - w / 2, p.y - thick, p.z - d / 2); s.max.set(p.x + w / 2, p.y, p.z + d / 2);
  }
  addMover(cx: number, topY: number, cz: number, w: number, d: number, axis: THREE.Vector3, amp: number, speed: number, phase = 0) {
    const s = this.addPlatform(cx, topY, cz, w, d, { thick: 1.0, kind: "mover", color: "#ffffff", sideColor: this.theme.alt });
    const base = new V(cx, topY, cz);
    const prev = new V(cx, topY, cz);
    s.update = (t, dt) => {
      const off = Math.sin(t * speed + phase) * amp;
      s.obj.position.copy(base).addScaledVector(axis, off);
      this.syncSolid(s, w, 1.0, d);
      s.vel.copy(s.obj.position).sub(prev).divideScalar(Math.max(dt, 1e-4)); prev.copy(s.obj.position);
    };
    // little light strip
    const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.04, 0.12), stdMat(this.theme.accent, { emissive: this.theme.accent, emissiveIntensity: 1.5 }));
    strip.position.set(0, 0.01, d / 2 - 0.15); s.obj.add(strip);
    return s;
  }
  addCrumble(cx: number, topY: number, cz: number, w: number, d: number) {
    const s = this.addPlatform(cx, topY, cz, w, d, { thick: 0.7, kind: "crumble", color: "#ffd9b0", sideColor: "#c98a5a" });
    const base = new V(cx, topY, cz);
    let state: "idle" | "shake" | "fall" | "gone" = "idle"; let tt = 0;
    s.touched = () => { if (state === "idle") { state = "shake"; tt = 0; sfx("land"); } };
    s.update = (_t, dt) => {
      tt += dt;
      if (state === "shake") { s.obj.position.x = base.x + Math.sin(tt * 60) * 0.05; if (tt > 0.55) { state = "fall"; tt = 0; s.active = false; } }
      else if (state === "fall") { s.obj.position.y -= dt * (6 + tt * 20); s.obj.position.x = base.x; if (tt > 1.2) { state = "gone"; tt = 0; s.obj.visible = false; } }
      else if (state === "gone") { if (tt > 2.6) { state = "idle"; tt = 0; s.obj.position.copy(base); s.obj.visible = true; s.active = true; this.syncSolid(s, w, 0.7, d); } }
      if (state === "idle" || state === "shake") { this.syncSolid(s, w, 0.7, d); }
    };
    return s;
  }
  addSpring(x: number, y: number, z: number, power = 19) {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.7, 0.16, 18), stdMat("#3a3f55", { metalness: 0.4 }));
    base.position.y = 0.08; g.add(base);
    const coil = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.07, 8, 16), stdMat("#c9d0e0", { metalness: 0.8, roughness: 0.25 })); coil.rotation.x = Math.PI / 2; coil.position.y = 0.3; g.add(coil);
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.66, 0.14, 20), stdMat("#ff5a7a", { roughness: 0.3, emissive: "#ff2a5a", emissiveIntensity: 0.3 })); pad.position.y = 0.52; g.add(pad); pad.castShadow = true;
    g.position.set(x, y, z); this.scene.add(g);
    this.springs.push({ pos: new V(x, y + 0.5, z), power, obj: g, t: 0 });
  }
  addCoin(p: THREE.Vector3) { const o = makeCoin(); o.position.copy(p); this.scene.add(o); this.coins.push({ obj: o, got: false }); }
  coinLine(a: THREE.Vector3, b: THREE.Vector3, n: number, arch = 1.2) {
    for (let i = 1; i <= n; i++) { const t = i / (n + 1); const p = a.clone().lerp(b, t); p.y += Math.sin(t * Math.PI) * arch + 0.7; this.addCoin(p); }
  }
  addCrate(x: number, y: number, z: number, coins = 5, bot?: number) {
    const g = new THREE.Group();
    const m = new THREE.Mesh(new RoundedBoxGeometry(1.1, 1.1, 1.1, 3, 0.1), stdMat(bot !== undefined ? "#7a5af0" : "#e8a24a", { roughness: 0.6 }, "crate" + (bot !== undefined)));
    m.position.y = 0.55; m.castShadow = true; g.add(m);
    const band = new THREE.Mesh(new THREE.BoxGeometry(1.14, 0.14, 1.14), stdMat(this.theme.alt, { roughness: 0.5 })); band.position.y = 0.55; g.add(band);
    const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.16), stdMat("#fff", { emissive: "#fff", emissiveIntensity: 0.5 })); star.position.set(0, 0.55, 0.57); g.add(star);
    g.position.set(x, y, z); this.scene.add(g);
    const solid: Solid = { obj: g, min: new V(x - 0.55, y, z - 0.55), max: new V(x + 0.55, y + 1.1, z + 0.55), vel: new V(), kind: "static", active: true };
    this.solids.push(solid); this.crates.push({ solid, obj: g, broken: false, coins, bot });
  }
  breakCrate(c: { solid: Solid; obj: THREE.Object3D; broken: boolean; coins: number; bot?: number }) {
    if (c.broken) return; c.broken = true; c.solid.active = false; c.obj.visible = false; sfx("smash");
    const p = c.obj.position.clone(); p.y += 0.5;
    this.burst(p, "#e8a24a", 14, 5, 0.7, 0.3, 14); this.burst(p, "#ffffff", 6, 3, 0.5, 0.2, 6);
    for (let i = 0; i < c.coins; i++) this.spawnLoose(p);
    if (c.bot !== undefined) { const b = this.botsE.find((x) => x.idx === c.bot); if (b && b.state === "hidden") { b.state = "wait"; b.obj.visible = true; b.actor.root.position.y = 0; b.t = 0; } }
  }
  addBot(idx: number, pos: THREE.Vector3, hidden = false) {
    const def = idx < 0 ? null : botDef(this.planet!.id, idx);
    const d = def ?? { id: "vip", name: this.vip ?? "VIP", color: "#f4f6fa", hat: "crown", model: "robot" as const, anim: "Wave" };
    const vipInfo = this.vip ? VIP_BOTS[this.vip] : undefined;
    const actor = idx < 0 && vipInfo ? makeRobot({ body: vipInfo.color, hat: vipInfo.hat, hatColor: "#ffd23c", height: 1.0 }) : d.model === "xbot" ? makeXbot(d.color, 1.0) : makeRobot({ body: d.color, joint: "#a9b8d6", accent: "#2f8bff", hat: d.hat, hatColor: d.color === "#f4f6fa" ? "#ff5a5a" : "#ffffff", height: 0.95 });
    const g = new THREE.Group(); g.add(actor.root); g.position.copy(pos);
    actor.play(d.model === "xbot" ? "agree" : "Wave");
    const bubble = textSprite("HELP!", "#fff", "#ff3b5c", 1); bubble.position.set(0, 1.95, 0); g.add(bubble);
    this.scene.add(g);
    if (hidden) g.visible = false;
    this.botsE.push({ obj: g, actor, idx, state: hidden ? "hidden" : "wait", t: Math.random() * 6, def: d, bubble, pos: pos.clone(), vip: idx < 0 ? this.vip : undefined });
  }
  addPuzzle(idx: number, pos: THREE.Vector3) {
    const g = new THREE.Group(); const p = makePuzzle(["#43b0ff", "#ff6fa8", "#7aff7a", "#ffd23c"][idx % 4], 0.62); g.add(p);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture("#9ad8ff"), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.8 })); glow.scale.setScalar(2.6); g.add(glow);
    g.position.copy(pos); this.scene.add(g); this.puzzlesE.push({ obj: g, idx, got: false });
  }
  addCheckpoint(x: number, y: number, z: number) {
    const g = new THREE.Group();
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 2.2, 8), stdMat("#dfe6f5", { metalness: 0.6, roughness: 0.3 })); pole.position.y = 1.1; pole.castShadow = true; g.add(pole);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 0.2, 16), stdMat("#2a2f45")); base.position.y = 0.1; g.add(base);
    const light = new THREE.Mesh(new THREE.OctahedronGeometry(0.34), new THREE.MeshStandardMaterial({ color: "#ff5a5a", emissive: "#ff3a3a", emissiveIntensity: 1.6 })); light.position.y = 2.5; g.add(light);
    g.position.set(x, y, z); this.scene.add(g);
    this.checkpoints.push({ pos: new V(x, y + 0.05, z), obj: g, on: false, light });
  }
  addGoal(x: number, y: number, z: number) {
    const g = new THREE.Group();
    const white = stdMat("#f5f7fc", { roughness: 0.3 }); const glow = stdMat("#4aa8ff", { emissive: "#4aa8ff", emissiveIntensity: 2 }, "goalglow");
    for (const s of [-1, 1]) { const p = new THREE.Mesh(new RoundedBoxGeometry(0.7, 4.2, 0.7, 3, 0.2), white); p.position.set(s * 2.2, 2.1, 0); p.castShadow = true; g.add(p); const l = new THREE.Mesh(new THREE.SphereGeometry(0.28), glow); l.position.set(s * 2.2, 4.4, 0); g.add(l); }
    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.16, 12, 40, Math.PI), glow); ring.position.y = 4.1; g.add(ring);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.9), new THREE.MeshStandardMaterial({ color: "#ffffff", emissive: "#3a8aff", emissiveIntensity: 0.6, side: THREE.DoubleSide })); flag.position.set(0, 3.3, 0); g.add(flag);
    const star = new THREE.Mesh(new THREE.TorusKnotGeometry(0.25, 0.07, 48, 8), stdMat("#ffd23c", { emissive: "#ffb000", emissiveIntensity: 1.2 })); star.position.y = 3.3; star.name = "gstar"; g.add(star); g.remove(flag);
    g.position.set(x, y, z); this.scene.add(g); this.goalObj = g; this.goalPos.set(x, y, z);
  }
  addPickup(gadget: Gadget, pos: THREE.Vector3) {
    const g = new THREE.Group();
    const col = { frog: "#4ad65a", rocket: "#ff5a3c", monkey: "#a8703a", gloves: "#ff3a4a", none: "#fff" }[gadget];
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.7, 20, 14), new THREE.MeshStandardMaterial({ color: col, transparent: true, opacity: 0.55, roughness: 0.05, metalness: 0.2, emissive: col, emissiveIntensity: 0.4 })); g.add(cap);
    const label = textSprite({ frog: "FROG", rocket: "ROCKET", monkey: "MONKEY", gloves: "GLOVES", none: "" }[gadget], "#fff", col, 0.9); label.position.y = 1.5; g.add(label);
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.3, 0), stdMat(col, { emissive: col, emissiveIntensity: 1.2 })); g.add(core);
    g.position.copy(pos).add(new V(0, 1.1, 0)); this.scene.add(g); this.pickups.push({ obj: g, gadget, got: false, pos: g.position.clone() });
  }
  private addDecor(count: number, around: { p: THREE.Vector3; yaw: number }[]) {
    const r = this.r;
    for (let i = 0; i < count; i++) {
      const base = around[Math.floor(r() * around.length)];
      const a = r() * Math.PI * 2, dist = 14 + r() * 42;
      const x = base.p.x + Math.cos(a) * dist, z = base.p.z + Math.sin(a) * dist, y = base.p.y - 6 - r() * 24;
      const rad = 3 + r() * 6;
      const g = new THREE.Group();
      const topM = new THREE.Mesh(new THREE.CylinderGeometry(rad, rad * 0.95, 0.9, 16), stdMat(this.theme.top, { roughness: 0.7 }));
      const rock = new THREE.Mesh(new THREE.ConeGeometry(rad * 0.95, rad * 1.8, 10), stdMat(this.theme.side, { roughness: 0.9 }, "rock" + this.theme.side)); rock.rotation.x = Math.PI; rock.position.y = -rad * 0.9 - 0.4;
      topM.castShadow = true; topM.receiveShadow = true; rock.castShadow = true;
      g.add(topM, rock);
      const n = Math.floor(r() * 3);
      for (let k = 0; k < n; k++) { const pr = makeProp(this.theme.prop, r, this.theme); pr.position.set((r() - 0.5) * rad, 0.45, (r() - 0.5) * rad); pr.scale.setScalar(0.9 + r() * 1.3); pr.rotation.y = r() * 6; g.add(pr); }
      g.position.set(x, y, z); this.scene.add(g);
      const ph = r() * 6, sp = 0.2 + r() * 0.3; const by = y;
      this.ents.push({ obj: g, update: (_dt, t) => { g.position.y = by + Math.sin(t * sp + ph) * 0.5; } });
    }
  }

  // ───── enemies ─────
  addGrunt(x: number, y: number, z: number, bounds: { minx: number; maxx: number; minz: number; maxz: number }) {
    const g = new THREE.Group();
    const col = new THREE.Color(this.theme.accent).offsetHSL(0.5, 0, -0.1).getStyle();
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.5, 16, 12), stdMat(col, { roughness: 0.35 })); body.position.y = 0.55; body.scale.set(1, 0.95, 1); body.castShadow = true; g.add(body);
    const eyeM = stdMat("#fff"); const pupil = stdMat("#111");
    for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 8), eyeM); e.position.set(s * 0.2, 0.7, 0.4); g.add(e); const p = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), pupil); p.position.set(s * 0.2, 0.7, 0.53); g.add(p); const f = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6), stdMat("#2a2a40")); f.position.set(s * 0.25, 0.1, 0.05); f.scale.set(1, 0.6, 1.4); f.name = "foot" + s; g.add(f); }
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.3, 6), stdMat("#fff3c0")); horn.position.set(0, 1.1, 0.1); g.add(horn);
    g.position.set(x, y, z); this.scene.add(g);
    let dir = Math.random() * 6.28; let state: "walk" | "dead" = "walk"; let dt0 = 0; let flip = 0;
    const e: Enemy = {
      obj: g, pos: g.position, r: 0.6, h: 1.0, alive: true, hurts: true,
      update: (dt, t, lv) => {
        if (state === "dead") { dt0 += dt; g.scale.y = Math.max(0.02, 1 - dt0 * 6); g.scale.x = g.scale.z = 1 + dt0 * 2; if (dt0 > 0.5) { g.visible = false; } return; }
        const p = lv.player; const dx = p.pos.x - g.position.x, dz = p.pos.z - g.position.z; const dist = Math.hypot(dx, dz);
        let sp = 1.8;
        if (dist < 7 && Math.abs(p.pos.y - g.position.y) < 2.5) { dir = Math.atan2(dx, dz); sp = 3.4; } else { flip -= dt; if (flip < 0) { dir += (Math.random() - 0.5) * 2.4; flip = 1 + Math.random() * 2; } }
        let nx = g.position.x + Math.sin(dir) * sp * dt, nz = g.position.z + Math.cos(dir) * sp * dt;
        if (nx < bounds.minx || nx > bounds.maxx) { dir = -dir; nx = THREE.MathUtils.clamp(nx, bounds.minx, bounds.maxx); }
        if (nz < bounds.minz || nz > bounds.maxz) { dir = Math.PI - dir; nz = THREE.MathUtils.clamp(nz, bounds.minz, bounds.maxz); }
        g.position.x = nx; g.position.z = nz; g.rotation.y = dir;
        g.position.y = y + Math.abs(Math.sin(t * (sp * 4))) * 0.12;
        body.scale.y = 0.95 + Math.sin(t * 8) * 0.04;
      },
      spin: (lv) => { if (state === "dead") return; state = "dead"; e.alive = false; sfx("stomp"); lv.burst(g.position.clone().add(new V(0, 0.6, 0)), "#ffffff", 10, 4, 0.6, 0.3, 8); for (let i = 0; i < 3; i++) lv.spawnLoose(g.position.clone().add(new V(0, 0.6, 0))); },
      stomp: (lv) => { e.spin(lv); return true; },
    };
    this.enemies.push(e); this.ents.push(e);
  }
  addFox(x: number, y: number, z: number, bounds: { minx: number; maxx: number; minz: number; maxz: number }) {
    const a = makeFox(0.75);
    const g = new THREE.Group(); g.add(a.root); g.position.set(x, y, z); this.scene.add(g);
    a.play("Walk");
    let dir = 0; let dead = 0; let state: "walk" | "run" | "dead" = "walk";
    const e: Enemy = {
      obj: g, pos: g.position, r: 0.6, h: 0.8, alive: true, hurts: true,
      update: (dt, _t, lv) => {
        a.update(dt);
        if (state === "dead") { dead += dt; g.rotation.z += dt * 10; g.position.y += dt * (3 - dead * 10); g.scale.multiplyScalar(0.96); if (dead > 0.8) g.visible = false; return; }
        const p = lv.player; const dx = p.pos.x - g.position.x, dz = p.pos.z - g.position.z; const dist = Math.hypot(dx, dz);
        const near = dist < 9 && Math.abs(p.pos.y - g.position.y) < 2.5;
        if (near) { dir = Math.atan2(dx, dz); state = "run"; a.play("Run", { speed: 1.2 }); } else { state = "walk"; a.play("Walk"); dir += dt * 0.4; }
        const sp = near ? 5.2 : 1.3;
        let nx = g.position.x + Math.sin(dir) * sp * dt, nz = g.position.z + Math.cos(dir) * sp * dt;
        if (nx < bounds.minx || nx > bounds.maxx) { dir = -dir; nx = THREE.MathUtils.clamp(nx, bounds.minx, bounds.maxx); }
        if (nz < bounds.minz || nz > bounds.maxz) { dir = Math.PI - dir; nz = THREE.MathUtils.clamp(nz, bounds.minz, bounds.maxz); }
        g.position.x = nx; g.position.z = nz; g.rotation.y = dir;
      },
      spin: (lv) => { if (state === "dead") return; state = "dead"; e.alive = false; sfx("stomp"); lv.burst(g.position.clone().add(new V(0, 0.5, 0)), "#ff9a3c", 12, 4, 0.6, 0.3, 8); for (let i = 0; i < 4; i++) lv.spawnLoose(g.position.clone().add(new V(0, 0.5, 0))); },
      stomp: (lv) => { e.spin(lv); return true; },
    };
    this.enemies.push(e); this.ents.push(e);
  }
  addFlyer(x: number, y: number, z: number) {
    const kind = (["parrot", "flamingo", "stork"] as const)[Math.floor(this.r() * 3)];
    const a = makeBird(kind, 1.1); const act = Object.values(a.actions)[0]; act.play(); act.timeScale = 1.3;
    const g = new THREE.Group(); g.add(a.root); g.position.set(x, y, z); this.scene.add(g);
    const ph = this.r() * 6; const rad = 2 + this.r() * 2; let dead = 0; let alive = true;
    const e: Enemy = {
      obj: g, pos: g.position, r: 0.7, h: 0.8, alive: true, hurts: true,
      update: (dt, t, lv) => {
        a.update(dt);
        if (!alive) { dead += dt; g.position.y -= dt * (4 + dead * 12); g.rotation.z += dt * 8; if (dead > 1) g.visible = false; return; }
        const ang = t * 0.9 + ph; const tx = x + Math.cos(ang) * rad, tz = z + Math.sin(ang) * rad;
        const dd = Math.hypot(lv.player.pos.x - x, lv.player.pos.z - z);
        const tgtY = y + Math.sin(t * 2 + ph) * 0.4 + (dd < 6 ? -0.4 : 0);
        g.position.x += (tx - g.position.x) * Math.min(1, dt * 3); g.position.z += (tz - g.position.z) * Math.min(1, dt * 3); g.position.y += (tgtY - g.position.y) * Math.min(1, dt * 3);
        g.rotation.y = Math.atan2(-Math.sin(ang), Math.cos(ang)) + (kind === "flamingo" ? 0 : 0);
      },
      spin: (lv) => { if (!alive) return; alive = false; e.alive = false; sfx("stomp"); lv.burst(g.position.clone(), "#ffffff", 12, 4, 0.6, 0.3, 8); for (let i = 0; i < 3; i++) lv.spawnLoose(g.position.clone()); },
      stomp: (lv) => { e.spin(lv); return true; },
    };
    this.enemies.push(e); this.ents.push(e);
  }
  addCannon(x: number, y: number, z: number, interval = 2.6) {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.7, 0.5, 14), stdMat("#3a3f55", { metalness: 0.5, roughness: 0.4 })); base.position.y = 0.25; g.add(base);
    const barrel = new THREE.Group(); const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.36, 1.2, 14), stdMat("#4a5068", { metalness: 0.7, roughness: 0.3 })); tube.rotation.x = Math.PI / 2; tube.position.z = 0.5; tube.castShadow = true; barrel.add(tube); barrel.position.y = 0.75; g.add(barrel);
    g.position.set(x, y, z); this.scene.add(g);
    let cd = interval * (0.5 + this.r() * 0.7);
    this.ents.push({ obj: g, update: (dt, _t, lv) => {
      const p = lv.player; const dx = p.pos.x - x, dz = p.pos.z - z; const d = Math.hypot(dx, dz);
      barrel.rotation.y = Math.atan2(dx, dz);
      if (d < 24 && d > 2) { cd -= dt; if (cd <= 0) { cd = interval; lv.fireBall(new V(x, y + 0.8, z), new V(dx / d, 0.08, dz / d), 8.5); sfx("shoot"); lv.burst(new V(x + dx / d, y + 0.8, z + dz / d), "#ffb02a", 6, 2, 0.4, 0.3, 0); } }
    } });
  }
  fireBall(from: THREE.Vector3, dir: THREE.Vector3, speed: number, color = "#ff6a2a", gravity = 0) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.34, 12, 10), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 1.6, roughness: 0.3 }));
    m.position.copy(from); this.scene.add(m);
    const vel = dir.clone().normalize().multiplyScalar(speed); let life = 5;
    const u: Updatable = { obj: m, update: (dt, _t, lv) => {
      life -= dt; vel.y -= gravity * dt; m.position.addScaledVector(vel, dt);
      if (Math.random() < 0.5) lv.burst(m.position, color, 1, 0.5, 0.35, 0.28, 0, 0);
      const p = lv.player;
      if (p.spinT > 0 && m.position.distanceTo(p.center) < 1.8) { life = 0; sfx("stomp"); lv.burst(m.position, "#ffffff", 8, 4, 0.4, 0.3); lv.spawnLoose(m.position); }
      else if (m.position.distanceTo(p.center) < 0.7) { p.hurt(m.position); life = 0; lv.burst(m.position, color, 10, 4, 0.5); }
      if (life <= 0) { m.visible = false; u.remove = true; m.removeFromParent(); }
    } };
    this.ents.push(u);
  }
  addBoulder(x: number, y: number, z: number, axis: "x" | "z", len: number, speed = 4.2) {
    const R0 = 0.85;
    const m = new THREE.Mesh(new THREE.IcosahedronGeometry(R0, 1), stdMat("#9a8a7a", { roughness: 0.9 }, "boulder")); m.castShadow = true;
    const stripe = new THREE.Mesh(new THREE.TorusGeometry(R0 * 0.98, 0.07, 6, 20), stdMat(this.theme.accent, { emissive: this.theme.accent, emissiveIntensity: 0.4 })); m.add(stripe);
    const g = new THREE.Group(); g.add(m); this.scene.add(g);
    let s = -len / 2; const dirSign = Math.random() < 0.5 ? 1 : -1; let wait = Math.random() * 2;
    const e: Enemy = { obj: g, pos: g.position, r: R0, h: R0 * 2, alive: true, hurts: true, update: (dt) => {
      if (wait > 0) { wait -= dt; g.visible = false; return; }
      g.visible = true; s += speed * dt; if (s > len / 2) { s = -len / 2; wait = 0.8; }
      const pos = s * dirSign; g.position.set(axis === "x" ? x + pos : x, y + R0, axis === "z" ? z + pos : z); m.rotation.x -= dt * speed / R0 * (axis === "z" ? dirSign : 0); m.rotation.z += dt * speed / R0 * (axis === "x" ? dirSign : 0);
    }, spin: () => { /* immune */ }, stomp: () => false };
    this.enemies.push(e); this.ents.push(e);
  }
  addRotBar(x: number, y: number, z: number, arm: number, speed: number) {
    const g = new THREE.Group();
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 0.9, 12), stdMat("#2a2f45", { metalness: 0.5 })); post.position.y = 0.45; post.castShadow = true; g.add(post);
    const bar = new THREE.Group();
    const b = new THREE.Mesh(new RoundedBoxGeometry(arm * 2, 0.34, 0.34, 3, 0.1), stdMat(this.theme.accent, { roughness: 0.3, emissive: this.theme.accent, emissiveIntensity: 0.25 })); b.castShadow = true; bar.add(b);
    for (const s of [-1, 1]) { const t = new THREE.Mesh(new THREE.SphereGeometry(0.38, 12, 10), stdMat("#fff", { emissive: "#ff3a4a", emissiveIntensity: 0.6 })); t.position.x = s * arm; bar.add(t); }
    bar.position.y = 0.55; g.add(bar); g.position.set(x, y, z); this.scene.add(g);
    let ang = Math.random() * 6; const dirS = Math.random() < 0.5 ? 1 : -1;
    this.ents.push({ obj: g, update: (dt, _t, lv) => {
      ang += dt * speed * dirS; bar.rotation.y = ang;
      const p = lv.player; const c = p.center; const dx = c.x - x, dz = c.z - z;
      const ca = Math.cos(ang), sa = Math.sin(ang); // bar direction in xz: (ca, -sa)
      const along = dx * ca - dz * sa, perp = dx * sa + dz * ca;
      if (Math.abs(along) < arm + 0.3 && Math.abs(perp) < 0.55 && p.pos.y < y + 0.95 && p.pos.y + 0.95 > y + 0.3) p.hurt(new V(x + (dx - 0), y, z + 0));
    } });
  }

  // ───── generator ─────
  private generate() {
    const pl = this.planet!; const r = this.r; const mix = pl.mix; const diff = pl.diff; const th = this.theme;
    const kinds: { k: string; w: number }[] = [
      { k: "static", w: 3.2 }, { k: "small", w: 1 + diff * 0.35 }, { k: "mover", w: (mix.mover ?? 0) * 1.4 }, { k: "crumble", w: (mix.crumble ?? 0) * 1.5 },
      { k: "spring", w: (mix.spring ?? 0) * 1.2 }, { k: "beam", w: (mix.beam ?? 0) * 1.2 }, { k: "rotbar", w: (mix.rotbar ?? 0) * 1.1 }, { k: "ice", w: (mix.ice ?? 0) * 1.6 }, { k: "tower", w: (mix.tower ?? 0) * 1.0 }, { k: "climb", w: (mix.climb ?? 0) * 0.9 },
    ];
    const total = kinds.reduce((a, b) => a + b.w, 0);
    const pick = () => { let x = r() * total; for (const k of kinds) { x -= k.w; if (x <= 0) return k.k; } return "static"; };
    const allCrumble = (mix.crumble ?? 0) >= 2.5; const allSpring = (mix.spring ?? 0) >= 3.5;

    // start platform
    this.addPlatform(0, 0, 0, 8, 8, { thick: 2 });
    let cur = { x: 0, y: 0, z: 0, w: 8, d: 8 };
    this.spawn.set(0, 0.02, -1.5); this.spawnYaw = 0;
    this.path.push({ p: new V(0, 0, 0), yaw: Math.PI });
    let heading = 0; let turnSign = r() < 0.5 ? -1 : 1; let sinceFlip = 0;
    const bigPlats: { x: number; y: number; z: number; w: number; d: number; heading: number }[] = [{ x: 0, y: 0, z: 0, w: 8, d: 8, heading: 0 }];
    const nCP = pl.kind === "void" ? 0 : 2; let cpDone = 0;
    // reserve bot slots
    const slots: number[] = []; const nb = pl.bots;
    for (let i = 0; i < nb; i++) slots.push(1 + Math.floor(((i + 0.5) / nb) * (pl.len - 2)));
    const botAt = new Map<number, number>(); slots.forEach((s, i) => { let k = s; while (botAt.has(k)) k++; botAt.set(k, i); });
    const puzzleIdx = new Map<number, number>(); for (let i = 0; i < pl.puzzle; i++) puzzleIdx.set(Math.floor(pl.len * (0.35 + (i * 0.4) / Math.max(1, pl.puzzle))), i);
    const vortexAt = pl.vortex ? Math.floor(pl.len * 0.55) : -1;
    const gadgetAt = pl.gadget && pl.gadget !== "none" ? 2 : -1;

    const place = (w: number, d: number, gap: number, dy: number) => {
      const hd = heading;
      const dx = Math.sin(hd), dz = Math.cos(hd);
      const dist = exitDist(cur.w, cur.d, dx, dz) + gap + exitDist(w, d, dx, dz);
      return { x: cur.x + dx * dist, y: cur.y + dy, z: cur.z + dz * dist };
    };
    const advance = () => {
      sinceFlip++; if (sinceFlip > 3 + Math.floor(r() * 3)) { turnSign = -turnSign; sinceFlip = 0; }
      heading += turnSign * (0.18 + r() * 0.34);
    };
    let i = 0;
    while (i < pl.len) {
      advance();
      let type = i === pl.len - 1 ? "goal" : i === Math.floor(((cpDone + 1) * pl.len) / (nCP + 1)) && cpDone < nCP ? "arena" : pick();
      if (i === 0) type = "static";
      if (allCrumble && type !== "arena" && type !== "goal") type = "crumble"; if (allSpring && type !== "arena" && type !== "goal") type = "spring";
      const gapBase = 1.0 + r() * (1.0 + diff * 0.45);
      const prevCur = { ...cur };
      const startVec = new V(cur.x, cur.y, cur.z);
      let platformMade = false; let big = false; let w = 4, d = 4;
      const dyRand = () => THREE.MathUtils.clamp((r() - 0.35) * 1.6, -1.6, 1.1);
      switch (type) {
        case "static": case "ice": case "small": {
          w = type === "small" ? 2.4 + r() * 1.2 : 4 + r() * 3.2; d = type === "small" ? 2.4 + r() * 1.2 : 4 + r() * 3.2;
          const p = place(w, d, gapBase, dyRand());
          const s = this.addPlatform(p.x, p.y, p.z, w, d, { kind: type === "ice" ? "ice" : "static" });
          if (type === "ice") this.slippery = false;
          cur = { ...p, w, d }; big = type !== "small"; platformMade = true; void s; break;
        }
        case "crumble": {
          const n = 2 + Math.floor(r() * 2);
          for (let k = 0; k < n; k++) { w = d = 2.6 + r() * 0.8; const p = place(w, d, 1.0 + r() * 0.8, k === 0 ? 0.2 : (r() - 0.4) * 0.8); this.addCrumble(p.x, p.y, p.z, w, d); cur = { ...p, w, d }; if (k < n - 1) { advance(); heading *= 0.8; } }
          platformMade = true; break;
        }
        case "mover": {
          w = d = 3.0; const vertical = r() < 0.35;
          if (vertical) { const p = place(w, d, 1.8, 0); this.addMover(p.x, p.y + 1.2, p.z, w, d, new V(0, 1, 0), 2.4, 1.1 + r() * 0.5, r() * 6); cur = { ...p, w, d }; }
          else { const amp = 2.1; const gap = 4.0 + r() * 1.2; const p = place(w, d, gap, 0); this.addMover(p.x, p.y, p.z, w, d, new V(Math.sin(heading), 0, Math.cos(heading)), amp, 1 + r() * 0.6, r() * 6); cur = { ...p, w, d }; cur.x += Math.sin(heading) * 0; }
          platformMade = true; break;
        }
        case "spring": {
          w = d = 3.2; const p = place(w, d, gapBase, dyRand()); this.addPlatform(p.x, p.y, p.z, w, d); this.addSpring(p.x, p.y, p.z); cur = { ...p, w, d };
          const w2 = 3.6 + r() * 2, d2 = 3.6 + r() * 2; const dy = 2.6 + r() * 2.4; const p2 = place(w2, d2, 3.2 + r() * 2.8, dy); this.addPlatform(p2.x, p2.y, p2.z, w2, d2);
          this.coinLine(new V(p.x, p.y + 0.6, p.z), new V(p2.x, p2.y + 0.6, p2.z), 5, 3.4);
          cur = { ...p2, w: w2, d: d2 }; w = w2; d = d2; platformMade = true; big = true; advance(); break;
        }
        case "beam": {
          const along = Math.abs(Math.sin(heading)) > Math.abs(Math.cos(heading)) ? "x" : "z"; const len = 6 + r() * 4;
          w = along === "x" ? len : 1.5; d = along === "z" ? len : 1.5; const p = place(w, d, gapBase, dyRand() * 0.5);
          this.addPlatform(p.x, p.y, p.z, w, d, { thick: 0.7, color: th.alt }); this.coinLine(startVec.clone().setY(p.y), new V(p.x, p.y, p.z), 3, 0.2); cur = { ...p, w, d }; platformMade = true; break;
        }
        case "rotbar": {
          w = d = 7; const p = place(w, d, gapBase, dyRand() * 0.5); this.addPlatform(p.x, p.y, p.z, w, d); this.addRotBar(p.x, p.y, p.z, 2.7, 1.3 + diff * 0.18 + r() * 0.4); cur = { ...p, w, d }; big = true; platformMade = true;
          for (let k = 0; k < 6; k++) { const a = (k / 6) * 6.28; this.addCoin(new V(p.x + Math.cos(a) * 3.1, p.y + 0.7, p.z + Math.sin(a) * 3.1)); } break;
        }
        case "tower": {
          const steps = 6 + Math.floor(r() * 3); const c0 = { ...cur }; let ang = heading; let px = c0.x, pz = c0.z, py = c0.y;
          for (let k = 0; k < steps; k++) { ang += 0.9; px += Math.sin(ang) * 3.7; pz += Math.cos(ang) * 3.7; py += 1.05; this.addPlatform(px, py, pz, 2.6, 2.6, { thick: 0.8 }); if (k % 2 === 0) this.addCoin(new V(px, py + 0.8, pz)); cur = { x: px, y: py, z: pz, w: 2.6, d: 2.6 }; }
          heading = ang; platformMade = true; break;
        }
        case "climb": {
          w = 5; d = 5; const p = place(w, d, gapBase, 0); this.addPlatform(p.x, p.y, p.z, w, d); cur = { ...p, w, d };
          const h = 4.8; const dx = Math.sin(heading), dz = Math.cos(heading);
          const wallW = Math.abs(dx) > Math.abs(dz) ? 0.7 : 4, wallD = Math.abs(dx) > Math.abs(dz) ? 4 : 0.7;
          const e = exitDist(cur.w, cur.d, dx, dz);
          const wx = cur.x + dx * (e + 0.45), wz = cur.z + dz * (e + 0.45);
          const wy = cur.y + h; const wall = this.addPlatform(wx, wy, wz, wallW, wallD, { thick: h + 0.4, kind: "climb", color: "#4cb85a", sideColor: "#3f9a4a", round: 0.05 });
          void wall;
          for (let k = 0; k < 5; k++) { const vy = cur.y + 0.9 + k * 0.85; const side = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), stdMat("#ffd23c", { emissive: "#ffb000", emissiveIntensity: 0.5 })); side.position.set(wx - dx * (0.4 + 0.0), vy, wz - dz * 0.4); this.scene.add(side); }
          const w2 = 5, d2 = 5; const e2 = exitDist(w2, d2, dx, dz); const nx = wx + dx * (e2 - 0.1), nz = wz + dz * (e2 - 0.1);
          this.addPlatform(nx, wy, nz, w2, d2); cur = { x: nx, y: wy, z: nz, w: w2, d: d2 }; w = w2; d = d2; platformMade = true; big = true; break;
        }
        case "arena": {
          w = d = 9; const p = place(w, d, gapBase * 0.8, 0); this.addPlatform(p.x, p.y, p.z, w, d, { thick: 2 }); cur = { ...p, w, d };
          this.addCheckpoint(p.x - w / 2 + 1.2, p.y, p.z - d / 2 + 1.2); cpDone++; big = true; platformMade = true;
          break;
        }
        case "goal": {
          w = d = 9; const p = place(w, d, gapBase, 0); this.addPlatform(p.x, p.y, p.z, w, d, { thick: 2 }); cur = { ...p, w, d }; this.addGoal(p.x, p.y, p.z); platformMade = true; break;
        }
      }
      if (!platformMade) { i++; continue; }
      void prevCur;
      this.path.push({ p: new V(cur.x, cur.y, cur.z), yaw: heading + Math.PI });
      // coins on gap
      if (type === "static" || type === "ice" || type === "small") this.coinLine(startVec.clone().setY(startVec.y + 0.3), new V(cur.x, cur.y + 0.3, cur.z), 3 + Math.floor(r() * 3), 0.8);
      const bounds = { minx: cur.x - cur.w / 2 + 0.8, maxx: cur.x + cur.w / 2 - 0.8, minz: cur.z - cur.d / 2 + 0.8, maxz: cur.z + cur.d / 2 - 0.8 };
      if (big && type !== "goal") {
        bigPlats.push({ x: cur.x, y: cur.y, z: cur.z, w: cur.w, d: cur.d, heading });
        // enemies
        const ew = [{ k: "grunt", w: mix.grunt ?? 0 }, { k: "fox", w: mix.fox ?? 0 }, { k: "cannon", w: mix.cannon ?? 0 }, { k: "flyer", w: mix.flyer ?? 0 }, { k: "boulder", w: (mix.boulder ?? 0) }];
        const et = ew.reduce((a, b) => a + b.w, 0);
        if (et > 0 && i > 1 && (type !== "arena" || r() < 0.5) && r() < 0.35 + diff * 0.12) {
          let x = r() * et; let ek = "grunt"; for (const e of ew) { x -= e.w; if (x <= 0) { ek = e.k; break; } }
          const c = new V(cur.x + (r() - 0.5) * (cur.w - 3), cur.y, cur.z + (r() - 0.5) * (cur.d - 3));
          if (ek === "grunt") { const n = 1 + (diff > 3 && r() < 0.5 ? 1 : 0); for (let k = 0; k < n; k++) this.addGrunt(c.x + k, c.y, c.z, bounds); }
          else if (ek === "fox") this.addFox(c.x, c.y, c.z, bounds);
          else if (ek === "cannon" && cur.w > 4) this.addCannon(cur.x + (cur.w / 2 - 0.9) * Math.sign(r() - 0.5), cur.y, cur.z + (cur.d / 2 - 0.9) * Math.sign(r() - 0.5), 3.4 - diff * 0.3);
          else if (ek === "flyer") this.addFlyer(cur.x, cur.y + 1.6, cur.z);
          else if (ek === "boulder") { const axis = cur.w > cur.d ? "x" : "z"; this.addBoulder(cur.x, cur.y, cur.z, axis, (axis === "x" ? cur.w : cur.d) - 1.6, 3.4 + diff * 0.3); }
        }
        // crates
        if (r() < 0.5 && cur.w > 4) { const c = new V(cur.x + (r() - 0.5) * (cur.w - 2.5), cur.y, cur.z + (r() - 0.5) * (cur.d - 2.5)); this.addCrate(c.x, c.y, c.z, 4 + Math.floor(r() * 5)); }
        // coin cluster
        if (r() < 0.6) for (let k = 0; k < 4; k++) this.addCoin(new V(cur.x + (k - 1.5) * 0.8, cur.y + 0.6, cur.z + 1.2));
        // props decoration on platform corners
        if (r() < 0.5 && cur.w > 4.5) { const pr = makeProp(th.prop, r, th); pr.position.set(cur.x + cur.w / 2 - 0.7, cur.y, cur.z - cur.d / 2 + 0.7); pr.scale.setScalar(0.8 + r() * 0.5); pr.rotation.y = r() * 6; this.scene.add(pr); }
      }
      // gadget pickup
      if (i === gadgetAt) { this.addPickup(pl.gadget!, new V(cur.x, cur.y, cur.z + 0.0)); }
      // bots & puzzles & vortex via nooks
      const mk = (variant: number, make: (pos: THREE.Vector3) => void) => {
        const side = r() < 0.5 ? -1 : 1; const px = Math.cos(heading) * side, pz = -Math.sin(heading) * side;
        if (variant === 0) { make(new V(cur.x + (r() - 0.5) * (cur.w - 2), cur.y, cur.z + (r() - 0.5) * (cur.d - 2))); return; }
        const e = exitDist(cur.w, cur.d, px, pz);
        if (variant === 1) { // hop nook
          const nw = 3; const gap = 2.8; const dist = e + gap + exitDist(nw, nw, px, pz); const nx = cur.x + px * dist, nz = cur.z + pz * dist, ny = cur.y + 0.6;
          this.addPlatform(nx, ny, nz, nw, nw, { thick: 0.9, color: th.alt }); this.coinLine(new V(cur.x + px * e, cur.y, cur.z + pz * e), new V(nx, ny, nz), 2, 0.9); make(new V(nx, ny, nz));
        } else { // spring nook
          const sx = cur.x + px * (e - 1.0), sz = cur.z + pz * (e - 1.0); this.addSpring(sx, cur.y, sz, 18);
          const nw = 3.4; const dist = e + 4.2 + exitDist(nw, nw, px, pz); const nx = cur.x + px * dist, nz = cur.z + pz * dist, ny = cur.y + 3.2;
          this.addPlatform(nx, ny, nz, nw, nw, { thick: 0.9, color: th.alt }); make(new V(nx, ny, nz));
        }
      };
      if (botAt.has(i)) {
        const bi = botAt.get(i)!; const variant = Math.floor(r() * 3);
        if (!this.botFound[bi]) { if (variant === 0 && r() < 0.5 && cur.w > 4 && big) { mk(0, (pos) => { this.addBot(bi, pos.clone().setY(pos.y), true); this.addCrate(pos.x + 0.1, pos.y, pos.z, 3, bi); }); } else mk(variant, (pos) => this.addBot(bi, pos)); }
        else mk(variant, () => { /* already rescued: still build nook for geometry consistency */ });
      }
      if (puzzleIdx.has(i)) { const pi = puzzleIdx.get(i)!; mk(2, (pos) => { if (!this.puzzleFound[pi]) this.addPuzzle(pi, pos.clone().add(new V(0, 1.1, 0))); }); }
      if (i === vortexAt) mk(2, (pos) => { this.vortexPos = pos.clone().add(new V(0, 1.4, 0)); this.buildVortex(this.vortexPos); });
      i++;
    }
    // extra: boulders need no more, finalize
    this.minY = Math.min(...this.solids.map((s) => s.min.y)) - 24;
    this.sky.waterY = this.minY + 14;
    this.addDecor(46, this.path);
    this.cpPos.copy(this.spawn);
  }

  private buildVortex(pos: THREE.Vector3) {
    const g = new THREE.Group();
    for (let k = 0; k < 3; k++) { const t = new THREE.Mesh(new THREE.TorusGeometry(0.5 + k * 0.28, 0.07, 8, 28), new THREE.MeshStandardMaterial({ color: ["#ffd23c", "#ff6fa8", "#6ad0ff"][k], emissive: ["#ffd23c", "#ff6fa8", "#6ad0ff"][k], emissiveIntensity: 1.5 })); t.name = "v" + k; g.add(t); }
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture("#ffd23c"), blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); glow.scale.setScalar(4); g.add(glow);
    g.position.copy(pos); this.scene.add(g); this.vortexObj = g;
  }

  // ───── Boss arena ─────
  private buildBossArena() {
    const pl = this.planet!; const th = this.theme; const H = this.arenaHalf;
    this.addPlatform(0, 0, 0, H * 2, H * 2, { thick: 4, round: 0.8 });
    // decorative rim
    const rimMat = stdMat(th.accent, { emissive: th.accent, emissiveIntensity: 0.6 });
    for (const [x, z, w, d] of [[0, H, H * 2, 0.4], [0, -H, H * 2, 0.4], [H, 0, 0.4, H * 2], [-H, 0, 0.4, H * 2]] as number[][]) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.12, d), rimMat); m.position.set(x, 0.1, z); this.scene.add(m); }
    const ring = new THREE.Mesh(new THREE.RingGeometry(3, 3.2, 48), new THREE.MeshBasicMaterial({ color: th.accent, transparent: true, opacity: 0.5, side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.y = 0.07; this.scene.add(ring);
    this.spawn.set(0, 0.02, H - 4); this.spawnYaw = 0; this.minY = -30; this.path.push({ p: new V(0, 0, 0), yaw: 0 });
    this.sky.waterY = -26;
    this.boss = new Boss(pl.boss!, this);
    this.addCheckpoint(-H + 2, 0, H - 2); this.checkpoints[0].on = true; this.checkpoints[0].obj.visible = false;
    this.addDecor(36, [{ p: new V(0, 0, 0), yaw: 0 }]);
    for (let i = 0; i < 4; i++) this.addCrate((i < 2 ? -1 : 1) * (H - 2), 0, (i % 2 ? -1 : 1) * (H - 2), 6);
  }
  spawnVip(pos: THREE.Vector3) { this.vip = this.planet?.vip; this.addBot(-1, pos); }

  // ───── Hub ─────
  buildHub(unlocks: { gatcha: boolean; garage: boolean; safari: boolean }, onAct: (id: string) => void, rescued: BotDef[], vips: string[], puzzlesGot: number) {
    this.isHub = true; const th = this.theme; const r = this.r;
    const HS = 34;
    this.addPlatform(0, 0, 0, HS * 2, HS * 2, { thick: 8, round: 2.5 });
    this.minY = -40; this.sky.waterY = -34;
    this.spawn.set(0, 0.02, 18); this.spawnYaw = 0;
    // PS5 crash
    const ps5 = makePS5(); ps5.position.set(-6, -0.2, -22); ps5.rotation.set(0.12, 0.5, -0.18); ps5.scale.setScalar(1.7); this.scene.add(ps5);
    this.solids.push({ obj: ps5, min: new V(-14, 0, -27), max: new V(2, 5.2, -17), vel: new V(), kind: "static", active: true });
    this.ents.push({ obj: ps5, update: (_dt, t) => { if (Math.random() < 0.3) this.burst(new V(-6 + (Math.random() - 0.5) * 6, 9, -20), "#8a8f9a", 1, 1.0, 1.6, 1.2, -1.2, 0.8); void t; } });
    // Dual Speeder landing pad
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.4, 0.25, 32), stdMat("#2a2f45", { metalness: 0.4 })); pad.position.set(0, 0.12, 20); this.scene.add(pad);
    const padRing = new THREE.Mesh(new THREE.TorusGeometry(2.6, 0.08, 8, 40), stdMat("#4aa8ff", { emissive: "#4aa8ff", emissiveIntensity: 2 })); padRing.rotation.x = Math.PI / 2; padRing.position.set(0, 0.28, 20); this.scene.add(padRing);
    this.interact.push({ pos: new V(0, 0, 20), r: 4, label: "Galaxy Map", action: () => onAct("map") });
    // Gatcha Lab
    const bld = (x: number, z: number, color: string, label: string, id: string, ok: boolean, need: number) => {
      const g = new THREE.Group();
      const body = new THREE.Mesh(new RoundedBoxGeometry(7, 5, 6, 4, 0.5), stdMat(ok ? color : "#6a7088", { roughness: 0.4 })); body.position.y = 2.5; body.castShadow = true; body.receiveShadow = true; g.add(body);
      const roof = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 3.8, 1.6, 4), stdMat(ok ? "#ffffff" : "#8a90a8")); roof.rotation.y = Math.PI / 4; roof.position.y = 5.8; roof.scale.set(1.15, 1, 1); g.add(roof);
      const sign = textSprite(label.toUpperCase(), "#fff", ok ? "#2f6df0" : "#555a70", 1.9); sign.position.set(0, 8.2, 0); g.add(sign);
      if (!ok) { const lock = textSprite(`${need} PIECES`, "#fff", "#ff3b5c", 1.3); lock.position.set(0, 6.6, 3.5); g.add(lock); }
      g.position.set(x, 0, z); this.scene.add(g);
      this.solids.push({ obj: g, min: new V(x - 3.5, 0, z - 3), max: new V(x + 3.5, 5.0, z + 3), vel: new V(), kind: "static", active: true });
      this.interact.push({ pos: new V(x, 0, z + 5.2), r: 3.3, label, locked: ok ? null : `Needs ${need} Puzzle Pieces (${puzzlesGot})`, action: () => onAct(id) });
      return g;
    };
    const bg = bld(-22, 4, "#ff6fc8", "Gatcha Lab", "gatcha", unlocks.gatcha, 2);
    // capsule machine on top
    const cm = new THREE.Mesh(new THREE.SphereGeometry(1.5, 20, 16), new THREE.MeshStandardMaterial({ color: "#ffffff", transparent: true, opacity: 0.55, roughness: 0.05, metalness: 0.3 })); cm.position.set(0, 9.9, 0); bg.add(cm);
    for (let k = 0; k < 6; k++) { const c = new THREE.Mesh(new THREE.SphereGeometry(0.36, 10, 8), stdMat(["#ff5a7a", "#ffd23c", "#4fd8ff", "#7aff7a", "#c07aff", "#ff9a3c"][k])); c.position.set(Math.cos(k) * 0.7, 9.5 + Math.sin(k * 2) * 0.4, Math.sin(k) * 0.7); bg.add(c); }
    bld(22, 4, "#4f8bff", "Speeder Garage", "garage", unlocks.garage, 5);
    // Safari park (fenced area with robotic animals)
    const sx = 20, sz = -14;
    const safariOK = unlocks.safari;
    const fenceMat = stdMat(safariOK ? "#fff3c0" : "#8a90a8");
    for (let k = -6; k <= 6; k++) for (const [fx, fz, rot] of [[sx + k * 1.4, sz - 8.4, 0], [sx + k * 1.4, sz + 8.4, 0], [sx - 8.4, sz + k * 1.4, 1], [sx + 8.4, sz + k * 1.4, 1]] as number[][]) { const p = new THREE.Mesh(new THREE.BoxGeometry(rot ? 0.15 : 1.2, 0.9, rot ? 1.2 : 0.15), fenceMat); p.position.set(fx, 0.45, fz); this.scene.add(p); }
    this.solids.push({ obj: new THREE.Object3D(), min: new V(sx - 8.6, 0, sz - 8.6), max: new V(sx + 8.6, 0.9, sz - 8.2), vel: new V(), kind: "static", active: true }, { obj: new THREE.Object3D(), min: new V(sx - 8.6, 0, sz + 8.2), max: new V(sx + 8.6, 0.9, sz + 8.6), vel: new V(), kind: "static", active: true }, { obj: new THREE.Object3D(), min: new V(sx - 8.6, 0, sz - 8.6), max: new V(sx - 8.2, 0.9, sz + 8.6), vel: new V(), kind: "static", active: true });
    const sign = textSprite(safariOK ? "SAFARI PARK" : "SAFARI • 8 PIECES", "#fff", safariOK ? "#27a85a" : "#555a70", 1.8); sign.position.set(sx, 4, sz + 8.4); this.scene.add(sign);
    this.interact.push({ pos: new V(sx + 8.8, 0, sz), r: 3, label: "Safari Park Photo", locked: safariOK ? null : `Needs 8 Puzzle Pieces (${puzzlesGot})`, action: () => onAct("safari") });
    const animals: Actor[] = [];
    const zoo: [() => Actor, THREE.Vector3][] = [[() => makeFox(0.8), new V(sx - 3, 0, sz - 3)], [() => makeFox(0.8), new V(sx + 3, 0, sz + 3)], [() => makeBird("flamingo", 1.3), new V(sx, 2.2, sz)], [() => makeBird("parrot", 1.0), new V(sx - 4, 2.8, sz + 4)], [() => makeBird("stork", 1.3), new V(sx + 4, 3.2, sz - 4)]];
    for (const [mk, p] of zoo) {
      const a = mk(); const act = Object.values(a.actions)[0]; if (act) { act.play(); act.timeScale = 1; } if (a.actions.Walk) a.play("Walk");
      const g = new THREE.Group(); g.add(a.root); g.position.copy(p); this.scene.add(g); animals.push(a);
      const ph = r() * 6, rad = 2 + r() * 3; const c0 = p.clone();
      this.ents.push({ obj: g, update: (dt, t) => { a.update(dt); const ang = t * 0.5 + ph; g.position.x = c0.x + Math.cos(ang) * rad; g.position.z = c0.z + Math.sin(ang) * rad; g.rotation.y = -ang + Math.PI; } });
    }
    // Puzzle board
    const board = new THREE.Group();
    const frame = new THREE.Mesh(new RoundedBoxGeometry(9, 5, 0.6, 3, 0.2), stdMat("#20243a")); frame.position.y = 4; frame.castShadow = true; board.add(frame);
    for (let k = 0; k < 12; k++) { const col = k % 4, row = Math.floor(k / 4); const on = k < puzzlesGot; const tile = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.3, 0.2), stdMat(on ? ["#43b0ff", "#ff6fa8", "#7aff7a", "#ffd23c"][k % 4] : "#3a4060", { emissive: on ? ["#43b0ff", "#ff6fa8", "#7aff7a", "#ffd23c"][k % 4] : "#000", emissiveIntensity: on ? 0.5 : 0 })); tile.position.set(-3.3 + col * 2.2, 5.2 - row * 1.5, 0.35); board.add(tile); }
    const lg1 = new THREE.CylinderGeometry(0.15, 0.15, 3, 6); for (const s of [-1, 1]) { const l = new THREE.Mesh(lg1, stdMat("#20243a")); l.position.set(s * 3.5, 1.5, 0); board.add(l); }
    board.position.set(-24, 0, -8); board.rotation.y = 0.5; this.scene.add(board);
    this.solids.push({ obj: board, min: new V(-28, 0, -12), max: new V(-20, 3, -4), vel: new V(), kind: "static", active: true });
    // bots hanging out
    const list = rescued.slice(0, 70);
    list.forEach((def, i) => {
      const a = Math.random() * 6.28 + i, rr = 7 + (i % 5) * 3 + Math.random() * 2;
      let x = Math.cos(a) * rr, z = Math.sin(a) * rr * 0.9 + 4; if (Math.abs(x + 22) < 6 && Math.abs(z - 4) < 6) x += 10; if (Math.abs(x - 22) < 6 && Math.abs(z - 4) < 6) x -= 10;
      const actor = def.model === "xbot" ? makeXbot(def.color, 1.0) : makeRobot({ body: def.color, hat: def.hat, hatColor: "#ffffff", height: 0.95 });
      actor.play(def.model === "xbot" ? "idle" : def.anim, { speed: 0.8 + Math.random() * 0.4 });
      const g = new THREE.Group(); g.add(actor.root); g.position.set(x, 0, z); g.rotation.y = Math.random() * 6; this.scene.add(g);
      this.ents.push({ obj: g, update: (dt) => { actor.update(dt); const p = this.player; if (p && p.spinT > 0 && Math.hypot(p.pos.x - g.position.x, p.pos.z - g.position.z) < 1.6 && actor.current !== "Jump") { actor.play("Jump", { once: true }); sfx("jump"); this.burst(g.position.clone().add(new V(0, 1, 0)), "#ffd23c", 8, 3, 0.6); } if (actor.current === "Jump" && actor.isDone("Jump")) actor.play(def.model === "xbot" ? "idle" : def.anim); } });
    });
    vips.forEach((name, i) => {
      const info = VIP_BOTS[name] ?? { color: "#fff", hat: "crown", note: "" };
      const a = makeRobot({ body: info.color, hat: info.hat, hatColor: "#ffd23c", height: 1.15 }); a.play("Dance");
      const g = new THREE.Group(); g.add(a.root); const ang = -0.9 + i * 0.35; g.position.set(Math.sin(ang) * 14, 0, 11 + Math.cos(ang) * 3); g.rotation.y = ang + 3.14; this.scene.add(g);
      const nm = textSprite(name.toUpperCase(), "#fff", "#8a4fe0", 0.9); nm.position.set(0, 2.1, 0); g.add(nm);
      this.ents.push({ obj: g, update: (dt) => a.update(dt) });
    });
    // decorative trees
    for (let i = 0; i < 26; i++) { const a = r() * 6.28, rr = 26 + r() * 6; const pr = makeProp(th.prop, r, th); pr.position.set(Math.cos(a) * rr, 0, Math.sin(a) * rr); pr.scale.setScalar(1.2 + r()); this.scene.add(pr); }
    this.addDecor(40, [{ p: new V(0, 0, 0), yaw: 0 }]);
    this.path.push({ p: new V(0, 0, 0), yaw: 0 });
  }

  // ───── per-frame ─────
  update(dt: number, t: number) {
    const p = this.player;
    this.time += dt;
    for (const s of this.solids) s.update?.(t, dt);
    this.light.follow(p.pos);
    // ents
    for (const u of this.ents) u.update(dt, t, this);
    this.ents = this.ents.filter((u) => !u.remove);
    this.boss?.update(dt, t, this);
    // springs
    for (const s of this.springs) {
      s.t = Math.max(0, s.t - dt * 3); s.obj.scale.y = 1 - s.t * 0.4; s.obj.children[2].position.y = 0.52 + Math.sin(t * 3 + s.pos.x) * 0.0;
      const dx = p.pos.x - s.pos.x, dz = p.pos.z - s.pos.z;
      if (p.vel.y <= 0 && Math.hypot(dx, dz) < 0.85 && p.pos.y - (s.pos.y - 0.4) < 0.45 && p.pos.y > s.pos.y - 0.9 && p.dead <= 0) {
        p.vel.y = s.power * (p.gadget === "frog" ? 1.12 : 1); p.onGround = false; p.standing = null; p.jumping = false; s.t = 1; sfx("spring"); p.actor.play("Jump", { once: true, fade: 0.05 });
        this.burst(new V(s.pos.x, s.pos.y, s.pos.z), "#ffffff", 8, 3, 0.5, 0.3, 4);
      }
    }
    // coins
    const pc = p.center;
    for (const c of this.coins) {
      if (c.got) continue;
      if (c.vel) { c.t! += dt; c.vel.y -= 22 * dt; c.obj.position.addScaledVector(c.vel, dt); const gy = p.groundBelow(c.obj.position.x, c.obj.position.z, c.obj.position.y + 0.6); if (gy !== null && c.obj.position.y < gy + 0.4 && c.vel.y < 0) { c.obj.position.y = gy + 0.4; c.vel.y *= -0.45; c.vel.x *= 0.7; c.vel.z *= 0.7; if (Math.abs(c.vel.y) < 1) { c.vel = undefined; } } if (c.obj.position.y < this.minY) { c.got = true; c.obj.visible = false; } if ((c.t ?? 0) < 0.45) { c.obj.rotation.y += dt * 10; continue; } }
      c.obj.rotation.y += dt * 3;
      if (!c.vel) c.obj.position.y += Math.sin(t * 3 + c.obj.position.x) * 0.002;
      const d = c.obj.position.distanceTo(pc);
      if (d < 3.2 && p.dead <= 0 && !c.vel) { c.obj.position.lerp(pc, Math.min(1, dt * (9 - d * 1.5))); }
      if (d < 0.85 && p.dead <= 0) { c.got = true; c.obj.visible = false; this.runCoins++; sfx("coin"); this.burst(c.obj.position, "#ffd23c", 4, 2, 0.4, 0.22, 2); this.ev.onCoin(); }
    }
    // crates: spin / stomp / slam
    if (p.spinT > 0) for (const c of this.crates) if (!c.broken && Math.hypot(c.solid.obj.position.x - p.pos.x, c.solid.obj.position.z - p.pos.z) < (p.gadget === "gloves" ? 2.8 : 1.9) && Math.abs(c.solid.obj.position.y - p.pos.y) < 1.4) this.breakCrate(c);
    for (const c of this.crates) if (!c.broken && p.vel.y < -3 && Math.abs(c.solid.obj.position.x - p.pos.x) < 0.9 && Math.abs(c.solid.obj.position.z - p.pos.z) < 0.9 && Math.abs(p.pos.y - (c.solid.obj.position.y + 1.1)) < 0.3) { this.breakCrate(c); p.vel.y = 8; }
    // enemies
    const range = p.gadget === "gloves" ? 2.7 : 1.8;
    for (const e of this.enemies) {
      if (!e.alive || !e.obj.visible) continue;
      const ex = e.pos.x, ez = e.pos.z, ey = e.pos.y;
      const dxz = Math.hypot(p.pos.x - ex, p.pos.z - ez);
      if (p.spinT > 0 && dxz < range + e.r && Math.abs(p.pos.y + 0.4 - (ey + e.h / 2)) < 1.4) { e.spin(this); continue; }
      if (p.dead > 0) continue;
      if (dxz < e.r + 0.35 && p.pos.y < ey + e.h + 0.3 && p.pos.y + 0.95 > ey) {
        if (p.vel.y < -1 && p.pos.y > ey + e.h * 0.45) { if (e.stomp(this)) { p.vel.y = 10.5; p.onGround = false; sfx("stomp"); continue; } }
        if (e.hurts) p.hurt(new V(ex, ey, ez));
      }
    }
    // shockwaves visuals
    for (const s of this.shock) { s.t += dt; s.r += dt * 9; s.obj.scale.setScalar(s.r / 0.4); (s.obj.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.8 - s.t * 2); if (s.t > 0.4) { s.obj.removeFromParent(); } }
    this.shock = this.shock.filter((s) => s.t <= 0.4);
    // bots
    for (const b of this.botsE) {
      if (b.state === "hidden") continue;
      b.t += dt; b.actor.update(dt);
      b.bubble.visible = b.state === "wait"; b.bubble.position.y = 1.95 + Math.sin(b.t * 4) * 0.08;
      if (b.state === "wait") {
        const d = Math.hypot(p.pos.x - b.obj.position.x, p.pos.z - b.obj.position.z);
        const near = d < 1.3 && Math.abs(p.pos.y - b.obj.position.y) < 1.6;
        if ((near || (p.spinT > 0 && d < 2.0)) && p.dead <= 0) {
          b.state = "saved"; b.t = 0; sfx("rescue");
          if (b.actor.actions.ThumbsUp) b.actor.play("Jump", { once: true });
          this.burst(b.obj.position.clone().add(new V(0, 1, 0)), "#ffd23c", 24, 5, 1.0, 0.35, 5, 0.6); this.burst(b.obj.position.clone().add(new V(0, 1, 0)), "#4fd8ff", 14, 4, 0.9, 0.3, 4);
          if (b.idx >= 0) { this.botFound[b.idx] = true; this.ev.onBot(b.idx); } else { this.ev.onToast(`VIP Bot rescued: ${b.vip}!`); this.finishSoon(b.vip); }
        } else { const face = Math.atan2(p.pos.x - b.obj.position.x, p.pos.z - b.obj.position.z); b.actor.root.rotation.y += (face - b.actor.root.rotation.y) * Math.min(1, dt * 3); }
      } else if (b.state === "saved") {
        b.obj.position.y = b.pos.y + Math.max(0, Math.sin(Math.min(b.t, 1) * Math.PI) * 1.2); if (b.t > 1.4) { b.obj.visible = false; }
        b.actor.root.rotation.y += dt * 12;
      }
    }
    // puzzle pieces
    for (const z of this.puzzlesE) {
      if (z.got) continue; z.obj.rotation.y += dt * 2; z.obj.position.y += Math.sin(t * 2.5) * 0.004;
      if (z.obj.position.distanceTo(pc) < 1.3 && p.dead <= 0) { z.got = true; z.obj.visible = false; this.puzzleFound[z.idx] = true; sfx("puzzle"); this.burst(z.obj.position, "#9ad8ff", 30, 6, 1.2, 0.4, 3); this.ev.onPuzzle(z.idx); }
    }
    // checkpoints
    for (const c of this.checkpoints) {
      c.light.rotation.y += dt * 2; c.light.position.y = 2.5 + Math.sin(t * 3) * 0.08;
      if (!c.on && c.pos.distanceTo(p.pos) < 2.2) { c.on = true; (c.light.material as THREE.MeshStandardMaterial).color.set("#5aff7a"); (c.light.material as THREE.MeshStandardMaterial).emissive.set("#2aff5a"); this.cpPos.copy(c.pos); this.cpCoins = this.runCoins; sfx("check"); this.burst(c.pos.clone().add(new V(0, 2, 0)), "#5aff7a", 18, 4, 0.8, 0.3, 3); this.ev.onCheckpoint(); }
    }
    // pickups
    for (const k of this.pickups) {
      if (k.got) continue; k.obj.rotation.y += dt * 1.5; k.obj.position.y = k.pos.y + Math.sin(t * 2) * 0.12;
      if (k.obj.position.distanceTo(pc) < 1.4 && p.dead <= 0) { k.got = true; k.obj.visible = false; this.gadgetOwned = k.gadget; p.setGadget(k.gadget); this.burst(k.obj.position, "#ffffff", 22, 5, 0.9, 0.35, 3); this.ev.onToast({ frog: "Frog Suit! Jump super high", rocket: "Rocket Boost! Hold R / R2 to fly", monkey: "Monkey Climbers! Climb green walls", gloves: "Boxing Gloves! Punch from afar", none: "" }[k.gadget]); }
    }
    // vortex
    if (this.vortexObj) { this.vortexObj.children.forEach((c, i) => { if (c.name.startsWith("v")) c.rotation.set(t * (1 + i * 0.5), t * (0.7 - i * 0.2), 0); }); if (this.vortexPos && !this.vortexObj.userData.got && this.vortexPos.distanceTo(pc) < 1.6) { this.vortexObj.userData.got = true; this.vortexObj.visible = false; sfx("warp"); this.burst(this.vortexPos, "#ffd23c", 50, 7, 1.4, 0.45, 2); this.ev.onVortex(); } }
    // goal
    if (this.goalObj) {
      const s = this.goalObj.getObjectByName("gstar"); if (s) { s.rotation.y += dt * 2; s.rotation.x += dt; }
      if (!this.finished && p.dead <= 0 && Math.hypot(p.pos.x - this.goalPos.x, p.pos.z - this.goalPos.z) < 2.0 && Math.abs(p.pos.y - this.goalPos.y) < 3) { this.finished = true; this.finishSoon(); }
    }
    this.fx.update(dt);
    // pause-free particles for hub smoke etc.
  }
  finishSoon(vip?: string) {
    this.finished = true; sfx("goal"); this.player.celebrate = 3; this.player.frozen = true; this.player.vel.set(0, 0, 0);
    this.burst(this.player.center.add(new V(0, 1, 0)), "#ffd23c", 60, 8, 1.6, 0.4, 3); this.burst(this.player.center, "#ff6fa8", 40, 7, 1.6, 0.4, 3); this.burst(this.player.center, "#4fd8ff", 40, 7, 1.6, 0.4, 3);
    setTimeout(() => this.ev.onGoal(vip), 1800);
  }
  nearestPath(p: THREE.Vector3) {
    let best = 0, bd = 1e9;
    for (let i = 0; i < this.path.length; i++) { const d = this.path[i].p.distanceToSquared(p); if (d < bd) { bd = d; best = i; } }
    return this.path[best];
  }
  dispose() {
    this.scene.traverse((o) => { const m = o as THREE.Mesh; if (m.isMesh) { m.geometry?.dispose(); } });
  }
}
