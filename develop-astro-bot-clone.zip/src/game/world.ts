import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { THEMES, rng, type Theme } from "./data";
import { glowTexture } from "./assets";
import { ui } from "./store";

export class Gfx {
  renderer: THREE.WebGLRenderer;
  composer: EffectComposer;
  renderPass: RenderPass;
  bloom: UnrealBloomPass;
  camera = new THREE.PerspectiveCamera(58, 1, 0.1, 900);
  env: THREE.Texture;
  w = 1; h = 1;
  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.92;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    const pm = new THREE.PMREMGenerator(this.renderer);
    this.env = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    const rt = new THREE.WebGLRenderTarget(4, 4, { type: THREE.HalfFloatType, samples: 4 });
    this.composer = new EffectComposer(this.renderer, rt);
    this.renderPass = new RenderPass(new THREE.Scene(), this.camera);
    this.bloom = new UnrealBloomPass(new THREE.Vector2(256, 256), 0.42, 0.55, 0.88);
    this.composer.addPass(this.renderPass);
    this.composer.addPass(this.bloom);
    this.composer.addPass(new OutputPass());
    this.resize();
    window.addEventListener("resize", () => this.resize());
  }
  resize() {
    this.w = window.innerWidth; this.h = window.innerHeight;
    this.renderer.setSize(this.w, this.h, false);
    this.composer.setSize(this.w, this.h);
    this.camera.aspect = this.w / this.h; this.camera.updateProjectionMatrix();
  }
  render(scene: THREE.Scene) {
    this.renderPass.scene = scene;
    this.renderer.shadowMap.enabled = ui.settings.shadows;
    this.bloom.enabled = ui.settings.bloom;
    this.composer.render();
  }
}

// ───────── Sky / atmosphere ─────────
export class Sky {
  dome: THREE.Mesh;
  stars: THREE.Points;
  decor = new THREE.Group();
  sun: THREE.Sprite;
  constructor(public scene: THREE.Scene, public theme: Theme, seed = 1) {
    const mat = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: { top: { value: new THREE.Color(theme.skyTop) }, mid: { value: new THREE.Color(theme.skyMid) }, bot: { value: new THREE.Color(theme.skyBot) } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }",
      fragmentShader: "uniform vec3 top; uniform vec3 mid; uniform vec3 bot; varying vec3 vP; void main(){ float h = vP.y; vec3 c = h>0.0 ? mix(mid, top, pow(clamp(h,0.0,1.0),0.6)) : mix(mid, bot, pow(clamp(-h*2.5,0.0,1.0),0.8)); gl_FragColor = vec4(c,1.0); }",
    });
    this.dome = new THREE.Mesh(new THREE.SphereGeometry(500, 32, 16), mat); this.dome.renderOrder = -10; this.dome.frustumCulled = false;
    scene.add(this.dome);
    const r = rng(seed * 7 + 3);
    const n = theme.stars ? 1100 : 200;
    const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const u = r() * 2 - 1, a = r() * Math.PI * 2, s = Math.sqrt(1 - u * u);
      const rad = 480; pos.set([Math.cos(a) * s * rad, Math.abs(u) * rad * (theme.stars ? 1 : 0.9) + (theme.stars ? 0 : 10) * (u < 0 ? -1 : 1), Math.sin(a) * s * rad], i * 3);
      const c = new THREE.Color().setHSL(r() < 0.5 ? 0.6 : 0.1, 0.5, 0.8 + r() * 0.2); col.set([c.r, c.g, c.b], i * 3);
    }
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(pos, 3)); g.setAttribute("color", new THREE.BufferAttribute(col, 3));
    this.stars = new THREE.Points(g, new THREE.PointsMaterial({ size: theme.stars ? 2.2 : 1.4, vertexColors: true, sizeAttenuation: false, fog: false, transparent: true, opacity: theme.stars ? 1 : 0.35, depthWrite: false }));
    scene.add(this.stars);
    this.sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture("#ffffff"), color: theme.sun, fog: false, depthWrite: false, transparent: true, blending: THREE.AdditiveBlending }));
    this.sun.scale.set(150, 150, 1); this.sun.position.set(180, 220, -300); scene.add(this.sun);
    scene.add(this.decor);
    this.buildDecor(theme, r);
  }
  private buildDecor(t: Theme, r: () => number) {
    const d = this.decor;
    const planetTex = (c1: string, c2: string) => {
      const c = document.createElement("canvas"); c.width = 256; c.height = 128; const x = c.getContext("2d")!;
      x.fillStyle = c1; x.fillRect(0, 0, 256, 128);
      for (let i = 0; i < 40; i++) { x.fillStyle = i % 2 ? c2 : c1; x.globalAlpha = 0.45; x.beginPath(); x.ellipse(r() * 256, r() * 128, 20 + r() * 50, 4 + r() * 12, 0, 0, 7); x.fill(); }
      const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return tx;
    };
    const cloudTex = (() => { const c = document.createElement("canvas"); c.width = 256; c.height = 128; const x = c.getContext("2d")!; for (let i = 0; i < 14; i++) { const gx = 40 + r() * 176, gy = 70 + r() * 20 - Math.sin(i) * 10, rad = 24 + r() * 28; const gr = x.createRadialGradient(gx, gy, 0, gx, gy, rad); gr.addColorStop(0, "rgba(255,255,255,0.95)"); gr.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = gr; x.fillRect(0, 0, 256, 128); } const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return tx; })();
    switch (t.bg) {
      case "clouds":
        for (let i = 0; i < 46; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: cloudTex, transparent: true, opacity: 0.85, depthWrite: false, color: t.skyBot })); const a = r() * 6.28, rr = 60 + r() * 380; s.position.set(Math.cos(a) * rr, -30 + r() * 20 - rr * 0.04, Math.sin(a) * rr); s.scale.set(120 + r() * 100, 50 + r() * 30, 1); d.add(s); }
        break;
      case "planets":
        for (let i = 0; i < 7; i++) { const rad = 20 + r() * 50; const m = new THREE.Mesh(new THREE.SphereGeometry(rad, 24, 16), new THREE.MeshStandardMaterial({ map: planetTex(["#ff9a5a", "#5ac8ff", "#c05aff", "#5aff9a", "#ff5a9a", "#ffd75a", "#8a8aff"][i], "#ffffff"), roughness: 0.8, fog: false })); const a = r() * 6.28; m.position.set(Math.cos(a) * (250 + r() * 100), -40 + r() * 140, Math.sin(a) * (250 + r() * 100)); d.add(m); if (i % 3 === 0) { const ring = new THREE.Mesh(new THREE.RingGeometry(rad * 1.4, rad * 2, 48), new THREE.MeshBasicMaterial({ color: "#ffe9b0", side: THREE.DoubleSide, transparent: true, opacity: 0.5, fog: false })); ring.rotation.x = 1.2; ring.position.copy(m.position); d.add(ring); } }
        break;
      case "sea": case "bubbles": case "lava": {
        const col = t.bg === "lava" ? "#ff5a1a" : t.bg === "sea" ? "#27b9e8" : "#1f8fc7";
        const w = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.MeshStandardMaterial({ color: col, roughness: 0.2, metalness: 0.1, emissive: t.bg === "lava" ? "#ff4000" : "#000000", emissiveIntensity: t.bg === "lava" ? 0.9 : 0, transparent: t.bg !== "lava", opacity: 0.88 }));
        w.rotation.x = -Math.PI / 2; w.position.y = this.waterY; d.add(w); (this as unknown as { water: THREE.Mesh }).water = w; break; }
      case "mesas":
        for (let i = 0; i < 24; i++) { const h = 30 + r() * 70; const m = new THREE.Mesh(new THREE.CylinderGeometry(10 + r() * 14, 16 + r() * 18, h, 8), new THREE.MeshStandardMaterial({ color: t.side, roughness: 0.9, flatShading: true })); const a = r() * 6.28, rr = 160 + r() * 220; m.position.set(Math.cos(a) * rr, h / 2 - 45, Math.sin(a) * rr); d.add(m); }
        break;
      case "pyramids":
        for (let i = 0; i < 14; i++) { const h = 40 + r() * 80; const m = new THREE.Mesh(new THREE.ConeGeometry(h * 0.8, h, 4), new THREE.MeshStandardMaterial({ color: t.side, roughness: 0.9, flatShading: true })); const a = r() * 6.28, rr = 200 + r() * 200; m.position.set(Math.cos(a) * rr, h / 2 - 45, Math.sin(a) * rr); m.rotation.y = r(); d.add(m); }
        break;
      case "grid": {
        const g = new THREE.GridHelper(1600, 80, t.accent, t.top); g.position.y = -30; (g.material as THREE.Material).transparent = true; (g.material as THREE.Material).opacity = 0.55; d.add(g);
        const s = new THREE.Mesh(new THREE.SphereGeometry(60, 24, 16), new THREE.MeshBasicMaterial({ color: "#ff5ac8", fog: false })); s.position.set(0, 40, -420); d.add(s); break; }
      case "moon": {
        const m = new THREE.Mesh(new THREE.SphereGeometry(55, 32, 20), new THREE.MeshStandardMaterial({ color: "#f2f0ff", emissive: "#aab0ff", emissiveIntensity: 0.55, roughness: 1, fog: false })); m.position.set(-220, 130, -330); d.add(m); break; }
      case "neon":
        for (let i = 0; i < 26; i++) { const h = 40 + r() * 120; const m = new THREE.Mesh(new THREE.BoxGeometry(10 + r() * 14, h, 10 + r() * 14), new THREE.MeshStandardMaterial({ color: "#10103a", emissive: [t.accent, t.alt, t.top][i % 3], emissiveIntensity: 0.55 })); const a = r() * 6.28, rr = 170 + r() * 220; m.position.set(Math.cos(a) * rr, h / 2 - 45, Math.sin(a) * rr); d.add(m); }
        break;
    }
  }
  water: THREE.Mesh | undefined;
  waterY = -26;
  update(cam: THREE.Camera, t: number) {
    this.dome.position.copy(cam.position); this.stars.position.copy(cam.position);
    this.sun.position.copy(cam.position).add(new THREE.Vector3(180, 220, -300));
    this.decor.position.x = cam.position.x * 0.9; this.decor.position.z = cam.position.z * 0.9;
    if (this.water) { this.water.position.x = cam.position.x; this.water.position.z = cam.position.z; this.water.position.y = this.waterY + Math.sin(t * 0.8) * 0.25; }
  }
}

export class Lighting {
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  constructor(scene: THREE.Scene, theme: Theme, env: THREE.Texture) {
    scene.fog = new THREE.FogExp2(theme.fog, theme.fogD);
    scene.environment = env; scene.environmentIntensity = theme.stars ? 0.35 : 0.55;
    this.hemi = new THREE.HemisphereLight(theme.skyMid, theme.stars ? "#3a2a7a" : theme.side, theme.stars ? 0.7 : 0.9); scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(theme.sun, theme.stars ? 2.0 : 2.6);
    this.sun.castShadow = true; this.sun.shadow.mapSize.set(2048, 2048);
    const c = this.sun.shadow.camera; c.left = -26; c.right = 26; c.top = 26; c.bottom = -26; c.near = 1; c.far = 120;
    this.sun.shadow.bias = -0.0004; this.sun.shadow.normalBias = 0.04;
    scene.add(this.sun); scene.add(this.sun.target);
  }
  follow(p: THREE.Vector3) {
    // snap the light to a texel grid to stop shadow shimmer
    const step = 52 / 2048;
    const sx = Math.round(p.x / step) * step, sy = Math.round(p.y / step) * step, sz = Math.round(p.z / step) * step;
    this.sun.target.position.set(sx, sy, sz);
    this.sun.position.set(sx + 34, sy + 52, sz + 22);
  }
}

// ───────── Particles ─────────
export class Particles {
  max = 900;
  pos = new Float32Array(this.max * 3);
  col = new Float32Array(this.max * 3);
  size = new Float32Array(this.max);
  vel = new Float32Array(this.max * 3);
  life = new Float32Array(this.max);
  maxLife = new Float32Array(this.max);
  base = new Float32Array(this.max);
  grav = new Float32Array(this.max);
  head = 0;
  points: THREE.Points;
  constructor(scene: THREE.Scene) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(this.col, 3));
    g.setAttribute("size", new THREE.BufferAttribute(this.size, 1));
    const m = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, vertexColors: true, blending: THREE.NormalBlending,
      uniforms: { scale: { value: 600 }, map: { value: glowTexture("#ffffff") } },
      vertexShader: "attribute float size; varying vec3 vC; uniform float scale; void main(){ vC = color; vec4 mv = modelViewMatrix*vec4(position,1.0); gl_PointSize = size*scale/(-mv.z); gl_Position = projectionMatrix*mv; }",
      fragmentShader: "uniform sampler2D map; varying vec3 vC; void main(){ vec4 t = texture2D(map, gl_PointCoord); if(t.a<0.02) discard; gl_FragColor = vec4(vC, t.a); }",
    });
    this.points = new THREE.Points(g, m); this.points.frustumCulled = false; scene.add(this.points);
  }
  emit(p: THREE.Vector3, color: string, n = 10, speed = 3, life = 0.6, size = 0.25, grav = 6, up = 0.5) {
    const c = new THREE.Color(color);
    for (let k = 0; k < n; k++) {
      const i = this.head; this.head = (this.head + 1) % this.max;
      this.pos.set([p.x, p.y, p.z], i * 3);
      const a = Math.random() * 6.283, e = Math.random() * 2 - 1 + up, s = speed * (0.4 + Math.random() * 0.8);
      this.vel.set([Math.cos(a) * s * (1 - Math.abs(e) * 0.3), e * s, Math.sin(a) * s * (1 - Math.abs(e) * 0.3)], i * 3);
      this.col.set([c.r, c.g, c.b], i * 3);
      this.life[i] = this.maxLife[i] = life * (0.6 + Math.random() * 0.6); this.base[i] = size * (0.6 + Math.random() * 0.8); this.grav[i] = grav;
    }
  }
  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) { this.size[i] = 0; continue; }
      this.life[i] -= dt;
      this.vel[i * 3 + 1] -= this.grav[i] * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      this.size[i] = this.base[i] * Math.max(0, this.life[i] / this.maxLife[i]);
    }
    (this.points.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.points.geometry.attributes.size as THREE.BufferAttribute).needsUpdate = true;
    (this.points.geometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }
}
export { THEMES };
