export type NavKey = "up" | "down" | "left" | "right" | "ok" | "back" | "tri" | "start" | "l1" | "r1";
const navListeners = new Set<(k: NavKey) => void>();
export function onNav(fn: (k: NavKey) => void) { navListeners.add(fn); return () => { navListeners.delete(fn); }; }
function fire(k: NavKey) { navListeners.forEach((f) => f(k)); }

class InputState {
  keys = new Set<string>();
  private edge = new Set<string>();
  pressedNow = new Set<string>();
  mdx = 0; mdy = 0; wheel = 0; dragging = false;
  move = { x: 0, y: 0 };
  cam = { x: 0, y: 0 };
  jump = false; jumpP = false; spinP = false; slamP = false; boost = false; interactP = false; startP = false; callP = false;
  usingPad = false;
  padName = "";
  private prevBtn: boolean[] = [];
  private navHold: Record<string, number> = {};

  attach(el: HTMLElement) {
    window.addEventListener("keydown", (e) => {
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space", "Tab"].includes(e.code)) e.preventDefault();
      if (!e.repeat) { this.edge.add(e.code); this.usingPad = false; }
      this.keys.add(e.code);
      const rep = e.repeat;
      switch (e.code) {
        case "ArrowUp": case "KeyW": fire("up"); break;
        case "ArrowDown": case "KeyS": fire("down"); break;
        case "ArrowLeft": case "KeyA": fire("left"); break;
        case "ArrowRight": case "KeyD": fire("right"); break;
        case "Enter": case "Space": if (!rep) fire("ok"); break;
        case "Escape": case "Backspace": if (!rep) { fire("back"); fire("start"); } break;
        case "KeyE": case "KeyT": if (!rep) fire("tri"); break;
        case "KeyQ": if (!rep) fire("l1"); break;
        case "KeyR": if (!rep) fire("r1"); break;
        case "KeyP": if (!rep) fire("start"); break;
      }
    });
    window.addEventListener("keyup", (e) => this.keys.delete(e.code));
    window.addEventListener("blur", () => this.keys.clear());
    el.addEventListener("pointerdown", (e) => { if (e.button === 0 || e.button === 2) { this.dragging = true; this.edge.add("Mouse" + e.button); } });
    window.addEventListener("pointerup", () => { this.dragging = false; });
    window.addEventListener("pointermove", (e) => { if (this.dragging) { this.mdx += e.movementX; this.mdy += e.movementY; } });
    el.addEventListener("wheel", (e) => { this.wheel += Math.sign(e.deltaY); }, { passive: true });
    el.addEventListener("contextmenu", (e) => e.preventDefault());
  }

  isDown(...c: string[]) { return c.some((k) => this.keys.has(k)); }
  was(...c: string[]) { return c.some((k) => this.pressedNow.has(k)); }

  private pollPad(dt: number) {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const gp = Array.from(pads).find((p) => p && p.connected);
    if (!gp) { this.padName = ""; return null; }
    this.padName = gp.id;
    const dz = (v: number) => (Math.abs(v) < 0.16 ? 0 : v);
    const b = (i: number) => !!gp.buttons[i]?.pressed;
    const edge = (i: number) => b(i) && !this.prevBtn[i];
    const lx = dz(gp.axes[0] ?? 0), ly = dz(gp.axes[1] ?? 0), rx = dz(gp.axes[2] ?? 0), ry = dz(gp.axes[3] ?? 0);
    const any = gp.buttons.some((x) => x.pressed) || lx || ly || rx || ry;
    if (any) this.usingPad = true;
    // menu navigation
    const rep = (name: string, down: boolean, cb: () => void) => {
      if (!down) { this.navHold[name] = 0; return; }
      const t = this.navHold[name] ?? 0;
      if (t === 0) { cb(); this.navHold[name] = 0.001; }
      else { this.navHold[name] = t + dt; if (this.navHold[name] > 0.35) { cb(); this.navHold[name] = 0.28; } }
    };
    rep("up", b(12) || ly < -0.6, () => fire("up")); rep("down", b(13) || ly > 0.6, () => fire("down"));
    rep("left", b(14) || lx < -0.6, () => fire("left")); rep("right", b(15) || lx > 0.6, () => fire("right"));
    if (edge(0)) fire("ok"); if (edge(1)) fire("back"); if (edge(3)) fire("tri"); if (edge(9)) fire("start");
    if (edge(4)) fire("l1"); if (edge(5)) fire("r1");
    const res = {
      lx, ly, rx, ry, jump: b(0), jumpP: edge(0), spinP: edge(2) || edge(5), slamP: edge(1), boost: b(7) || b(6) || (gp.buttons[7]?.value ?? 0) > 0.3, interactP: edge(3), startP: edge(9), callP: edge(3),
    };
    this.prevBtn = gp.buttons.map((x) => x.pressed);
    return res;
  }

  /** call once per frame */
  update(dt: number) {
    this.pressedNow = this.edge; this.edge = new Set();
    const pad = this.pollPad(dt);
    let mx = 0, my = 0;
    if (this.isDown("KeyA")) mx -= 1; if (this.isDown("KeyD")) mx += 1;
    if (this.isDown("KeyW")) my += 1; if (this.isDown("KeyS")) my -= 1;
    if (pad) { if (Math.abs(pad.lx) > 0.01 || Math.abs(pad.ly) > 0.01) { mx = pad.lx; my = -pad.ly; } }
    const l = Math.hypot(mx, my);
    if (l > 1) { mx /= l; my /= l; }
    this.move.x = mx; this.move.y = my;
    let cx = 0, cy = 0;
    if (this.isDown("ArrowLeft")) cx -= 1; if (this.isDown("ArrowRight")) cx += 1;
    if (this.isDown("ArrowUp")) cy -= 1; if (this.isDown("ArrowDown")) cy += 1;
    if (pad) { cx += pad.rx; cy += pad.ry; }
    this.cam.x = cx * 2.2 * dt + this.mdx * 0.0042; this.cam.y = cy * 1.6 * dt + this.mdy * 0.0034;
    this.mdx = 0; this.mdy = 0;
    this.jump = this.isDown("Space") || !!pad?.jump;
    this.jumpP = this.was("Space") || !!pad?.jumpP;
    this.spinP = this.was("KeyJ", "KeyK", "ShiftLeft", "ShiftRight") || !!pad?.spinP;
    this.slamP = this.was("KeyC", "ControlLeft", "KeyL") || !!pad?.slamP;
    this.boost = this.isDown("KeyR", "KeyF", "Mouse2") || !!pad?.boost;
    this.interactP = this.was("KeyE", "KeyT") || !!pad?.interactP;
    this.callP = this.interactP;
    this.startP = this.was("Escape", "KeyP") || !!pad?.startP;
  }
}
export const input = new InputState();
