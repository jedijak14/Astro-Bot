import { useEffect, useState } from "react";
import { useUI, readSlot, deleteSlot, completion, totalBots, totalPuzzles } from "../game/store";
import { engine } from "../game/engine";
import { sfx } from "../game/audio";
import { useNav, PromptBar, RobotIcon, PuzzleIcon, CoinIcon } from "./common";

export function Loading() {
  const ui = useUI();
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center" style={{ background: "radial-gradient(circle at 50% 40%, #12297e 0%, #040724 70%)" }}>
      <div className="relative text-[clamp(40px,7vw,96px)] font-bold logo-text logo-wrap" style={{ animationDuration: "2s" }}>ASTRO BOT</div>
      <div className="mt-10 w-[min(420px,70vw)] meter"><i style={{ width: `${Math.round(ui.loading * 100)}%`, background: "linear-gradient(90deg,#4fb4ff,#fff)" }} /></div>
      <div className="mt-3 text-white/80 text-lg tracking-widest">LOADING ASTRO… {Math.round(ui.loading * 100)}%</div>
    </div>
  );
}

function Logo() {
  return (
    <div className="logo-wrap select-none text-center" style={{ fontSize: "clamp(48px, 10.2vw, 160px)" }}>
      <div className="relative inline-block">
        <div className="logo-text relative" style={{ letterSpacing: "0.03em" }}>
          <span className="absolute inset-0 logo-stroke" aria-hidden>ASTRO</span>
          ASTRO
        </div>
      </div>
      <div className="relative inline-block -mt-[0.02em]" style={{ fontSize: "1.18em", marginLeft: "0.22em" }}>
        <div className="logo-text relative">
          <span className="absolute inset-0 logo-stroke" aria-hidden>BOT</span>
          B<span className="inline-block relative" style={{ width: "0.74em", height: "0.74em", verticalAlign: "-0.04em" }}>
            <span className="absolute inset-0 rounded-full" style={{ background: "radial-gradient(circle at 35% 30%, #fff, #bfe0ff 60%, #6aa8ff)", border: "0.09em solid #1457e8", boxShadow: "0 0 0 0.09em #0b2fa8" }} />
            <span className="absolute rounded-full" style={{ left: "26%", top: "34%", width: "48%", height: "32%", background: "#07123a", boxShadow: "inset 0 0 0.1em #59d4ff" }} />
            <span className="absolute rounded-full" style={{ left: "36%", top: "42%", width: "10%", height: "16%", background: "#59d4ff" }} />
            <span className="absolute rounded-full" style={{ left: "54%", top: "42%", width: "10%", height: "16%", background: "#59d4ff" }} />
          </span>T
        </div>
      </div>
    </div>
  );
}

export function TitleScreen() {
  const [ready, setReady] = useState(false);
  useEffect(() => { const t = setTimeout(() => setReady(true), 400); return () => clearTimeout(t); }, []);
  const go = () => { if (ready) engine.pressStart(); };
  useNav((k) => { if (k !== "up" && k !== "down" && k !== "left" && k !== "right") go(); });
  useEffect(() => {
    const kd = (e: KeyboardEvent) => { if (!e.repeat) go(); };
    window.addEventListener("keydown", kd); window.addEventListener("pointerdown", go);
    return () => { window.removeEventListener("keydown", kd); window.removeEventListener("pointerdown", go); };
  });
  return (
    <div className="fixed inset-0 z-20 flex flex-col items-center justify-between py-[5vh] cursor-pointer" style={{ background: "linear-gradient(180deg, rgba(2,5,40,0.55) 0%, rgba(2,5,40,0) 35%, rgba(2,5,40,0) 65%, rgba(2,5,40,0.8) 100%)" }}>
      <div className="mt-[3vh]"><Logo /></div>
      <div className="flex flex-col items-center gap-4">
        <div className="press-blink text-white title-shadow font-semibold tracking-[0.25em] text-[clamp(18px,2.4vw,36px)]">PRESS ANY BUTTON</div>
        <div className="text-white/60 text-[clamp(11px,1vw,14px)] tracking-widest">TEAM ASOBI  •  A FAN-MADE WEB TRIBUTE  •  PLAYSTATION®5 STYLE</div>
      </div>
    </div>
  );
}

export function SlotScreen() {
  useUI();
  const [sel, setSel] = useState(0);
  const [confirm, setConfirm] = useState<number | null>(null);
  useNav((k) => {
    if (confirm !== null) { if (k === "ok") { deleteSlot(confirm + 1); setConfirm(null); sfx("hit"); } else if (k === "back" || k === "tri") { setConfirm(null); sfx("back"); } return; }
    if (k === "left") { setSel((s) => (s + 2) % 3); sfx("move"); }
    if (k === "right") { setSel((s) => (s + 1) % 3); sfx("move"); }
    if (k === "ok") engine.selectSlot(sel + 1);
    if (k === "tri" && readSlot(sel + 1)) { setConfirm(sel); sfx("ok"); }
    if (k === "back") { sfx("back"); engine.backToTitle(); }
  });
  return (
    <div className="fixed inset-0 z-20 flex flex-col items-center justify-between py-[5vh]" style={{ background: "linear-gradient(180deg, rgba(2,5,40,0.7), rgba(2,5,40,0.25) 40%, rgba(2,5,40,0.8))" }}>
      <div className="text-white title-shadow font-bold tracking-[0.2em] text-[clamp(26px,3.6vw,54px)]">SELECT SAVE DATA</div>
      <div className="flex gap-[2.4vw] items-stretch">
        {[0, 1, 2].map((i) => {
          const d = readSlot(i + 1); const isSel = sel === i;
          return (
            <div key={i} onMouseEnter={() => setSel(i)} onClick={() => { setSel(i); engine.selectSlot(i + 1); }}
              className="ps-panel cursor-pointer px-[1.6vw] py-[2.2vh] w-[min(26vw,340px)] min-w-[220px] transition-all duration-200"
              style={{ transform: isSel ? "scale(1.07) translateY(-8px)" : "scale(0.95)", borderColor: isSel ? "#fff" : undefined, boxShadow: isSel ? "0 0 50px rgba(110,180,255,0.9), 0 12px 40px rgba(0,0,0,0.5)" : undefined, opacity: isSel ? 1 : 0.8 }}>
              <div className="flex items-center justify-between">
                <div className="text-[clamp(18px,1.8vw,28px)] font-bold">SLOT {i + 1}</div>
                {d && <div className="text-[clamp(12px,1vw,16px)] px-3 py-1 rounded-full bg-white text-[#0b2a8a] font-bold">{completion(d)}%</div>}
              </div>
              <div className="my-4 h-[18vh] min-h-[110px] rounded-2xl flex items-center justify-center" style={{ background: "radial-gradient(circle at 50% 40%, #2a58d8, #0a1a5a)" }}>
                {d ? (
                  <div className="text-center">
                    <div className="text-6xl" style={{ animation: "floaty 2.4s ease-in-out infinite" }}>🤖</div>
                    <div className="mt-2 text-white/90 text-sm">{Object.keys(d.cleared).length} planets cleared</div>
                  </div>
                ) : <div className="text-center"><div className="text-5xl opacity-90" style={{ animation: "floaty 2.4s ease-in-out infinite" }}>✨</div><div className="mt-2 text-lg font-semibold">NEW GAME</div></div>}
              </div>
              {d ? (
                <div className="flex justify-between items-center text-[clamp(14px,1.3vw,20px)]">
                  <span className="flex items-center gap-1"><RobotIcon size={24} />{totalBots(d)}</span>
                  <span className="flex items-center gap-1"><PuzzleIcon size={24} />{totalPuzzles(d)}</span>
                  <span className="flex items-center gap-1"><CoinIcon size={24} />{d.coins}</span>
                </div>
              ) : <div className="text-center text-white/70 text-sm">Empty</div>}
            </div>
          );
        })}
      </div>
      <div className="flex flex-col items-center gap-3">
        <PromptBar items={[{ g: "x", label: "Select" }, { g: "o", label: "Back" }, { g: "t", label: "Delete Data" }]} />
      </div>
      {confirm !== null && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/60">
          <div className="ps-panel p-8 text-center pop-in">
            <div className="text-3xl font-bold mb-2">Delete Slot {confirm + 1}?</div>
            <div className="text-white/80 mb-6">This cannot be undone.</div>
            <PromptBar items={[{ g: "x", label: "Delete" }, { g: "o", label: "Cancel" }]} />
          </div>
        </div>
      )}
    </div>
  );
}
