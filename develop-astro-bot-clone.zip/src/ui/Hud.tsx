import { useEffect, useMemo, useState } from "react";
import { useUI, ui, patchSettings, totalBots, totalPuzzles } from "../game/store";
import { planetById, galaxyById, GALAXIES, VIP_BOTS } from "../game/data";
import { engine } from "../game/engine";
import { applyVolumes, sfx } from "../game/audio";
import { useNav, Glyph, PromptBar, RobotIcon, PuzzleIcon, CoinIcon, fmtTime } from "./common";

const GADGETS: Record<string, { name: string; icon: string; color: string; hint: string }> = {
  frog: { name: "FROG SUIT", icon: "🐸", color: "#4ad65a", hint: "Super jump" },
  rocket: { name: "ROCKET BOOST", icon: "🚀", color: "#ff5a3c", hint: "Hold R / R2" },
  monkey: { name: "MONKEY CLIMBERS", icon: "🐵", color: "#c98a4a", hint: "Climb green walls" },
  gloves: { name: "BOXING GLOVES", icon: "🥊", color: "#ff3a4a", hint: "Long-range spin" },
};

export function Fade() { const ui2 = useUI(); return <div className="fade-layer" style={{ opacity: ui2.fade ? 1 : 0 }} />; }

export function LevelHud() {
  const s = useUI();
  const pl = s.planetId ? planetById(s.planetId) : null;
  const g = s.gadget !== "none" ? GADGETS[s.gadget] : null;
  const found = s.runBots.filter(Boolean).length;
  const key = s.coinPulse;
  return (
    <div className="fixed inset-0 z-10 pointer-events-none">
      {/* top-left: bots & puzzle pieces */}
      {pl && pl.kind !== "boss" && (
        <div className="absolute left-[2vw] top-[3vh] flex flex-col gap-2 items-start">
          {s.runBots.length > 0 && (
            <div className="ps-pill px-4 py-1.5 flex items-center gap-1.5">
              {s.runBots.map((b, i) => <RobotIcon key={i} on={b} size={Math.max(20, 28 - s.runBots.length)} />)}
              <span className="ml-1.5 text-[clamp(14px,1.4vw,20px)] font-bold">{found}/{s.runBots.length}</span>
            </div>
          )}
          {s.runPuzzles.length > 0 && (
            <div className="ps-pill px-4 py-1.5 flex items-center gap-1.5">
              {s.runPuzzles.map((b, i) => <PuzzleIcon key={i} on={b} size={26} color={["#43b0ff", "#ff6fa8", "#7aff7a", "#ffd23c"][i % 4]} />)}
            </div>
          )}
        </div>
      )}
      {/* top-right: coins */}
      <div className="absolute right-[2vw] top-[3vh]">
        <div key={key} className="ps-pill px-5 py-1.5 flex items-center gap-2" style={{ animation: key ? "coinPulse 0.25s ease-out" : undefined }}>
          <CoinIcon size={34} /><span className="text-[clamp(22px,2.4vw,36px)] font-bold tabular-nums title-shadow">{s.runCoins}</span>
        </div>
        {pl && <div className="mt-2 text-right text-white/90 title-shadow font-semibold tabular-nums text-[clamp(13px,1.2vw,18px)]">⏱ {fmtTime(s.time)}{pl.timer ? `  / PAR ${fmtTime(pl.timer)}` : ""}</div>}
      </div>
      {/* gauges bottom-left */}
      <div className="absolute left-[2vw] bottom-[4vh] w-[min(240px,32vw)] flex flex-col gap-2">
        {g && (
          <div className="ps-pill px-4 py-1.5 flex items-center gap-2 self-start pop-in" style={{ borderColor: g.color }}>
            <span className="text-2xl">{g.icon}</span><div className="leading-tight"><div className="font-bold text-sm">{g.name}</div><div className="text-xs text-white/80">{g.hint}</div></div>
          </div>
        )}
        <div className="flex items-center gap-2"><span className="text-xs font-bold w-12 text-white/90">HOVER</span><div className="meter flex-1"><i style={{ width: `${s.hover * 100}%`, background: "linear-gradient(90deg,#4fb4ff,#9ae8ff)" }} /></div></div>
        {s.gadget === "rocket" && <div className="flex items-center gap-2"><span className="text-xs font-bold w-12 text-white/90">BOOST</span><div className="meter flex-1"><i style={{ width: `${s.boost * 100}%`, background: "linear-gradient(90deg,#ff7a3c,#ffd23c)" }} /></div></div>}
      </div>
      {s.bossName && s.bossMax > 0 && <BossBar name={s.bossName} hp={s.bossHp} max={s.bossMax} />}
      {s.banner && <Banner title={s.banner.title} sub={s.banner.sub} key={s.banner.t} />}
      {s.hint && <div className="absolute bottom-[12vh] left-1/2 -translate-x-1/2 ps-pill px-6 py-2 text-center text-[clamp(12px,1.2vw,18px)] max-w-[80vw] pop-in">{s.hint}</div>}
      {s.toast && <Toast text={s.toast.text} key={s.toast.t} />}
      <div className="absolute right-[2vw] bottom-[3vh] text-white/70 text-xs title-shadow text-right leading-5">
        <div><b>WASD</b> move • <b>Space</b> jump/hover • <b>J</b> spin • <b>C</b> slam{s.gadget === "rocket" ? " • R boost" : ""}</div>
        <div><b>Mouse drag / Arrows</b> camera • <b>Esc</b> pause</div>
      </div>
    </div>
  );
}

function Banner({ title, sub }: { title: string; sub: string }) {
  return (
    <div className="absolute left-0 top-[26vh]" style={{ animation: "bannerIn 3.4s ease-out forwards" }}>
      <div className="pl-[4vw] pr-[6vw] py-3 rounded-r-[3rem]" style={{ background: "linear-gradient(90deg, rgba(10,30,130,0.92), rgba(30,90,230,0.82) 80%, rgba(30,90,230,0))" }}>
        <div className="text-white/80 tracking-[0.3em] text-[clamp(11px,1.1vw,16px)] font-semibold uppercase">{sub}</div>
        <div className="text-white font-bold title-shadow uppercase text-[clamp(28px,4.4vw,68px)] leading-none">{title}</div>
      </div>
    </div>
  );
}
function Toast({ text }: { text: string }) {
  return <div className="absolute top-[11vh] left-1/2 -translate-x-1/2 name-plate px-7 py-2 font-bold text-[clamp(14px,1.6vw,24px)]" style={{ animation: "slideDown 3s ease-out forwards" }}>{text}</div>;
}
function BossBar({ name, hp, max }: { name: string; hp: number; max: number }) {
  return (
    <div className="absolute top-[3vh] left-1/2 -translate-x-1/2 w-[min(560px,48vw)] text-center">
      <div className="font-bold tracking-[0.25em] title-shadow text-[clamp(14px,1.5vw,22px)] mb-1">{name}</div>
      <div className="flex gap-2 justify-center">{Array.from({ length: max }).map((_, i) => <div key={i} className="h-5 flex-1 rounded-full border-2 border-white" style={{ background: i < hp ? "linear-gradient(180deg,#ff8a9a,#ff2a4a)" : "rgba(0,0,0,0.5)", boxShadow: i < hp ? "0 0 14px rgba(255,60,90,0.9)" : "none", transition: "all 0.3s" }} />)}</div>
    </div>
  );
}

export function HubHud() {
  const s = useUI();
  const coins = s.save?.coins ?? 0;
  return (
    <div className="fixed inset-0 z-10 pointer-events-none">
      <div className="absolute left-[2vw] top-[3vh] flex flex-col gap-2 items-start">
        <div className="ps-pill px-4 py-1.5 flex items-center gap-2 text-[clamp(16px,1.6vw,24px)] font-bold"><RobotIcon size={30} />{totalBots()}</div>
        <div className="ps-pill px-4 py-1.5 flex items-center gap-2 text-[clamp(16px,1.6vw,24px)] font-bold"><PuzzleIcon size={30} />{totalPuzzles()}</div>
      </div>
      <div className="absolute right-[2vw] top-[3vh] ps-pill px-5 py-1.5 flex items-center gap-2"><CoinIcon size={34} /><span className="text-[clamp(22px,2.4vw,36px)] font-bold tabular-nums title-shadow">{coins}</span></div>
      {s.banner && <Banner title={s.banner.title} sub={s.banner.sub} key={s.banner.t} />}
      {s.prompt && <div className="absolute bottom-[14vh] left-1/2 -translate-x-1/2 name-plate px-8 py-2 font-bold text-[clamp(16px,1.9vw,28px)] pop-in" key={s.prompt}>{s.prompt.replace("△  ", "")} <span className="ml-3 inline-block align-middle text-[#0b8a4a]">[E] △</span></div>}
      {s.hint && <div className="absolute bottom-[4vh] left-1/2 -translate-x-1/2 ps-pill px-6 py-2 text-center text-[clamp(12px,1.2vw,18px)] max-w-[84vw]">{s.hint}</div>}
      {s.toast && <Toast text={s.toast.text} key={s.toast.t} />}
      <div className="absolute right-[2vw] bottom-[3vh] text-white/80 text-sm title-shadow text-right leading-6">
        <div><b>B</b> Bot Collection • <b>Esc</b> Pause</div>
        <div>Follow the glowing pad to the <b>Galaxy Map</b></div>
      </div>
    </div>
  );
}

// ───── Options ─────
export function OptionsPanel({ onBack }: { onBack: () => void }) {
  const s = useUI();
  const [i, setI] = useState(0);
  const items = ["music", "sfx", "unlock", "shadows", "bloom", "invert", "back"] as const;
  useNav((k) => {
    const it = items[i];
    if (k === "up") { setI((v) => (v + items.length - 1) % items.length); sfx("move"); }
    if (k === "down") { setI((v) => (v + 1) % items.length); sfx("move"); }
    const adj = k === "left" ? -0.1 : k === "right" ? 0.1 : 0;
    if (adj && (it === "music" || it === "sfx")) { patchSettings({ [it]: Math.min(1, Math.max(0, +(s.settings[it] + adj).toFixed(2))) } as never); applyVolumes(); sfx("move"); }
    if (k === "ok") { sfx("ok"); if (it === "unlock") patchSettings({ unlockAll: !s.settings.unlockAll }); else if (it === "shadows") patchSettings({ shadows: !s.settings.shadows }); else if (it === "bloom") patchSettings({ bloom: !s.settings.bloom }); else if (it === "invert") patchSettings({ invertY: !s.settings.invertY }); else if (it === "back") onBack(); }
    if (k === "back") onBack();
  });
  const Row = ({ idx, label, children }: { idx: number; label: string; children: React.ReactNode }) => (
    <div onMouseEnter={() => setI(idx)} className={`menu-item flex items-center justify-between gap-6 px-6 py-3 rounded-2xl text-[clamp(16px,1.6vw,24px)] font-semibold ${i === idx ? "sel" : ""}`}>{<span>{label}</span>}{children}</div>
  );
  const Toggle = ({ on, onClick }: { on: boolean; onClick: () => void }) => <button onClick={onClick} className="w-16 h-8 rounded-full relative border-2 border-white/80 pointer-events-auto" style={{ background: on ? "#3a8aff" : "#2a3260" }}><span className="absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all" style={{ left: on ? "2.1rem" : "0.15rem" }} /></button>;
  const Slider = ({ v, k }: { v: number; k: "music" | "sfx" }) => <input className="w-44 pointer-events-auto" type="range" min={0} max={1} step={0.05} value={v} onChange={(e) => { patchSettings({ [k]: +e.target.value } as never); applyVolumes(); }} />;
  return (
    <div className="flex flex-col gap-2 w-[min(560px,90vw)]">
      <Row idx={0} label="Music Volume"><Slider v={s.settings.music} k="music" /></Row>
      <Row idx={1} label="Sound Effects"><Slider v={s.settings.sfx} k="sfx" /></Row>
      <Row idx={2} label="Unlock All Planets"><Toggle on={s.settings.unlockAll} onClick={() => patchSettings({ unlockAll: !s.settings.unlockAll })} /></Row>
      <Row idx={3} label="Shadows"><Toggle on={s.settings.shadows} onClick={() => patchSettings({ shadows: !s.settings.shadows })} /></Row>
      <Row idx={4} label="Bloom Glow"><Toggle on={s.settings.bloom} onClick={() => patchSettings({ bloom: !s.settings.bloom })} /></Row>
      <Row idx={5} label="Invert Camera Y"><Toggle on={s.settings.invertY} onClick={() => patchSettings({ invertY: !s.settings.invertY })} /></Row>
      <div onClick={onBack} className={`menu-item text-center px-6 py-3 rounded-2xl text-[clamp(16px,1.6vw,24px)] font-semibold cursor-pointer ${i === 6 ? "sel" : ""}`}>Back</div>
    </div>
  );
}

function Controls({ onBack }: { onBack: () => void }) {
  useNav((k) => { if (k === "ok" || k === "back") onBack(); });
  const rows: [string, string, string][] = [["Move", "W A S D", "Left Stick"], ["Camera", "Mouse Drag / Arrow Keys", "Right Stick"], ["Jump (hold to hover)", "Space", "✕"], ["Spin Attack", "J / K / Shift", "□ / R1"], ["Ground Slam", "C / Ctrl (in air)", "○"], ["Rocket Boost / Speeder Boost", "R / F / Right Mouse", "R2"], ["Interact / Call", "E", "△"], ["Pause", "Esc / P", "Options"], ["Bot Collection (Crash Site)", "B", "—"]];
  return (
    <div className="ps-panel p-6 w-[min(680px,92vw)]">
      <div className="grid grid-cols-[1.4fr_1.2fr_1fr] gap-x-4 gap-y-2 text-[clamp(13px,1.3vw,19px)]">
        <b className="text-white/60">ACTION</b><b className="text-white/60">KEYBOARD</b><b className="text-white/60">DUALSENSE</b>
        {rows.map((r, i) => <><span key={"a" + i} className="font-semibold">{r[0]}</span><span key={"b" + i} className="text-sky-200">{r[1]}</span><span key={"c" + i} className="text-pink-200">{r[2]}</span></>)}
      </div>
      <div className="mt-5 flex justify-center"><PromptBar items={[{ g: "x", label: "Back" }]} /></div>
    </div>
  );
}

export function PauseMenu() {
  const s = useUI();
  const [i, setI] = useState(0);
  const inLevel = engine.mode === "level";
  const items = useMemo(() => [
    { id: "resume", label: "Resume" },
    ...(inLevel ? [{ id: "restart", label: "Restart Planet" }] : []),
    { id: "controls", label: "Controls" },
    { id: "options", label: "Options" },
    ...(inLevel ? [{ id: "quit", label: "Return to Galaxy Map" }] : [{ id: "title", label: "Back to Title" }]),
  ], [inLevel]);
  const act = (id: string) => {
    sfx("ok");
    if (id === "resume") engine.pause(false); else if (id === "restart") engine.restartLevel(); else if (id === "controls") ui.pauseTab = "controls";
    else if (id === "options") ui.pauseTab = "options"; else if (id === "quit") engine.quitLevel(); else if (id === "title") { engine.pause(false); engine.backToTitle(); }
    if (id === "controls" || id === "options") patchSettings({});
  };
  useNav((k) => {
    if (s.pauseTab !== "main") return;
    if (k === "up") { setI((v) => (v + items.length - 1) % items.length); sfx("move"); }
    if (k === "down") { setI((v) => (v + 1) % items.length); sfx("move"); }
    if (k === "ok") act(items[i].id);
    if (k === "back" || k === "start") engine.pause(false);
  });
  const pl = s.planetId && inLevel ? planetById(s.planetId) : null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(4,10,60,0.55), rgba(2,4,30,0.88))", backdropFilter: "blur(5px)" }}>
      <div className="flex flex-col items-center gap-4 pop-in">
        <div className="text-[clamp(30px,4vw,64px)] font-bold title-shadow tracking-[0.18em]">{s.pauseTab === "main" ? "PAUSED" : s.pauseTab === "controls" ? "CONTROLS" : "OPTIONS"}</div>
        {pl && s.pauseTab === "main" && <div className="text-white/80 tracking-widest -mt-2">{pl.name.toUpperCase()}</div>}
        {s.pauseTab === "main" && (
          <div className="ps-panel p-4 flex flex-col gap-2 w-[min(440px,86vw)]">
            {items.map((it, idx) => (
              <div key={it.id} onMouseEnter={() => setI(idx)} onClick={() => act(it.id)} className={`menu-item cursor-pointer text-center px-6 py-3 rounded-2xl font-bold text-[clamp(18px,1.9vw,28px)] ${i === idx ? "sel" : ""}`}>{it.label}</div>
            ))}
          </div>
        )}
        {s.pauseTab === "controls" && <Controls onBack={() => { sfx("back"); ui.pauseTab = "main"; patchSettings({}); }} />}
        {s.pauseTab === "options" && <div className="ps-panel p-4"><OptionsPanel onBack={() => { sfx("back"); ui.pauseTab = "main"; patchSettings({}); }} /></div>}
        {s.pauseTab === "main" && <PromptBar items={[{ g: "x", label: "Select" }, { g: "o", label: "Resume" }]} />}
      </div>
    </div>
  );
}

// ───── Results ─────
export function Results() {
  const s = useUI(); const r = s.results!; const pl = planetById(r.planetId);
  const [step, setStep] = useState(0);
  useEffect(() => { const ts = [300, 700, 1100, 1500, 1900].map((d, i) => setTimeout(() => { setStep(i + 1); sfx("coin"); }, d)); return () => ts.forEach(clearTimeout); }, []);
  useNav((k) => { if (k === "ok" && step >= 3) engine.closeResults(); });
  const conf = useMemo(() => Array.from({ length: 70 }, (_, i) => ({ l: Math.random() * 100, d: Math.random() * 3, t: 2.5 + Math.random() * 3, c: ["#ffd23c", "#ff6fa8", "#4fd8ff", "#7aff7a", "#fff", "#c07aff"][i % 6], s: 6 + Math.random() * 8 })), []);
  const rank = pl.timer ? (r.time <= pl.timer ? "S" : r.time <= pl.timer * 1.25 ? "A" : r.time <= pl.timer * 1.6 ? "B" : "C") : null;
  const vip = r.vip ? VIP_BOTS[r.vip] : null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(10,40,160,0.55), rgba(2,6,40,0.9))", backdropFilter: "blur(4px)" }}>
      {conf.map((c, i) => <i key={i} className="fixed top-0 rounded-sm" style={{ left: `${c.l}%`, width: c.s, height: c.s * 0.5, background: c.c, animation: `confetti ${c.t}s linear ${c.d}s infinite` }} />)}
      <div className="flex flex-col items-center gap-5 pop-in z-10">
        <div className="text-white/80 tracking-[0.4em] font-semibold">{galaxyById(pl.galaxy).name.toUpperCase()}</div>
        <div className="font-bold title-shadow text-center uppercase text-[clamp(32px,5.6vw,88px)] leading-none">{pl.kind === "boss" ? "Boss Defeated!" : "Planet Cleared!"}</div>
        <div className="name-plate px-8 py-1 font-bold text-[clamp(18px,2.2vw,34px)]">{pl.name}</div>
        <div className="ps-panel px-8 py-5 w-[min(560px,92vw)] flex flex-col gap-3 text-[clamp(16px,1.7vw,26px)]">
          {pl.bots > 0 && step >= 1 && <div className="flex items-center justify-between pop-in"><span className="font-semibold">Bots Rescued</span><span className="flex items-center gap-1">{Array.from({ length: r.botsTotal }).map((_, i) => <RobotIcon key={i} on={i < r.bots} size={24} />)}<b className="ml-2">{r.bots}/{r.botsTotal}</b></span></div>}
          {pl.puzzle > 0 && step >= 2 && <div className="flex items-center justify-between pop-in"><span className="font-semibold">Puzzle Pieces</span><span className="flex items-center gap-1">{Array.from({ length: r.puzzleTotal }).map((_, i) => <PuzzleIcon key={i} on={i < r.puzzles} size={26} />)}<b className="ml-2">{r.puzzles}/{r.puzzleTotal}</b></span></div>}
          {step >= 3 && <div className="flex items-center justify-between pop-in"><span className="font-semibold">Coins</span><span className="flex items-center gap-2"><CoinIcon size={30} /><b>{r.coins}</b></span></div>}
          {step >= 3 && <div className="flex items-center justify-between pop-in"><span className="font-semibold">Time</span><span className="flex items-center gap-3 tabular-nums"><b>{fmtTime(r.time)}</b>{r.newBest && <span className="px-3 py-0.5 rounded-full bg-yellow-300 text-[#7a4a00] text-sm font-bold">NEW BEST!</span>}{rank && <span className="w-10 h-10 rounded-full bg-white text-[#0b2a8a] flex items-center justify-center font-bold text-2xl">{rank}</span>}</span></div>}
        </div>
        {vip && step >= 4 && <div className="ps-panel px-6 py-3 flex items-center gap-4 pop-in" style={{ borderColor: "#ffd23c" }}><span className="text-4xl">🎖️</span><div><div className="text-yellow-300 font-bold tracking-widest text-sm">VIP BOT RESCUED</div><div className="text-[clamp(18px,2vw,30px)] font-bold">{r.vip}</div><div className="text-white/70 text-sm">{vip.note}</div></div></div>}
        {r.vortex && step >= 4 && <div className="ps-panel px-6 py-2 pop-in" style={{ borderColor: "#ffd23c" }}>🌀 <b>Vortex portal found!</b> New Lost Galaxy planets unlocked.</div>}
        {step >= 3 && <div className="press-blink mt-2"><PromptBar items={[{ g: "x", label: "Continue" }]} /></div>}
        {step >= 3 && <button className="pointer-events-auto name-plate px-10 py-2 font-bold text-xl" onClick={() => engine.closeResults()}>Continue</button>}
      </div>
    </div>
  );
}

// ───── Credits ─────
export function Credits() {
  useNav((k) => { if (k === "ok" || k === "back" || k === "start") engine.closeCredits(); });
  const lines: [string, string][] = [["", "ASTRO BOT"], ["", "A FAN-MADE WEB TRIBUTE"], ["Game Design", "Inspired by Team Asobi"], ["Engine", "three.js • React • Vite • Tailwind"], ["Rigged & Animated Models", "RobotExpressive by Tomás Laulhé (CC0)"], ["", "Fox, Parrot, Flamingo, Stork, Horse, Xbot"], ["", "three.js & Khronos glTF sample assets"], ["Typeface", "Fredoka (SIL OFL)"], ["Galaxies", GALAXIES.map((g) => g.name).join(" • ")], ["Special Thanks", "Every bot you rescued"], ["", "THANK YOU FOR PLAYING!"]];
  return (
    <div className="fixed inset-0 z-50 overflow-hidden" style={{ background: "radial-gradient(circle at 50% 30%, #1a3aa0 0%, #02030f 75%)" }}>
      <div className="absolute inset-x-0 text-center flex flex-col gap-10" style={{ animation: "creditScroll 38s linear forwards" }}>
        {lines.map((l, i) => <div key={i}>{l[0] && <div className="text-sky-300 tracking-[0.4em] text-lg uppercase">{l[0]}</div>}<div className={`font-bold title-shadow ${l[0] ? "text-3xl" : "text-5xl logo-text"}`}>{l[1]}</div></div>)}
      </div>
      <div className="absolute bottom-6 inset-x-0 flex justify-center"><PromptBar items={[{ g: "x", label: "Skip" }]} /></div>
    </div>
  );
}
export { Glyph };
