import { useState } from "react";
import { useUI, galaxyUnlocked, galaxyProgress, botsIn, puzzlesIn, planetLock, totalBots, totalPuzzles, ui, addToast } from "../game/store";
import { GALAXIES, PLANETS, planetById, galaxyById, botDef, VIP_BOTS, GATCHA_ITEMS, OUTFITS, SPEEDER_COLORS, HUB_UNLOCKS } from "../game/data";
import { engine } from "../game/engine";
import { sfx } from "../game/audio";
import { useNav, PromptBar, RobotIcon, PuzzleIcon, CoinIcon, fmtTime } from "./common";

const KIND_LABEL: Record<string, string> = { boss: "BOSS", vip: "VIP BOT", extra: "SECRET", lost: "LOST GALAXY", final: "FINALE", credits: "VICTORY LAP", speed: "SPEEDRUN", void: "CHALLENGE", main: "" };
function galaxyLockText(id: string) {
  const idx = ["gorilla", "tentacle", "serpent", "camo", "feather"].indexOf(id);
  if (idx > 0) { const prev = galaxyById(["gorilla", "tentacle", "serpent", "camo", "feather"][idx - 1]); return `Defeat the boss of ${prev.name}`; }
  if (id === "lost") return "Find a hidden Vortex portal"; if (id === "dejavu") return "Defeat all 5 galaxy bosses"; return "Defeat Space Bully Nebulax";
}

export function GalaxySelect() {
  const s = useUI();
  const [sel, setSel] = useState(engine.map?.selected ?? 0);
  const go = (i: number) => { const n = (i + GALAXIES.length) % GALAXIES.length; setSel(n); engine.selectGalaxyIndex(n); sfx("move"); };
  const enter = () => { const g = GALAXIES[sel]; if (!galaxyUnlocked(g.id)) { sfx("back"); addToast(galaxyLockText(g.id)); return; } sfx("ok"); engine.chooseGalaxy(g.id); };
  useNav((k) => { if (k === "left") go(sel - 1); if (k === "right") go(sel + 1); if (k === "ok") enter(); if (k === "back") { sfx("back"); engine.backFromMap(); } });
  const g = GALAXIES[sel]; const unlocked = galaxyUnlocked(g.id); const pr = galaxyProgress(g.id);
  const bots = g.planets.reduce((a, id) => a + botsIn(id), 0); const botTot = g.planets.reduce((a, id) => a + planetById(id).bots, 0);
  const pz = g.planets.reduce((a, id) => a + puzzlesIn(id), 0); const pzTot = g.planets.reduce((a, id) => a + planetById(id).puzzle, 0);
  return (
    <div className="fixed inset-0 z-10 pointer-events-none">
      <div className="absolute top-[3vh] left-1/2 -translate-x-1/2 text-center">
        <div className="tracking-[0.4em] text-white/80 font-semibold text-[clamp(12px,1.2vw,18px)]">GALAXY MAP</div>
        <div className="font-bold title-shadow text-[clamp(18px,2vw,30px)]">Choose your destination</div>
      </div>
      <div className="absolute right-[2vw] top-[3vh] ps-pill px-5 py-1.5 flex items-center gap-2"><CoinIcon size={30} /><b className="text-2xl tabular-nums">{s.save?.coins ?? 0}</b></div>
      <div className="absolute left-[2vw] top-[3vh] flex flex-col gap-2"><div className="ps-pill px-4 py-1.5 flex items-center gap-2 font-bold text-xl"><RobotIcon size={28} />{totalBots()}</div><div className="ps-pill px-4 py-1.5 flex items-center gap-2 font-bold text-xl"><PuzzleIcon size={28} />{totalPuzzles()}</div></div>
      {/* name */}
      <div className="absolute bottom-[19vh] left-1/2 -translate-x-1/2 text-center w-[min(900px,94vw)]">
        <div key={g.id} className="pop-in">
          <div className="text-white/80 tracking-[0.35em] text-[clamp(11px,1.1vw,16px)] font-semibold">{g.creature.toUpperCase()} • {pr.done}/{pr.total} PLANETS CLEARED</div>
          <div className="font-bold uppercase title-shadow text-[clamp(34px,6vw,92px)] leading-none" style={{ color: unlocked ? "#fff" : "#9aa4c0" }}>{g.name}</div>
          {unlocked ? (
            <div className="mt-2 flex items-center justify-center gap-6 text-[clamp(14px,1.5vw,22px)] font-semibold"><span className="flex items-center gap-2"><RobotIcon size={26} />{bots}/{botTot}</span><span className="flex items-center gap-2"><PuzzleIcon size={26} />{pz}/{pzTot}</span></div>
          ) : <div className="mt-2 inline-block name-plate px-6 py-1 font-bold text-[clamp(14px,1.5vw,22px)]">🔒 {galaxyLockText(g.id)}</div>}
        </div>
      </div>
      {/* ribbon */}
      <div className="absolute bottom-[8vh] left-1/2 -translate-x-1/2 flex gap-2 pointer-events-auto">
        {GALAXIES.map((q, i) => (
          <div key={q.id} onClick={() => { go(i); }} onDoubleClick={enter} className="cursor-pointer flex items-center justify-center rounded-full transition-all" style={{ width: sel === i ? 62 : 46, height: sel === i ? 62 : 46, background: galaxyUnlocked(q.id) ? `linear-gradient(135deg, ${q.color}, ${q.color2})` : "#3a4060", border: `3px solid ${sel === i ? "#fff" : "rgba(255,255,255,0.4)"}`, boxShadow: sel === i ? `0 0 26px ${q.color}` : "none", fontSize: sel === i ? 30 : 22, opacity: galaxyUnlocked(q.id) ? 1 : 0.6 }}>{galaxyUnlocked(q.id) ? q.icon : "🔒"}</div>
        ))}
      </div>
      <div className="absolute bottom-[2.5vh] left-1/2 -translate-x-1/2"><PromptBar items={[{ text: "◀ ▶", label: "Choose" }, { g: "x", label: "Enter Galaxy" }, { g: "o", label: "Crash Site" }]} /></div>
      <button className="pointer-events-auto absolute bottom-[2.5vh] right-[2vw] name-plate px-6 py-1.5 font-bold text-lg" onClick={enter}>Enter Galaxy</button>
      {s.toast && <div key={s.toast.t} className="absolute top-[12vh] left-1/2 -translate-x-1/2 name-plate px-7 py-2 font-bold text-[clamp(14px,1.6vw,24px)]" style={{ animation: "slideDown 3s ease-out forwards" }}>{s.toast.text}</div>}
    </div>
  );
}

export function FlightHud() {
  const s = useUI();
  const g = galaxyById(s.mapGalaxy);
  const pl = s.mapNear ? planetById(s.mapNear) : null;
  const lock = pl ? planetLock(pl.id) : null; const done = pl ? s.save?.cleared[pl.id] : null;
  useNav((k) => { if (k === "back") { sfx("back"); engine.backFromMap(); } });
  const pr = galaxyProgress(g.id);
  return (
    <div className="fixed inset-0 z-10 pointer-events-none">
      <div className="absolute left-[2vw] top-[3vh] flex flex-col gap-2">
        <div className="ps-pill px-5 py-1.5 flex items-center gap-3"><span className="text-2xl">{g.icon}</span><span className="font-bold tracking-widest uppercase text-[clamp(13px,1.3vw,20px)]">{g.name}</span><span className="text-white/70 text-sm">{pr.done}/{pr.total}</span></div>
      </div>
      <div className="absolute right-[2vw] top-[3vh] ps-pill px-5 py-1.5 flex items-center gap-2"><CoinIcon size={30} /><b className="text-2xl tabular-nums">{s.save?.coins ?? 0}</b></div>
      {pl && (
        <div className="absolute top-[3vh] left-1/2 -translate-x-1/2 text-center" key={pl.id}>
          <div className="pop-in flex flex-col items-center gap-2">
            {KIND_LABEL[pl.kind] && <div className="px-4 py-0.5 rounded-full text-xs font-bold tracking-[0.3em]" style={{ background: pl.kind === "boss" ? "#ff3a5a" : "#ffd23c", color: pl.kind === "boss" ? "#fff" : "#4a2a00" }}>{KIND_LABEL[pl.kind]}</div>}
            <div className="name-plate px-10 py-1.5 font-bold uppercase text-[clamp(22px,3vw,46px)] leading-tight">{pl.name}</div>
            {pl.bots > 0 && <div className="ps-pill px-4 py-1.5 flex items-center gap-1.5">{Array.from({ length: pl.bots }).map((_, i) => <RobotIcon key={i} on={!!s.save?.bots[pl.id]?.includes(i)} size={28} />)}</div>}
            {pl.puzzle > 0 && <div className="ps-pill px-4 py-1.5 flex items-center gap-1.5">{Array.from({ length: pl.puzzle }).map((_, i) => <PuzzleIcon key={i} on={!!s.save?.puzzles[pl.id]?.includes(i)} size={28} color={["#43b0ff", "#ff6fa8", "#7aff7a", "#ffd23c"][i % 4]} />)}</div>}
            {done && <div className="text-white/90 text-sm title-shadow">★ Cleared • Best {fmtTime(done.time)}</div>}
            {lock && <div className="px-5 py-1 rounded-full bg-black/60 border-2 border-red-300 text-red-100 font-semibold">🔒 {lock}</div>}
            <div className="max-w-[44vw] text-white/80 text-sm title-shadow">{pl.blurb}</div>
          </div>
        </div>
      )}
      <div className="absolute bottom-[4vh] left-1/2 -translate-x-1/2 flex items-center gap-8">
        {pl && !lock && <button onClick={() => engine.dive()} className="pointer-events-auto name-plate px-8 py-2 font-bold text-[clamp(18px,2vw,30px)] pop-in" key={pl.id + "d"}>✕  Dive in</button>}
        {pl && lock && <div className="px-6 py-2 rounded-full bg-black/55 border-2 border-white/40 font-bold text-[clamp(16px,1.8vw,26px)]">✕ Locked</div>}
      </div>
      <div className="absolute bottom-[4vh] left-[2vw]"><PromptBar items={[{ text: "WASD", label: "Steer" }, { text: "Shift / R2", label: "Boost" }, { g: "o", label: "Back" }]} /></div>
      {s.toast && <div key={s.toast.t} className="absolute top-[26vh] left-1/2 -translate-x-1/2 name-plate px-7 py-2 font-bold text-[clamp(14px,1.6vw,24px)]" style={{ animation: "slideDown 3s ease-out forwards" }}>{s.toast.text}</div>}
    </div>
  );
}

// ───── Gatcha Lab ─────
export function Gatcha() {
  const s = useUI();
  const [busy, setBusy] = useState(false);
  const pull = () => {
    if (busy) return; if (!engine.gatchaPull()) return;
    setBusy(true); setTimeout(() => setBusy(false), 1400);
  };
  useNav((k) => { if (k === "ok") pull(); if (k === "back") engine.closeModal(); });
  const res = s.gatchaResult; const owned = s.save?.gatcha ?? [];
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(120,20,100,0.55), rgba(10,4,40,0.92))", backdropFilter: "blur(6px)" }}>
      <div className="flex flex-col items-center gap-4 w-[min(980px,94vw)] max-h-[94vh]">
        <div className="text-[clamp(30px,4vw,60px)] font-bold title-shadow tracking-[0.15em]">GATCHA LAB</div>
        <div className="flex items-center gap-10 flex-wrap justify-center">
          <div className="relative w-[200px] h-[260px] flex flex-col items-center">
            <div className="w-[170px] h-[170px] rounded-full relative overflow-hidden" style={{ background: "radial-gradient(circle at 35% 30%, rgba(255,255,255,0.9), rgba(180,220,255,0.35) 60%, rgba(120,170,255,0.3))", border: "5px solid #fff", boxShadow: "0 0 40px rgba(255,150,230,0.7)" }}>
              {["#ff5a7a", "#ffd23c", "#4fd8ff", "#7aff7a", "#c07aff", "#ff9a3c", "#fff"].map((c, i) => <i key={i} className="absolute rounded-full" style={{ width: 38, height: 38, background: c, left: 20 + (i * 37) % 110, top: 80 + ((i * 53) % 60), animation: busy ? `shake 0.2s infinite ${i * 0.03}s` : "none", boxShadow: "inset -5px -5px 10px rgba(0,0,0,0.25)" }} />)}
            </div>
            <div className="w-[190px] h-[110px] rounded-b-[40px] rounded-t-xl mt-[-12px] flex items-end justify-center pb-3" style={{ background: "linear-gradient(180deg,#ff8ad8,#c03a98)", border: "4px solid #fff" }}>
              <div className="w-20 h-12 rounded-xl bg-black/60 border-2 border-white/70" />
            </div>
          </div>
          <div className="flex flex-col items-center gap-3 min-w-[280px] min-h-[220px] justify-center">
            {res ? (
              <div key={res.id + s.version} className="ps-panel px-8 py-5 text-center" style={{ animation: "capsuleDrop 0.7s ease-out both", borderColor: res.rarity === 3 ? "#ffd23c" : res.rarity === 2 ? "#c07aff" : "#8ac0ff" }}>
                <div className="text-7xl mb-1">{res.emoji}</div>
                <div className="text-2xl font-bold">{res.name}</div>
                <div className="text-sm tracking-widest" style={{ color: res.rarity === 3 ? "#ffd23c" : res.rarity === 2 ? "#d9a8ff" : "#9ad0ff" }}>{"★".repeat(res.rarity)} {res.rarity === 3 ? "RARE" : res.rarity === 2 ? "UNCOMMON" : "COMMON"}</div>
                <div className="mt-1 text-sm text-white/80">{res.dupe ? "Duplicate! +20 coins refunded" : "NEW collectible!"}</div>
              </div>
            ) : <div className="text-white/80 text-lg text-center max-w-[300px]">Spend coins to win collectibles for your bots to play with!</div>}
            <button onClick={pull} className="pointer-events-auto name-plate px-8 py-2 font-bold text-2xl flex items-center gap-2" style={{ opacity: (s.save?.coins ?? 0) >= 100 ? 1 : 0.6 }}><CoinIcon size={28} /> 100 — Pull!</button>
            <div className="flex items-center gap-2 text-xl font-bold"><CoinIcon size={26} />{s.save?.coins ?? 0}</div>
            {(s.save?.coins ?? 0) < 100 && <button className="pointer-events-auto text-xs underline text-white/60" onClick={() => engine.debugCoins()}>(web demo) get +500 coins</button>}
          </div>
        </div>
        <div className="ps-panel p-4 w-full overflow-auto">
          <div className="text-white/70 text-sm tracking-widest mb-2">COLLECTION {owned.length}/{GATCHA_ITEMS.length}</div>
          <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(64px,1fr))" }}>
            {GATCHA_ITEMS.map((it) => { const has = owned.includes(it.id); return <div key={it.id} title={has ? it.name : "???"} className="aspect-square rounded-xl flex items-center justify-center text-3xl" style={{ background: has ? "rgba(255,255,255,0.14)" : "rgba(0,0,0,0.35)", border: `2px solid ${has ? (it.rarity === 3 ? "#ffd23c" : it.rarity === 2 ? "#c07aff" : "#8ac0ff") : "rgba(255,255,255,0.15)"}`, filter: has ? "none" : "grayscale(1) brightness(0.2)" }}>{it.emoji}</div>; })}
          </div>
        </div>
        <PromptBar items={[{ g: "x", label: "Pull" }, { g: "o", label: "Leave" }]} />
      </div>
    </div>
  );
}

// ───── Garage ─────
export function Garage() {
  const s = useUI(); const pz = totalPuzzles();
  useNav((k) => { if (k === "back") engine.closeModal(); });
  const save = s.save!;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(20,60,160,0.55), rgba(2,6,40,0.92))", backdropFilter: "blur(6px)" }}>
      <div className="flex flex-col items-center gap-4 w-[min(980px,94vw)]">
        <div className="text-[clamp(28px,3.6vw,54px)] font-bold title-shadow tracking-[0.12em]">DUAL SPEEDER GARAGE</div>
        <div className="grid md:grid-cols-2 gap-5 w-full">
          <div className="ps-panel p-4"><div className="text-white/70 tracking-widest text-sm mb-2">ASTRO OUTFITS</div>
            <div className="flex flex-col gap-2">
              {OUTFITS.map((o) => { const need = o.id === "throwback" ? 0 : o.need; const lock = o.id === "throwback" ? !save.vips.includes("Great Bot Leader") && !s.settings.unlockAll : pz < need && !s.settings.unlockAll; const on = save.outfit === o.id; return (
                <button key={o.id} disabled={lock} onClick={() => engine.setOutfit(o.id)} className={`pointer-events-auto menu-item flex items-center gap-3 px-4 py-2 rounded-2xl text-left font-semibold ${on ? "sel" : ""}`} style={{ opacity: lock ? 0.5 : 1 }}>
                  <span className="w-8 h-8 rounded-full border-2 border-white" style={{ background: `linear-gradient(135deg, ${o.body}, ${o.joint})` }} /><span className="flex-1">{o.name}</span>{lock && <span className="text-sm">🔒 {o.id === "throwback" ? "Beat Nebulax" : `${need} pieces`}</span>}{on && <span>✓</span>}
                </button>); })}
            </div></div>
          <div className="ps-panel p-4"><div className="text-white/70 tracking-widest text-sm mb-2">SPEEDER PAINT</div>
            <div className="grid grid-cols-2 gap-2">
              {SPEEDER_COLORS.map((c) => { const on = save.speeder === c.id; return <button key={c.id} onClick={() => engine.setSpeeder(c.id)} className={`pointer-events-auto menu-item flex items-center gap-3 px-3 py-2 rounded-2xl font-semibold ${on ? "sel" : ""}`}><span className="w-8 h-8 rounded-xl border-2 border-white" style={{ background: c.color }} />{c.name}</button>; })}
            </div>
            <div className="mt-4 text-sm text-white/70">Your paint job appears on the Dual Speeder when you fly the galaxy map.</div>
          </div>
        </div>
        <PromptBar items={[{ g: "o", label: "Leave" }]} />
      </div>
    </div>
  );
}

// ───── Bot Collection ─────
export function Collection() {
  const s = useUI(); const [tab, setTab] = useState<"bots" | "vip" | "planets">("bots");
  useNav((k) => { if (k === "back" || k === "tri") engine.closeModal(); if (k === "l1") setTab((t) => (t === "bots" ? "planets" : t === "vip" ? "bots" : "vip")); if (k === "r1") setTab((t) => (t === "bots" ? "vip" : t === "vip" ? "planets" : "bots")); });
  const save = s.save!;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(10,40,150,0.6), rgba(2,6,40,0.94))", backdropFilter: "blur(6px)" }}>
      <div className="flex flex-col gap-3 w-[min(1060px,95vw)] h-[90vh]">
        <div className="flex items-center justify-between"><div className="text-[clamp(26px,3.4vw,50px)] font-bold title-shadow tracking-[0.1em]">BOT COLLECTION</div><div className="flex gap-3 text-xl font-bold"><span className="ps-pill px-4 py-1 flex items-center gap-2"><RobotIcon size={26} />{totalBots()}</span><span className="ps-pill px-4 py-1 flex items-center gap-2"><PuzzleIcon size={26} />{totalPuzzles()}</span></div></div>
        <div className="flex gap-2">{(["bots", "vip", "planets"] as const).map((t) => <button key={t} onClick={() => setTab(t)} className={`pointer-events-auto menu-item px-6 py-1.5 rounded-full font-bold uppercase tracking-widest ${tab === t ? "sel" : "ps-pill"}`}>{t === "vip" ? "VIP Bots" : t}</button>)}</div>
        <div className="ps-panel p-4 flex-1 overflow-auto">
          {tab === "bots" && GALAXIES.map((g) => (
            <div key={g.id} className="mb-5"><div className="font-bold tracking-widest mb-2 flex items-center gap-2" style={{ color: g.color }}>{g.icon} {g.name.toUpperCase()}</div>
              {g.planets.map(planetById).filter((p) => p.bots > 0).map((p) => (
                <div key={p.id} className="mb-2"><div className="text-sm text-white/70 mb-1">{p.name}</div>
                  <div className="flex flex-wrap gap-2">{Array.from({ length: p.bots }).map((_, i) => { const got = save.bots[p.id]?.includes(i); const d = botDef(p.id, i); return <div key={i} title={got ? d.name : "???"} className="px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2" style={{ background: got ? "rgba(255,255,255,0.14)" : "rgba(0,0,0,0.35)", border: `2px solid ${got ? d.color : "rgba(255,255,255,0.12)"}`, color: got ? "#fff" : "#6a7090" }}><span className="w-3 h-3 rounded-full" style={{ background: got ? d.color : "#444" }} />{got ? d.name : "???"}</div>; })}</div></div>
              ))}
            </div>))}
          {tab === "vip" && (
            <div className="grid gap-3" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(250px,1fr))" }}>
              {Object.entries(VIP_BOTS).map(([name, v]) => { const got = save.vips.includes(name); return <div key={name} className="ps-panel p-4 flex items-center gap-3" style={{ opacity: got ? 1 : 0.5, borderColor: got ? "#ffd23c" : undefined }}><span className="text-4xl" style={{ filter: got ? "none" : "grayscale(1) brightness(0.3)" }}>🎖️</span><div><div className="font-bold">{got ? name : "???"}</div><div className="text-sm text-white/70">{got ? v.note : "Rescue by defeating a boss or finishing a VIP planet."}</div></div></div>; })}
            </div>)}
          {tab === "planets" && GALAXIES.map((g) => (
            <div key={g.id} className="mb-4"><div className="font-bold tracking-widest mb-2" style={{ color: g.color }}>{g.icon} {g.name.toUpperCase()}</div>
              <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))" }}>
                {g.planets.map(planetById).map((p) => { const c = save.cleared[p.id]; return <div key={p.id} className="px-3 py-2 rounded-xl text-sm" style={{ background: c ? "rgba(80,160,255,0.22)" : "rgba(0,0,0,0.35)", border: `2px solid ${c ? "#8ac0ff" : "rgba(255,255,255,0.12)"}` }}><div className="font-bold">{c ? "★ " : ""}{p.name}</div><div className="text-white/60 text-xs">{KIND_LABEL[p.kind] || "PLANET"} • 🤖 {botsIn(p.id)}/{p.bots} • 🧩 {puzzlesIn(p.id)}/{p.puzzle}{c ? ` • ${fmtTime(c.time)}` : ""}</div></div>; })}
              </div></div>))}
        </div>
        <div className="flex justify-between items-center"><PromptBar items={[{ text: "Q / R", label: "Switch tab" }, { g: "o", label: "Close" }]} /><div className="text-white/60 text-sm">Hub unlocks: Gatcha Lab {HUB_UNLOCKS[0].need} • Garage {HUB_UNLOCKS[1].need} • Safari {HUB_UNLOCKS[2].need} pieces • {PLANETS.length} planets total</div></div>
      </div>
    </div>
  );
}

export function SafariHud() {
  useNav((k) => { if (k === "back" || k === "ok") engine.exitPhoto(); });
  return <div className="fixed inset-0 z-10 pointer-events-none"><div className="absolute bottom-[4vh] left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"><div className="ps-pill px-6 py-1.5 font-bold tracking-widest">📷 PHOTO MODE — SAFARI PARK</div><PromptBar items={[{ text: "Mouse / Arrows", label: "Orbit" }, { g: "o", label: "Exit" }]} /></div></div>;
}
export { ui };
