import { useEffect, useRef, type ReactNode } from "react";
import { onNav, type NavKey } from "../game/input";

export function useNav(fn: (k: NavKey) => void, active = true) {
  const ref = useRef(fn); ref.current = fn;
  useEffect(() => { if (!active) return; return onNav((k) => ref.current(k)); }, [active]);
}

export function Glyph({ k, className = "" }: { k: "x" | "o" | "s" | "t"; className?: string }) {
  const map = { x: ["✕", "g-x"], o: ["○", "g-o"], s: ["□", "g-s"], t: ["△", "g-t"] } as const;
  return <span className={`btn-glyph ${map[k][1]} ${className}`}>{map[k][0]}</span>;
}

export function PromptBar({ items }: { items: { g?: "x" | "o" | "s" | "t"; text?: string; label: string }[] }) {
  return (
    <div className="flex items-center gap-6 text-white title-shadow text-[clamp(14px,1.5vw,22px)] font-medium">
      {items.map((it, i) => (
        <div key={i} className="flex items-center gap-2">
          {it.g ? <Glyph k={it.g} /> : <span className="px-2 py-0.5 rounded-lg bg-white/20 border border-white/60 text-[0.8em]">{it.text}</span>}
          <span>{it.label}</span>
        </div>
      ))}
    </div>
  );
}

export function RobotIcon({ on = true, size = 26, color = "#ffffff" }: { on?: boolean; size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" style={{ opacity: on ? 1 : 0.32, filter: on ? "drop-shadow(0 0 5px rgba(120,200,255,0.9))" : "none" }}>
      <rect x="5" y="7" width="22" height="19" rx="9" fill={on ? color : "#8a96b8"} stroke="#0b2a8a" strokeWidth="2" />
      <rect x="9" y="12" width="14" height="9" rx="4.5" fill="#0b1030" />
      <ellipse cx="13" cy="16.5" rx="1.9" ry="2.4" fill={on ? "#59d4ff" : "#4a5a80"} />
      <ellipse cx="19" cy="16.5" rx="1.9" ry="2.4" fill={on ? "#59d4ff" : "#4a5a80"} />
      <circle cx="16" cy="4.5" r="2" fill={on ? "#ffd23c" : "#8a96b8"} />
      <rect x="15.2" y="5" width="1.6" height="3" fill="#0b2a8a" />
    </svg>
  );
}
export function PuzzleIcon({ on = true, size = 26, color = "#43b0ff" }: { on?: boolean; size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" style={{ opacity: on ? 1 : 0.32, filter: on ? `drop-shadow(0 0 6px ${color})` : "none" }}>
      <path d="M6 6h7a3 3 0 1 1 6 0h7v7a3 3 0 1 0 0 6v7h-7a3 3 0 1 0-6 0H6v-7a3 3 0 1 1 0-6z" fill={on ? color : "#8a96b8"} stroke="#0b2a8a" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}
export function CoinIcon({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" style={{ filter: "drop-shadow(0 0 5px rgba(255,200,40,0.8))" }}>
      <circle cx="16" cy="16" r="13" fill="#ffcf3a" stroke="#b8730a" strokeWidth="2.5" />
      <circle cx="16" cy="16" r="9" fill="none" stroke="#ff9a00" strokeWidth="1.6" />
      <path d="M16 8.5l2.2 5 5.3.5-4 3.6 1.2 5.2-4.7-2.8-4.7 2.8 1.2-5.2-4-3.6 5.3-.5z" fill="#fff3b0" stroke="#b8730a" strokeWidth="0.8" />
    </svg>
  );
}

export function Panel({ children, className = "", style }: { children: ReactNode; className?: string; style?: React.CSSProperties }) {
  return <div className={`ps-panel ${className}`} style={style}>{children}</div>;
}

export const fmtTime = (t: number) => { const m = Math.floor(t / 60), s = Math.floor(t % 60), c = Math.floor((t % 1) * 100); return `${m}:${String(s).padStart(2, "0")}.${String(c).padStart(2, "0")}`; };
