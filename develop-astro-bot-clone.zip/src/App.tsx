import { useEffect, useRef } from "react";
import { useUI } from "./game/store";
import { engine } from "./game/engine";
import { Loading, TitleScreen, SlotScreen } from "./ui/Title";
import { LevelHud, HubHud, PauseMenu, Results, Credits, Fade } from "./ui/Hud";
import { GalaxySelect, FlightHud, Gatcha, Garage, Collection, SafariHud } from "./ui/Menus";

export default function App() {
  const ref = useRef<HTMLCanvasElement>(null);
  const s = useUI();
  useEffect(() => { if (ref.current) engine.init(ref.current); }, []);
  const sc = s.screen;
  return (
    <>
      <canvas id="game" ref={ref} />
      {!s.ready && <Loading />}
      {s.ready && sc === "title" && <TitleScreen />}
      {s.ready && sc === "slots" && <SlotScreen />}
      {sc === "hub" && <HubHud />}
      {(sc === "gatcha") && <><HubHud /><Gatcha /></>}
      {(sc === "garage") && <><HubHud /><Garage /></>}
      {(sc === "collection") && <><HubHud /><Collection /></>}
      {sc === "safari" && <SafariHud />}
      {sc === "galaxies" && <GalaxySelect />}
      {sc === "map" && <FlightHud />}
      {(sc === "level" || sc === "results") && <LevelHud />}
      {sc === "results" && s.results && <Results />}
      {sc === "credits" && <Credits />}
      {s.paused && (sc === "level" || sc === "hub") && <PauseMenu />}
      <Fade />
    </>
  );
}
